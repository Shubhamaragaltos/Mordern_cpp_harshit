#include "Vehicle.h"

Vehicle::Vehicle(int id, std::string CarName, int long long Carprice, VehicleType CarType)
:Car_id(id), Car_Name(CarName),Car_price(Carprice),Car_Type(CarType)
{
}
std::ostream &operator<<(std::ostream &os, const Vehicle &rhs) {
    os << "Car_id: " << rhs.Car_id
       << " Car_Name: " << rhs.Car_Name
       << " Car_price: " << rhs.Car_price
       << " Car_Type: " <<static_cast<int> (rhs.Car_Type);
    return os;
}
