#include <iostream>
#include "Functionalities.h"

int main()
{
    Container ptr;
    std::cout << "\n\n================================================================\n\n";
    try
    {
        CreateObject(ptr);
    }
    catch (std::runtime_error &E)
    {
        std::cerr << E.what() << "ERROR IN CREATE";
    }

    std::cout << "\n\n=============================CAR INSTANCE FOR CAR ID 5893================================\n\n";

    try
    {
        Pointer at = Instane_for_given_id(ptr, 11);
        std::cout << *at;
    }
    catch (std::runtime_error &E)
    {
        std::cerr << E.what() << "\nERROR IN SEARCH DUNCTION\n";
    }
    std::cout << "\n\n=======================AVERAGE PRICE =================================\n\n";
    try
    {
        int long long ans = Average_Price(ptr);
        std::cout << "The Average price: " << ans;
    }
    catch (std::runtime_error &E)
    {
        std::cerr << E.what() << "ERROR IN CREATE";
    }
    std::cout << "\n\n=========================LOWEST PRICE=================================\n\n";
    try
    {
        int long long ans1 = Lowest_price(ptr);
        std::cout << ans1;
    }
    catch (std::runtime_error &E)
    {
        std::cerr << E.what() << "ERROR IN CREATE";
    }
    std::cout << "\n\n=======================HIGHEST=====================================\n\n";
    try
    {
        int long long ans2 = Highest_price(ptr);
        std::cout << ans2;
    }
    catch (std::runtime_error &E)
    {
        std::cerr << E.what() << "ERROR IN CREATE";
    }
    std::cout << "\n\n===========================REGISTRATION CHARGES=====================================\n\n";
    try
    {
        ALL_Regidtraion_charges(ptr);
    }
    catch (std::runtime_error &E)
    {
        std::cerr << E.what() << "ERROR IN CREATE";
    }
    std::cout << "\n\n=============================AUTOMATIC CARS===================================\n\n";

    try
    {
        Container p = Instance_for_type_of_car(ptr);
        for (auto r : p)
        {
            std::cout << "\n"
                      << *r;
        }
    }
    catch (std::runtime_error &E)
    {
        std::cerr << E.what() << "ERROR IN CREATE";
    }

    std::cout << "\n\n================================================================\n\n";
    try
    {
        Sort_Pirce_asencding(ptr);
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << "ERROR IN CREATE";
    }
    std::cout << "\n\n================================================================\n\n";
    try
    {
        Sort_Pirce_Decending(ptr);
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << "ERROR IN CREATE";
    }

    std::cout << "\n\n================================================================\n\n";
    Count_VhicleType(ptr);

    std::cout << "\n\n================================================================\n\n";
  //  Count_VhicleType_2(ptr);
    std::cout << "\n\n================================================================\n\n";
}