#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include "Vehicle.h"
#include <memory>
#include <vector>
#include"PetrolCar.h"
#include"DiselCar.h"
#include"EVCar.h"
#include"Hybrid.h"
#include<algorithm>
#include<numeric>

using Pointer = std::shared_ptr<Vehicle>;
using Container = std::vector<Pointer>;

void CreateObject(Container &data);
float Average_Price(Container &data);

void ALL_Regidtraion_charges(Container &data);
float Lowest_price(Container &data);
float Highest_price(Container &data);
Pointer Instane_for_given_id(Container &data, int id);
Container Instance_for_type_of_car(Container &data);
void Count_VhicleType(Container &data);
void Sort_Pirce_asencding(Container data);
void Sort_Pirce_Decending(Container data);
void Count_VhicleType_2(Container &data);





#endif // FUNCTIONALITIES_H
