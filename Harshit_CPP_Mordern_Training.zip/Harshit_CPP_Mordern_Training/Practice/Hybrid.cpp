#include "Hybrid.h"
std::ostream &operator<<(std::ostream &os, const Hybrid &rhs) {
    os << static_cast<const Vehicle &>(rhs)
       << " Car_Hybrid_battery: " << rhs.Car_Hybrid_battery
       << " Car_Hybrid_fuel: " << rhs.Car_Hybrid_fuel;
    return os;
}
Hybrid::Hybrid(int id, std::string CarName, int long long Carprice, VehicleType CarType, int FuelCapacity, int Battery_capacity)
: Vehicle(id,CarName,Carprice,CarType), Car_Hybrid_fuel(FuelCapacity), Car_Hybrid_battery(Battery_capacity)
{
}

void Hybrid::Vehicle_Registration()
{
    std::cout<<"\nThe Registraion Cost for HYBRID COST: "<<carPrice()*0.10f;
}
