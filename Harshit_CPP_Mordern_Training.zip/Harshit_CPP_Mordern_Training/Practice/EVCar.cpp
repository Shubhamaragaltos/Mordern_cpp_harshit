#include "EVCar.h"
std::ostream &operator<<(std::ostream &os, const EVCar &rhs) {
    os << static_cast<const Vehicle &>(rhs)
       << " Car_EV_Battery_capacity: " << rhs.Car_EV_Battery_capacity;
    return os;
}
EVCar::EVCar(int id, std::string CarName, int long long Carprice, VehicleType CarType, int FuelCapacity)
:Vehicle(id,CarName,Carprice,CarType), Car_EV_Battery_capacity(FuelCapacity)
{
}

void EVCar::Vehicle_Registration()
{
        std::cout<<"\nThe Registraion Cost for EVCAR COST: "<<carPrice()*0.01f;

}
