#include "DiselCar.h"
std::ostream &operator<<(std::ostream &os, const DiselCar &rhs) {
    os << "Disel_Fuel_capacity: " << rhs.Disel_Fuel_capacity;
    return os;
}
DiselCar::DiselCar(int id, std::string CarName, int long long Carprice, VehicleType CarType, int FuelCapacity)
:Vehicle(id,CarName,Carprice,CarType),Disel_Fuel_capacity(FuelCapacity)
{
}

void DiselCar::Vehicle_Registration()
{
        std::cout<<"\nThe Registraion Cost for DISEL COST: "<<carPrice()*0.30;

}
