#ifndef HYBRID_H
#define HYBRID_H

#include<iostream>
#include"Vehicle.h"

class Hybrid: public Vehicle
{
private:
    int Car_Hybrid_battery;
    int Car_Hybrid_fuel;
public:
     Hybrid(/* args */) = default;
    Hybrid(int id, std::string CarName, int long long Carprice, VehicleType CarType, int FuelCapacity, int Battery_capacity);
    Hybrid(Hybrid &&) = delete;
    Hybrid(const Hybrid &) = delete;

    Hybrid &operator=(const Hybrid &) = delete;
    Hybrid &operator=(Hybrid &) = delete;
     void Vehicle_Registration()override;

    ~Hybrid() = default;

    int carHybridFuel() const { return Car_Hybrid_fuel; }

    int carHybridBattery() const { return Car_Hybrid_battery; }

    friend std::ostream &operator<<(std::ostream &os, const Hybrid &rhs);
};

#endif // HYBRID_H
