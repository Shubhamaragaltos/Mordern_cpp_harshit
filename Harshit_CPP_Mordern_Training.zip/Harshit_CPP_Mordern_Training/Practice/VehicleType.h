#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

enum class VehicleType
{
    MANULA,
    AUTOMATIC,
    HYBRID
};

#endif // VEHICLETYPE_H
