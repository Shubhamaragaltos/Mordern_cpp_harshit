
#ifndef PETROLCAR_H
#define PETROLCAR_H

#include <iostream>
#include "Vehicle.h"

class PetrolCar : public Vehicle
{
private:
    int Petrol_Fuel_Capacity;

public:
    PetrolCar(/* args */) = default;
    PetrolCar(int id, std::string CarName, int long long Carprice, VehicleType CarType, int FuelCapacity);
    PetrolCar(PetrolCar &&) = delete;
    PetrolCar(const PetrolCar &) = delete;

    PetrolCar &operator=(const PetrolCar &) = delete;
    PetrolCar &operator=(PetrolCar &) = delete;
    void Vehicle_Registration() override;
    ~PetrolCar() = default;

    int petrolFuel_Capacity() const { return Petrol_Fuel_Capacity; }

    friend std::ostream &operator<<(std::ostream &os, const PetrolCar &rhs);
};
#endif // PETROLCAR_H
