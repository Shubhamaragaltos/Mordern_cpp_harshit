#include "PetrolCar.h"

PetrolCar::PetrolCar(int id, std::string CarName, int long long Carprice, VehicleType CarType, int FuelCapacity)
:Vehicle(id,CarName,Carprice,CarType), Petrol_Fuel_Capacity(FuelCapacity)
{
}
void PetrolCar::Vehicle_Registration()
{
        std::cout<<"\nThe Registraion Cost for PETROL COST: "<<carPrice()*0.18f;

}
std::ostream &operator<<(std::ostream &os, const PetrolCar &rhs)
{
    os << "Petrol_Fuel_Capacity: " << rhs.Petrol_Fuel_Capacity;
    return os;
}
