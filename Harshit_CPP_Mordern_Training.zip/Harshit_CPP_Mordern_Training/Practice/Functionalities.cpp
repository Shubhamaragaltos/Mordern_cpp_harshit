#include "Functionalities.h"

void CreateObject(Container &data)
{
    data.emplace_back(std::make_shared<PetrolCar>(1, "NEXON", 820, VehicleType::MANULA, 30));
    data.emplace_back(std::make_shared<PetrolCar>(2, "NEXON", 1190000, VehicleType::AUTOMATIC, 40));
    data.emplace_back(std::make_shared<DiselCar>(3, "KIA SELTOS", 1540000, VehicleType::MANULA, 30));
    data.emplace_back(std::make_shared<DiselCar>(4, "TAT HARRIER", 1890980, VehicleType::AUTOMATIC, 50));
    data.emplace_back(std::make_shared<EVCar>(5, "ALTROZ", 420000, VehicleType::MANULA, 30));
    data.emplace_back(std::make_shared<EVCar>(6, "ALTROZ", 620000, VehicleType::AUTOMATIC, 20));

    data.emplace_back(std::make_shared<Hybrid>(7, "TOYATA INOVA", 9822000, VehicleType::AUTOMATIC, 30, 100));
    data.emplace_back(std::make_shared<Hybrid>(8, "ALTO", 120000, VehicleType::MANULA, 40, 100));

    data.emplace_back(std::make_shared<EVCar>(10, "kia", 535356, VehicleType::AUTOMATIC, 20));
    data.emplace_back(std::make_shared<EVCar>(11, "alto", 897362, VehicleType::AUTOMATIC, 20));
    data.emplace_back(std::make_shared<EVCar>(12, "fera", 94746, VehicleType::AUTOMATIC, 20));
    data.emplace_back(std::make_shared<EVCar>(13, "boat", 647839, VehicleType::AUTOMATIC, 20));
    data.emplace_back(std::make_shared<EVCar>(14, "bmw", 547738, VehicleType::AUTOMATIC, 20));

    auto itr = data.begin();
    for (Pointer p : data)
    {
        std::cout << "\n"
                  << **itr;
        itr++;
    }
}

float Average_Price(Container &data)
{
    // if (data.empty())
    // {
    //     throw "\nCONATINER IS EMPTY\n";
    // }
    int count = 0;
    int sum = 0;
    // for (Pointer &p : data)
    // {
    //     sum += p->carPrice();
    //     count++;
    // }
    sum = std::accumulate(data.begin(), data.end(), 0, [&](int first, Pointer &ptr)
                          {
        count++;
        return first + ptr->carPrice(); });
    return sum / count;
}

void ALL_Regidtraion_charges(Container &data)
{
    if (data.empty())
    {
        throw "\nCONATINER IS EMPTY\n";
    }

    for (Pointer &p : data)
    {
        p->Vehicle_Registration();
    }
}

float Lowest_price(Container &data)
{
    if (data.empty())
    {
        throw "\nCONATINER IS EMPTY\n";
    }

    // int min = data[0]->carPrice();
    // for (Pointer &p : data)
    // {
    //     if (min > p->carPrice())
    //     {
    //         min = p->carPrice();
    //     }
    // }

    auto itr = std::min_element(data.begin(), data.end(), [](Pointer &ptr1, Pointer &ptr2)
                                { return ptr1->carPrice() < ptr2->carPrice(); });

    Pointer min = *itr;
    // std::cout<<"\n iterator: "<<**itr<<"\n\n";
    return min->carPrice();
}

float Highest_price(Container &data)
{
    if (data.empty())
    {
        throw "\nCONATINER IS EMPTY\n";
    }

    // int max = data[0]->carPrice();
    // for (Pointer &p : data)
    // {
    //     if (max < p->carPrice())
    //     {
    //         max = p->carPrice();
    //     }
    // }

    auto itr = std::max_element(data.begin(), data.end(), [](Pointer &ptr1, Pointer &ptr2)
                                { return ptr1->carPrice() < ptr2->carPrice(); });
    Pointer max = *itr;
    std::cout << "Higest Price : "
              << "\n";
    return max->carPrice();
}

Pointer Instane_for_given_id(Container &data, int id)
{
    if (data.empty())
    {
        throw std::runtime_error("\nCONATINER IS EMPTY\n");
    }

    // for (auto t : data)
    // {
    //     if (id == t->carId())
    //     {
    //         return t;
    //     }
    // }
    throw std::runtime_error("\nID NOT FOUND\n");
}
Container Instance_for_type_of_car(Container &data)
{
    if (data.empty())
    {
        throw "\nCONATINER IS EMPTY\n";
    }

    Container type;
    // for (Pointer p : data)
    // {
    //     if (p->carType() == VehicleType::AUTOMATIC)
    //     {
    //         type.emplace_back(p);
    //     }
    // }

    auto tp = std::find_if(data.begin(), data.end(), [](Pointer &ptr)
                           { return ptr->carType() == VehicleType::AUTOMATIC; });
    type.emplace_back(*tp);
    return type;
}

void Count_VhicleType(Container &data)
{
    int count = std::count_if(data.begin(), data.end(), [](Pointer &ptr)
                              { return ptr->carType()==VehicleType::AUTOMATIC; });
    std::cout << "\nCount : " << count << "\n";
}

void Sort_Pirce_asencding(Container data)
{
     std::sort(data.begin(),data.end(),[](Pointer& ptr1, Pointer& ptr2){
        return ptr1->carPrice() < ptr2->carPrice();

    });
        std::cout << "\nSort_Pirce_asencding : " << "\n";

    for (auto &&i : data)
    {
        std::cout<<*i<<"\n";
    }
    
}

void Sort_Pirce_Decending(Container data)
{
    std::sort(data.begin(),data.end(),[](Pointer& ptr1, Pointer& ptr2){
        return ptr1->carPrice() > ptr2->carPrice();

    });
        std::cout << "\nSort_Pirce_Dsencding : " << "\n";

    for (auto &&i : data)
    {
        std::cout<<*i<<"\n";
    }
    
}

// void Count_VhicleType_2(Container &data)
// {
//     int count = std::count(data.begin(), data.end(),data[0].get()->carPrice());
//     std::cout << "\nCount : " << count << "\n";
// }
