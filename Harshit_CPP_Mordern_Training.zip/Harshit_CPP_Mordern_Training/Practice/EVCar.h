#ifndef EVCAR_H
#define EVCAR_H

#include <iostream>
#include "Vehicle.h"

class EVCar : public Vehicle
{
private:
    /* data */
    int Car_EV_Battery_capacity{-1};

public:
    EVCar(/* args */) = default;
    EVCar(int id, std::string CarName, int long long Carprice, VehicleType CarType, int FuelCapacity);
    EVCar(EVCar &&) = delete;
    EVCar(const EVCar &) = delete;
    void Vehicle_Registration() override;

    EVCar &operator=(const EVCar &) = delete;
    EVCar &operator=(EVCar &) = delete;

    ~EVCar() = default;

    int carEV_BatteryCapacity() const { return Car_EV_Battery_capacity; }

    friend std::ostream &operator<<(std::ostream &os, const EVCar &rhs);
};
#endif // EVCAR_H
