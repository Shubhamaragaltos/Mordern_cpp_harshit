#ifndef DISELCAR_H
#define DISELCAR_H

#include <iostream>
#include "Vehicle.h"

class DiselCar : public Vehicle
{
private:
    int Disel_Fuel_capacity;

public:
    DiselCar(/* args */) = default;
    DiselCar(int id, std::string CarName, int long long Carprice, VehicleType CarType, int FuelCapacity);
    DiselCar(DiselCar &&) = delete;
    DiselCar(const DiselCar &) = delete;

    DiselCar &operator=(const DiselCar &) = delete;
    DiselCar &operator=(DiselCar &) = delete;
void Vehicle_Registration()override;
    ~DiselCar() = default;

    int diselFuelCapacity() const { return Disel_Fuel_capacity; }

    friend std::ostream &operator<<(std::ostream &os, const DiselCar &rhs);
};

#endif // DISELCAR_H
