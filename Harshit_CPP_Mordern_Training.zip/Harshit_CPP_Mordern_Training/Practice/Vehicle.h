#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
#include "VehicleType.h"

class Vehicle
{
private:
    int Car_id{-1};
    std::string Car_Name{""};
    int long long Car_price;
    VehicleType Car_Type{VehicleType::AUTOMATIC};

public:
    Vehicle(/* args */) = default;
    Vehicle(int id, std::string CarName, int long long Carprice, VehicleType CarType);
    Vehicle(Vehicle &&) = delete;
    Vehicle(const Vehicle &) = delete;

    Vehicle &operator=(const Vehicle &) = delete;
    Vehicle &operator=(Vehicle &) = delete;

    ~Vehicle() = default;
    virtual void Vehicle_Registration() = 0;
    int carId() const { return Car_id; }

    std::string carName() const { return Car_Name; }

    float carPrice() const { return Car_price; }

    VehicleType carType() const { return Car_Type; }

    friend std::ostream &operator<<(std::ostream &os, const Vehicle &rhs);
};

#endif // VEHICLE_H
