#include "Functionalities.h"

using Data_Container = std::vector<std::string>;
int main()
{
    Container ptr;
    CreateObjects(ptr);
    std::cout << "\n==========================================\n";
    Find_id_with_discount(ptr);
    std::cout << "\n==========================================\n";
    Find_type_using_id(ptr);
    std::cout << "\n==========================================\n";
    Find_N_iNstance(ptr);
    std::cout << "\n==========================================\n\n";

    return 0;
}