#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Order.h"
#include <vector>
#include<functional>

using Pointer = std::shared_ptr<Order>;
using Container = std::vector<Pointer>;
using Fntype = std::function<void(Container &)>;
//using Function_Container = std::vector<Fntype>;



// Functioanlities
void CreateObjects(Container &data);
//void Functions(Function_Container& function );
extern Fntype Find_id_with_discount;
extern Fntype Find_type_using_id;
extern Fntype Find_N_iNstance;

#endif // FUNCTIONALITIES_H
