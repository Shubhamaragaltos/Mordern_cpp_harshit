#include "Functionalities.h"

void CreateObjects(Container &data)
{
    // Putting data in the container
    data.emplace_back(
        std::make_shared<Order>(
            "ID1",
            100.5,
            Type::COD,
            10.5));
    data.emplace_back(
        std::make_shared<Order>(
            "ID2",
            200.5,
            Type::PAID,
            20.5));
    data.emplace_back(
        std::make_shared<Order>(
            "ID3",
            300.5,
            Type::PROMOTION,
            30.5));
    data.emplace_back(
        std::make_shared<Order>(
            "ID4",
            400.5,
            Type::PAID,
            40.5));
    data.emplace_back(
        std::make_shared<Order>(
            "ID5",
            1000.5,
            Type::COD,
            50.5));
}

Fntype Find_id_with_discount = [](Container &data)
{
                              auto itr = data.begin();
                              int max = (*itr)->discount();
                              std::string ans{};

                              for (Pointer p : data)
                              {
                                  if (max < p->discount())
                                  {
                                      max = p->discount();
                                      ans = p->id();
                                  }
                              }
                              std::cout << "\n The ID with Maximum Discout is : " << ans; };

Fntype Find_type_using_id = [](Container &data)
{
                                std::string idx = "ID2";
                                for (Pointer& p : data)
                                {
                                    if (p->id() == idx)
                                    {
                                        std::cout <<static_cast<int>(p->type());
                                    }
                                } };

Fntype Find_N_iNstance = [](Container &data)
{
    int n = 3;

    for (Pointer &p : data)
    {
        if (n > 0)
        {

            std::cout << "\n"
                      << *p;
            --n;
        }
    }
};
