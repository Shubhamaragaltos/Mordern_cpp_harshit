#include <algorithm>
#include <numeric>
#include <iostream>

template <typename T>

void Display(T &Container)
{
    for (auto &val : Container)
    {
        std::cout << val << "\n";
    }
    std::cout << std::endl;
}
int main()
{
    //// Example : Copy all element unconditionally from source to destination

    std::vector<int> v1{10, 20, 30, 40, 50};
    std::vector<int> result(v1.size());

    std::copy(v1.begin(), v1.end(), result.begin());
    Display(result);
    // Example 2: Sum of all values

    std::cout << "Total is : " << std::accumulate(v1.begin(), v1.end(), 0) << "\n";

    std::cout<<"Product is : "<<std::accumulate(v1.begin(), v1.end(), 1,[](int Current_result, int Item_from_container){return Current_result  * Item_from_container;}); 
    return 0;
}