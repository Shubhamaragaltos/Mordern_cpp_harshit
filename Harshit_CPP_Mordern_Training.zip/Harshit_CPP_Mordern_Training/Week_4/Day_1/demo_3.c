#include <stdlib.h>
#include <stdio.h>

int main()
{
    int id = fork();

    if (id == 0)
    {
        printf("This satementis printed in the child: \n");
        printf("Process ID: %d and my Child ID is : %d\n\n\n",getpid(),getppid());
    }
    else
    {
        printf("\nThis Comes from parent: \n");
        printf("Process ID: %d and my parent ID is : %d\n",getpid(),getppid());

    }
    return 0;
}