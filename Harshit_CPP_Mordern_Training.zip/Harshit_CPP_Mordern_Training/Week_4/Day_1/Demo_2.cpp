#include <iostream>
#include<vector>

/*
I want to design an application to process 10 e=recent transaction made by user by fetching their detail from the database

OPERATION:
    Each transaction hs bo relatibility with othera i.e All transactions are mutually exclusive Each Transaction
    has the following satate

    [transaction time | amount | source | destination]

    ANS: ARRAY



*/
/*

EXAMPLE 2:

    I want to desgin a application where a new data value is recevied at a fixed interval an gets added at
 the back of the data values do far. i want to process only the oldest value from theses values at a
 time and print the value on the console.

    I am not allowed to modify ant recevied value and for as value gets processed,
 it needs to be removed from the trnsaction pending set.

ANS : queu linked lis

*/
