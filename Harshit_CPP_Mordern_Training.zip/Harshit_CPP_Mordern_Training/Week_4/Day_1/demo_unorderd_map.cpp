#include<iostream>
#include<unordered_map>

int main()
{
    std::unordered_map<int,std::string> umap{
        {101,"Shubham"},
        {102,"Rohan"},
        {103, "Hetvi"},
        {104, "Bhagyashree"}
        
        
        
    };
    for(int i=101; i<105; i++)
    {

    std::cout<<"\n Employee with ID :"<<i<<" - "<<umap[i];
    }

}