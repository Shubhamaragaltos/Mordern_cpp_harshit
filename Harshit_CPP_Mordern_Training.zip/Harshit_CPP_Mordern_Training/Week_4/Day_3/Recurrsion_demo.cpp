#include <memory>
#include <iostream>
// Variadic templates (templates that can aacept variavle number of arguments)
// eg:

// Use Concept of recurrsion and base case
// my base case in addition id :  adding only 1 value;

// T add(T n1)
// {
//     return n1;
// }


template <typename... T>
auto add(T... args)
{
    return (args+ ...);
}


int main()
{
    std::cout << add<int>(1.90, 280, 8) << "\n";
    std::cout << add<int>(10, 20) << "\n";
}