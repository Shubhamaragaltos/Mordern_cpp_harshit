
#include"functionalities.h"






int main()
{
    Container ptr;
    CreateObject(ptr);
    std::cout<<"\n++++++++++++++++++++++++++++++++++++++++++++++\n";
    int count = Count0fEmployessLessThan7Char(ptr);
    std::cout<<"\n The Count of Employees Less than Characters 7 \n"<<count;
}