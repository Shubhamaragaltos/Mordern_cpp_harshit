#include <set>
#include <memory>
#include <iostream>
#include "Employee.h"

using Pointer = std::shared_ptr<Employee>;
using Pointer_Container = std::set<Pointer>;
template <typename T>
void Display(const T &container)
{
    for (const auto &val : container)
    {
        std::cout << val << "\n";
    }
}
// template<>
//  void Display(const Pointer& data)
//  {
//      for (const auto& ptr : data)
//      {
//          std::cout<<*ptr<<"\n";
//      }

// }

int main()
{
    std::set<int> s1{10, 20, 90, 90, 30, 20, 104, 5};
    s1.emplace(49);
    s1.insert(3);
    

    Display<std::set<int>>(s1);
}
