#include <iostream>

/*
    PASS BY VALUE: Accept both lvalue and rvalue. rvalue is assigned.
    Lvalue is copied. n1 is also modifiyable in the scope of f1.

    */

void f1(const int &&n1 )
{
    std::cout << "\nAdress of n1 in f1 function: " << &n1;
    std::cout << "\nValue of n1 in f1 Before modification: " << n1;
    //n1 = 100;
    std::cout << "\nValue of n1 in f1 After modification: " << n1;
}
int main()
{
    f1(4);
}