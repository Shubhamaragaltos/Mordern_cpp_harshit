#include "Employee.h"

Employee::Employee(std::string name, float salary): _name(name), _salary(salary)
{
}

std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_name: " << rhs._name
    
       << " _salary: " << rhs._salary;
    return os;
}
