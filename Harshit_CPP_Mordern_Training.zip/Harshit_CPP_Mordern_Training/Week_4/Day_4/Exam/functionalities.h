#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include"Employee.h"
#include <algorithm>
#include <memory>
#include <unordered_map>
#include <numeric>

/*
-return the count of employees whos name is less than 7 characters
 
-find salary of employee whose ID is received as a parameter
 
- find the average salary for only those employees whose id is passed as a vector of integers passed to the function

*/
using Pointer = std::shared_ptr<Employee>;
using Container = std::unordered_map<int, Pointer>;

void CreateObject(Container& data);
int Count0fEmployessLessThan7Char(Container& data);
 float FindSalarybyID(Container& data, int ID);
 float AverageSalary(Container& data, std::vector<int> ID);



#endif // FUNCTIONALITIES_H
