
#include "functionalities.h"

int main()
{
    Container ptr;
    CreateObject(ptr);
    std::cout << "\n++++++++++++++++++++++++++++++++++++++++++++++\n";
    int count = Count0fEmployessLessThan7Char(ptr);
    std::cout << "\n The Count of Employees Less than Characters 7 : \t" << count;
    std::cout << "\n++++++++++++++++++++++++++++++++++++++++++++++\n";
    std::cout << "\nThe salary for given ID:  " << FindSalarybyID(ptr, 101);
    std::cout << "\n++++++++++++++++++++++++++++++++++++++++++++++\n";
    std::cout << "\nThe Average salary for given ID:  " <<AverageSalary(ptr, std::vector<int>{103, 102});
    std::cout << "\n++++++++++++++++++++++++++++++++++++++++++++++\n";
}