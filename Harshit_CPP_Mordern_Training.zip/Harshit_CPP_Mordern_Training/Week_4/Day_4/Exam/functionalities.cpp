#include "functionalities.h"

void CreateObject(Container &data)
{
    data.emplace(std::make_pair(101, std::make_shared<Employee>("Shubham", 90000)));
    data.emplace(std::make_pair(102, std::make_shared<Employee>("Rohan", 2700)));
    data.emplace(std::make_pair(103, std::make_shared<Employee>("Hetvi_bhatashna", 76070)));
    data.emplace(std::make_pair(104, std::make_shared<Employee>("Shreya", 37637)));
}

int Count0fEmployessLessThan7Char(Container &data)
{
    auto ans = std::count_if(data.begin(), data.end(), [](const std::pair<int, Pointer> &ptr)
                             { return (ptr.second->name().size() < 7); });

    return ans;
}

float FindSalarybyID(Container &data, int ID)
{
    if (data.empty())
        throw std::runtime_error("No data exists in Container");

    auto itr = std::find_if(data.begin(), data.end(), [&](const std::pair<int, Pointer> &ptr)
                            { return ptr.first == ID; });
    if (itr == data.end())
    {
            throw std::runtime_error("No data find");

    }
    else
    {
        return itr->second->salary();
    }
}

float AverageSalary(Container &data, std::vector<int> ID)
{
     float total=0.0f;
        int count =0;
    for (int id : ID)
    {
       
        auto itr = data.find(id);
        if(itr!= data.end())
        {
            count ++;
            total += itr->second->salary();
        }
       
    }
    return total/count;
}

//complexity amortize