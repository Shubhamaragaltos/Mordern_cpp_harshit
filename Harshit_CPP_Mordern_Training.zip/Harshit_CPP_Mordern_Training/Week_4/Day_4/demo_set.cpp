#include <set>
#include<iostream>
#include<functional>


template<typename T>
void Display(std::set<T,std::less<float>>& Data)
{
    for (const T&i : Data)
    {
        std::cout<<i<<"\n";
    }
}
struct Employee
{
    int _id;
    float _salary;
    Employee(int id,float salary):_id(id),_salary(salary){}
    // bool operator<(const Employee& rhs)const
    // {
    //     return _salary>rhs._salary;
    // }

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
        os << "Employe: "<<"_id: " << rhs._id
           << " _salary: " << rhs._salary;
        return os;
    }
};
int main()
{
    Employee e1(1,40),e2(2,20),e3(3,10),e4(4,30),e5(5,40);
    std::set<Employee,std::less<float>> s1{e1,e2,e3,e4,e5};
    Display(s1);
    
}

/*
what about marathon?
ans: Final marathon may include question on set of primitive types of user-defined custom classes but NOT USING
SMART POINTERS

*/