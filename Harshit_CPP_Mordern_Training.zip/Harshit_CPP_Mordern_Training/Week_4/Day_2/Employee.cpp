#include <algorithm>
#include <iostream>
#include <memory>
#include <unordered_map>
#include <numeric>
class Employee
{
private:
    std::string _name;
    float _salary;

public:
    Employee(std::string name, float salary) : _name(name), _salary(salary) {} // PC
    ~Employee() = default;
    Employee() = default;
    Employee(const Employee &) = delete;
    Employee(Employee &&) = delete;
    Employee operator=(const Employee &) = delete;
    Employee operator=(Employee &&) = delete;

    void setName(const std::string &name) { _name = name; }

    void setSalary(float salary) { _salary = salary; }

    std::string name() const { return _name; }

    float salary() const { return _salary; }
};

using Pointer = std::shared_ptr<Employee>;
using Container = std::unordered_map<int, Pointer>;

void CreateObject(Container &data)
{
    data.emplace(std::make_pair(101, std::make_shared<Employee>("Shubham", 70000)));
    data.emplace(std::make_pair(102, std::make_shared<Employee>("Rohan", 2700)));
    data.emplace(std::make_pair(103, std::make_shared<Employee>("Hetvi", 7670)));
    data.emplace(std::make_pair(104, std::make_shared<Employee>("Shreya", 37637)));
}

// total salary for all employees
void TotalSalary(const Container &data)
{
    if (data.empty())
        throw std::runtime_error("No data exists in Container");

    float total = 0.f;
    for (auto &[k, v] : data)
    {
        total += v->salary();
    }
    // Alternatively total sum

    //     for(auto itr = data.begin(); itr!=data.end();++itr)
    //     {
    //         total = total + itr->second->salary();
    //     }
    //

    std::cout << "\nTotalSalary : " << total;
}
void STL_TotalSalary(const Container &data)
{
    float ans = std::accumulate(data.begin(), data.end(), 0.0f, [](float sum_till_current_value, const std::pair<int, Pointer> &row)
                    { return sum_till_current_value + row.second->salary(); });
    std::cout << "\nSTL_TotalSalary : " << ans;
}
// find the name of employee with the lowest salary;
std::string FindMinSalaryEmployeeName(Container& data)
{
    if (data.empty())
        throw std::runtime_error("No data exists in Container");
    
    /*
        min element will return an iterator to the main element found.
        
    */
   auto itr= std::min_element(data.begin(),data.end(),[](const std::pair<int,Pointer>& Pair1,const std::pair<int,Pointer>& Pair2){
    return Pair1.second->salary() < Pair2.second->salary();
   });
    std::string ans=itr->second->name();
   std::cout<<"\nName of min salary employee is: "<<itr->first<<"\t"<<itr->second->name()<<"\t"<<itr->second->salary();
   return ans;
 
}
std::string FindMaxnSalaryEmployeeName(Container& data)
{
    if (data.empty())
        throw std::runtime_error("No data exists in Container");
    
    /*
        min element will return an iterator to the main element found.
        
    */
   auto itr= std::max_element(data.begin(),data.end(),[](const std::pair<int,Pointer>& Pair1,const std::pair<int,Pointer>& Pair2){
    return Pair1.second->salary() < Pair2.second->salary();
   });
    std::string ans=itr->second->name();
   std::cout<<"\nName of max salary employee is: "<<itr->first<<"\t"<<itr->second->name()<<"\t"<<itr->second->salary();
   return ans;
 
}
 int main()
 {
    Container ptr;
    CreateObject(ptr);
    TotalSalary(ptr);
    STL_TotalSalary(ptr);
    FindMinSalaryEmployeeName(ptr);
    FindMaxnSalaryEmployeeName(ptr);
 }