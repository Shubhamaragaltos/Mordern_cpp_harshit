/*
Scenario 1: A function. I have input before creating thread
            I dont return value
ANSWER:    std::thread should be enough

Scenario 2: A function, I have input before Creating thread
            I want RETURN VALUE
ANSWER:    use std::async without FUTURE INPUT but with a future for return

Scenario 3: A function, I dont have inout before creatinfg thread
            I dont want return
ANSWER:  use std::async with future INPUT and future return type

Scenario 4: A function, I dont have inout before creatinfg thread
ANSWER:  use std::async with future INPUT and future return type

Scenario 5: A function, I have input, I want to start thread using the input
            I want my function to some work but stop or block before completion
            and wait for some event to happen
ANSWER:  Condition variable based code using unique lock






*/