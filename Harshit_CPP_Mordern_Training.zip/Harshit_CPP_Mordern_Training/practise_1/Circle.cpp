#include "Circle.h"

Circle::Circle(int radius): _radius(radius)
{

}

int Circle::Area()
{
    int pi =3.14;
    return pi *(_radius ^ 2);
}