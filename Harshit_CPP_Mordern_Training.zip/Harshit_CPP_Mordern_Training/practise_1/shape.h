#ifndef SHAPE_H
#define SHAPE_H

#include <iostream>

class shape
{
private:
public:
    shape(/* args */) = default;
    shape(const shape &) = delete;
    shape(shape &&) = delete;
    shape &operator=(shape &&) = delete;
    shape &operator=(const shape &) = delete;
    ~shape() = default;
    virtual int Area() = 0;
};

#endif // SHAPE_H
