#ifndef RECTANGLE_H
#define RECTANGLE_H

#include<iostream>
#include"shape.h"

class Rectangle : public shape
{
private:
    int _width{};
    int _height{};

public:
    Rectangle()=default;
    ~Rectangle()=default;
    Rectangle(int width,int height);
    int Area()override;

    int width() const { return _width; }

    int height() const { return _height; }
};

#endif // RECTANGLE_H
