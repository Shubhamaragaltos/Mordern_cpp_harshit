#include<iostream>
#include<vector>
#include"Rectangle.h"
#include"Circle.h"
#include<functional>
#include<memory>

using Pointer = std::shared_ptr<shape>;
using Container = std::vector<Pointer>;
using FNtype = std::reference_wrapper<Container>;

  void  addshape(Container& data);
  void CalculateTotalArea(FNtype& data);
 extern std::function<int(Container&)> Function_area_pointer;




