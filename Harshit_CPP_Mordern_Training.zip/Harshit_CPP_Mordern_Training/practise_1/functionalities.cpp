#include "functionalities.h"

void addshape(Container &data)
{
}

void CalculateTotalArea(FNtype &data)
{
}

std::function<int(Container &)> Function_area_pointer =[](voidContainer& data){ if()

}



