#ifndef CIRCLE_H
#define CIRCLE_H

#include <iostream>
#include "shape.h"
class Circle : public shape
{
private:
    int _radius{};

public:
    Circle() = default;
    ~Circle() = default;
    Circle(int radius);
    int Area() override;

    int radius() const { return _radius; }
};

#endif // CIRCLE_H
