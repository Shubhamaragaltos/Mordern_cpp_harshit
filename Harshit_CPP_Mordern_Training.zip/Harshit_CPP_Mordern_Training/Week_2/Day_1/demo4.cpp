/*
 A container 3 function
 then run a loop over the caotainer to execute the funtion

            DATA
         |    |      |
        F1    F2     F3
         |     |      |
         o1    02    o3



*/
#include <iostream>
#include <functional>
#include <vector>

using FnType = std::function<void(int)>;
using Function_Container = std::vector<FnType>;
using DataCotainer = std::vector<int>;
/*
Accept a blank Conatainer
it will add 3 lambdas into the Container
*/
void MakeLamdaFunction(Function_Container &functions)
{

    functions.emplace_back([](int number)
                           { std::cout << number * number << "\n"; });
    functions.emplace_back([](int number)
                           { std::cout << number * number * number << "\n"; });
    functions.emplace_back([](int number)
                           { std::cout << number * 100 << "\n"; });
    functions.emplace_back([](int number)
                           { std::cout << number * 92 << "\n"; });
}
/*
rune a for each loop on the function conatiner
excute each function with given data
*/

void ApplyLogicOnData(Function_Container &Function, DataCotainer & data)
{
   for(auto  fn:Function)
   {
     for(int n : data)
     {
        fn(n);
     }

   }
    


   
}

int main()
{
    Function_Container functions;
    MakeLamdaFunction(functions);
    DataCotainer fun{10,2,3,40};
    ApplyLogicOnData(functions, fun);
    std::cout<<"\n------------\n";
    // Function_Container ptr;
    // ApplyLogicOnData(ptr,8);
}