#include <iostream>
#include <memory>
#include <vector>
#include <functional>

using Fntype = std::function<void(int)>;
using Function_Container = std::vector<Fntype>;

void CreateObject(Function_Container &data)
{
    data.emplace_back([](int number)
                      { std::cout << "\n"
                                  << number * number; });
    data.emplace_back([](int number)
                      { std::cout << "\n"
                                  << number + number; });

    data.emplace_back([](int number)
                      { std::cout << "\n"
                                  << number - number; });

    data.emplace_back([](int number)
                      { std::cout << "\n"
                                  << number / number; });
}

void ApplyLogicOnData(Function_Container &data, int number = 10)
{
    for (auto Fn : data)
    {
        Fn(number);
    }
}
int main()
{
    Function_Container ptr;
    CreateObject(ptr);
    ApplyLogicOnData(ptr);
    return 0;
}
