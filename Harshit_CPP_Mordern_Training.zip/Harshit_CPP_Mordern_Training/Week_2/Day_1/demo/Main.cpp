#include <iostream>
#include <vector>
#include <functional>
#include"Functionalities.h"



int main()
{
Container_fun f1;
Container_fun f2;
Data_Container d1{2,3,4};

Create_object_stat_A(f1);
operation(f1,d1);
std::cout<<"\n++++++++++++++++++++++++++++++++++++\n";
Create_object_stat_B(f2);
operation(f2,d1);


}