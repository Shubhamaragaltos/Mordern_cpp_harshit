#include"Functionalities.h"

void Create_object_stat_A(Container_fun &data)
{
    data.emplace_back([](int number)
                      { std::cout << number * number << "\n"; });
    data.emplace_back([](int number)
                      { std::cout << number * number * number << "\n"; });

    data.emplace_back([](int number)
                      { std::cout << number * number * number * number << "\n"; });
}
void Create_object_stat_B(Container_fun &data)
{
    data.emplace_back([](int number)
                      { std::cout << number + number << "\n"; });
    data.emplace_back([](int number)
                      { std::cout << number + number + number << "\n"; });

    data.emplace_back([](int number)
                      { std::cout << number + number + number + number << "\n"; });
}

void operation(Container_fun& funtion, Data_Container data) {
    for(auto fn : funtion)
    {
        for(int n:data)
        {
            fn(n);
        
        }
        std::cout<<"\n\n";
    }

}