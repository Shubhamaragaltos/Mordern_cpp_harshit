#include<iostream>


#include <iostream>
#include <vector>
#include <functional>

using Data_Container = std::vector<int>;
using Fn_Type = std::function<void(int)>;
using Container_fun = std::vector<Fn_Type>;

void operation(Container_fun& funtion, Data_Container data);
void Create_object_stat_A(Container_fun &data);
void Create_object_stat_B(Container_fun &data);

