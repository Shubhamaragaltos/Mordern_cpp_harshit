#include <iostream>
#include <functional>
using namespace std::placeholders;
void operation  (std::function<void(int)> logic, int data){
    logic(data);


}


void cube(int number)
{
    std::cout << number * number * number<<"\n";
}
void Ties100(int num)
{
    std::cout<<num*100;
}
int main()
{
    int number =3;

  auto bind_fun = std::bind(operation,([&](){std::cout << number * number<<"\n";},_2));
 // bind_fun(4);
      operation([](int number){std::cout<<number*number*number<<"\n";},3);
    
        
        return 0;
}
