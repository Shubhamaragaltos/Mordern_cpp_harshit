#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include<iostream>
/*
PASCAL CASE : Employee, EmployeeData (Class name)
CAMEL CASE : employeeOfficialName, _id (private data member)
*/

class Employee
{
private:
    int _id;
    std::string _name;

    float _salary;
    
public:
    Employee(int id, std::string name, float salary);
    ~Employee() {}
    int id() const { return _id; }
    void setId(int id) { _id = id; }
    std::string name() const { return _name; }
    void setName(const std::string &name) { _name = name; }

    float salary() const { return _salary; }
    
    /*
    MEMBER FUNCTION = PASCAL CASE
    */
};
#endif // EMPLOYEE_H
