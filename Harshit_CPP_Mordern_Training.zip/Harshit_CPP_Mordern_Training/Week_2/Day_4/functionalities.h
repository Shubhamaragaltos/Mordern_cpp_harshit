#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include <vector>
#include <functional>
#include <memory>
#include "Employee.h"

using Pointer = std::shared_ptr<Employee>;
using Container = std::vector<Pointer>;

void CreateObject(Container& data);

extern std::function<float(Container &)> AverageSalary;


#endif // FUNCTIONALITIES_H
