#include <iostream>
#include "Functionalities.h"

int main()
{
    CarContainer ctr;
    EngineContainer etr;

    CreateObject(ctr, etr);

    for (CarPointer p : ctr)
    {
        std::cout << "\n\n"
                  << *p;
    }
    std::cout << "\n================================================\n";

    std::cout << "\n Find Horse power for ID 102 : " << IDbyEnginType(ctr, 102);

    std::cout << "\n================================================\n";

    std::cout << "\n The average : " << Average(ctr);
}