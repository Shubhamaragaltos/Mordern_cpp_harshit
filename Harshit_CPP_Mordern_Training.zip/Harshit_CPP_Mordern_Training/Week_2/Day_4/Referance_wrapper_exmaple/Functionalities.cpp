#include "Functionalities.h"

void CreateObject(CarContainer &Cardata, EngineContainer &EngineData)
{
    EngineData[0] = std::make_shared<Engine>(200, EngineType::DISEL);
    Cardata[0] = std::make_shared<Car>(101, "Dezire", 182903, EngineData[0]);

    EngineData[1] = std::make_shared<Engine>(288, EngineType::PETROL);
    Cardata[1] = std::make_shared<Car>(102, "Nexon", 1100090, EngineData[1]);

    EngineData[2] = std::make_shared<Engine>(890, EngineType::HYBRID);
    Cardata[2] = std::make_shared<Car>(103, "Lambo", 182903767, EngineData[2]);
}

int Average(CarContainer &Cardata)
{
    int total = 0;
    for (CarPointer p :Cardata)
    {
        total += p->price();
    }
    return total;
}

int IDbyEnginType(CarContainer &Cardata,int ID)
{
    for (CarPointer p :Cardata)
    {
        if(ID==p->id())
        {
            return p->engine().get()->horsePower();

        }
    }
    return 0;
}
