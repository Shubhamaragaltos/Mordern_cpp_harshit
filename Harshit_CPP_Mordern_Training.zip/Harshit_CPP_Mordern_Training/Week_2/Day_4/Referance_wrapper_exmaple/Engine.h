#ifndef ENGINE_H
#define ENGINE_H
#include"EngineType.h"
#include<iostream>
class Engine
{
private:
    int _horsePower;
    EngineType _engineType;

public:
    Engine(int horsepower,EngineType engineType);
    ~Engine()=default;

    int horsePower() const { return _horsePower; }

    EngineType engineType() const { return _engineType; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);
};

#endif // ENGINE_H
