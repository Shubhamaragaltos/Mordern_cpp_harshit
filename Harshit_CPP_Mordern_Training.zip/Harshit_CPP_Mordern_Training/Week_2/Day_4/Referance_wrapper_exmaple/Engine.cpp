#include "Engine.h"

Engine::Engine(int horsepower, EngineType engineType): _horsePower(horsepower), _engineType(engineType)
{
}
std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "_horsePower: " << rhs._horsePower
       << " _engineType: " << static_cast<int>(rhs._engineType);
    return os;
}
