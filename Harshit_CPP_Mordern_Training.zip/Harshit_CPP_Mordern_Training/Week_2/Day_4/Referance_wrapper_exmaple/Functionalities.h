

#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include"Car.h"
#include<memory>
#include<array>

using CarPointer = std::shared_ptr<Car>;
using CarContainer = std::array<CarPointer,3>;
using EnginePointer = std::shared_ptr<Engine>;
using EngineContainer = std::array<EnginePointer,3>;
void CreateObject(CarContainer& Cardata, EngineContainer& EngineData);
int Average(CarContainer& Cardata);
int IDbyEnginType(CarContainer& Cardata,int ID);

#endif // FUNCTIONALITIES_H
