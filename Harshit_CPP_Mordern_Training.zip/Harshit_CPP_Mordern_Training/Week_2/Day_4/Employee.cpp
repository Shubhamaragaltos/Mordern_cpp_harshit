#include "Employee.h"

Employee::Employee(int id, std::string name, float salary):_id(id),_name(name),_salary(salary)
{
}