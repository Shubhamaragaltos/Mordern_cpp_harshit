#include"functionalities.h"

#include<algorithm>
#include<numeric>

std::function<float(Container&)>  AverageSalary = [](Container& data){
 float  total = std::accumulate(data.begin(),data.end(),0,[](float current_result, Pointer& p){return current_result + p->salary();});
    std::cout<<"\nTotal : "<< total<<"\n\n";

    // for(Pointer& ptr : data)
    // {
    //     total +=ptr->salary();
    // }

 return total/data.size();
};
/*Average salaral is function wrapper type which is l value refernce as an input and return float type integer*/

void CreateObject(Container &data)
{
    data.emplace_back(std::make_shared<Employee>(101,"shubham",13400));
      data.emplace_back(std::make_shared<Employee>(111,"shubham",13400));
   data.emplace_back(std::make_shared<Employee>(121,"shubham",13400));
   data.emplace_back(std::make_shared<Employee>(171,"shubham",13400));


}
