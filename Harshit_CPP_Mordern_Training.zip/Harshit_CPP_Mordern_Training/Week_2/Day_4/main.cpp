#include<iostream>
#include"functionalities.h"

int main()
{
    Container ptr;
    CreateObject(ptr);
    float ans=AverageSalary(ptr);
    std::cout<<"\nThe average : "<<ans;
    return 0;
}