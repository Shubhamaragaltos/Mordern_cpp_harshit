#include"functionalities.h"



std::function<float(Container&)>  AverageSalary = [](Container& data){
    float total=0.0f;
    for(Pointer& ptr : data)
    {
        total +=ptr->salary();
    }
    return total;
};
/*Average salaral is function wrapper type which is l value refernce as an input and return float type integer*/

void CreateObject(Container &data)
{
    data.emplace_back(std::make_shared<Employee>(101,"shubham",13400));
      data.emplace_back(std::make_shared<Employee>(111,"rohan",32400));
   data.emplace_back(std::make_shared<Employee>(121,"hetvi",1400));
   data.emplace_back(std::make_shared<Employee>(171,"sherya",1500));


}

void SalaryForGivenID(Container &data, int id)
{
    for(Pointer p: data)
    {
        if(id==p->id())
        {
            std::cout<<"\n The salary: "<<p->salary()<<"\n";
        }
    }
}


