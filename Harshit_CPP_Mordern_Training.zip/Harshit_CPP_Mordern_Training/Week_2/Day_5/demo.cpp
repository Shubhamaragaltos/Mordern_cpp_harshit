#include<iostream>
#include<functional>

int main()
{
}