#include <iostream>
#include <array>
#include <bits/stdc++.h>
int main()
{
    std::array<int, 10> arr1{0}; // initilaise the array ith size 3;

    arr1[0] = 400;
    arr1[1] = 200;
    arr1[2] = 100;

    for (int n : arr1)
    {
        std::cout << n << "\n";
    }
    std::cout << "++++++++++++++\n";
    std::cout << arr1.size() << "\n"; // size of array
    std::cout << "First Number " << arr1.front() << "\n";
    std::cout << "last  Number " << arr1.back() << "\n";
    //  std:: sort(arr1.cbegin(),arr1.cend(),9);

    std::cout << "\n++++++++++++++\n\n";

    // for (int n : arr1)
    // {
    //     std::cout << n << "\n";
    // }

    // int arr2d [3][2]{{70,30},{40,50},{60,27}};
    std::array<std::array<int, 2>, 3> arr2d{
        std::array<int, 2>{70, 30}, std::array<int, 2>{40, 50}, std::array<int, 2>{60, 27}};
    for (std::array<int, 2> &row : arr2d)
    {
        for (int ele : row)
        {
            std::cout << ele << " ";
        }
        std::cout << "\n\n";
    }
    std::cout << "\n++++++++++++++\n\n";

    std::cout <<arr2d[1][0]<<"\n";
}