#include<iostream>
#include"functionalities.h"
using namespace std ::placeholders;

int main()
{
    Container ptr;
    CreateObject(ptr);


    std::cout<<"\nThe average : "<<AverageSalary(ptr);
   auto f1= std::bind(&SalaryForGivenID,_1,_2);
   f1(ptr,121);

    return 0;
}