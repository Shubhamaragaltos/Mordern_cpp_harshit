#include<iostream>
#include<functional>

void magic(std::reference_wrapper<int> n1)
{
    std::cout<<"Address of n1 in magic: "<<n1.get()<<"\n";
}

int main()
{
    int n1=10;
    std::cout<<"Address of n1 in magic"<<&n1<<"\n";
    magic(n1);
}