#include<iostream>
#include<vector>


int main()
{
    int n1=10;
    int& ref1 = n1;
/*
    arr is an array og size 1;
    arr can store 
    */
   //int& arr[1]{ref1};
  // std::vector<int&> v1 {ref1};

   int& ref2 = ref1;

}