#include <iostream>
#include <functional>

auto lfn1 = [](int number){ return number * number; };
using FnType = std::function<int(int)>;
/*
WHAT?
lambdas are callables like regular function (top -leavel function/ global function)

Lamdas have no nam i.e they are anonymous function

WHY?

They help us to pass, recive, store and utilise logic int the
form of an object with proper type system support.

CPP lambdas have concept of capture clause which allows them to act klike closure

*/

/*
  [n1] : Capture n1 only by value;
  [=]: Capture and use all varaibale from surrounding function by value;

  [&n1]: capture n1 by lvalue referance
  [&]: capture and use all varabiles from surrounding fucntion by referance;
  */

 void operation(std::function<void()>f)
 {
    f();
    
{
    int n1 = 100;
    std::cout << lfn1(n1)<<"\n";

    std::array<FnType, 1> arr{lfn1};

    // CAPTURE :
    auto fn = [n1]()
    { std::cout << n1 * n1<<"\n"; };
    fn();
    // MUTABLE:
    auto fn1 = [n1]() mutable
    {n1=99; std::cout << n1 * n1; };
    fn1();
auto fn11 = [&n1]() 
    {n1=2; std::cout <<"\n\n\n\n\n"<< n1 *10; };
  operation(fn11);
  }