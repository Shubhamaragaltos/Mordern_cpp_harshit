#include <curl/curl.h>
#include <string>
#include <iostream>

size_t writeFunction(void *ptr, size_t size, size_t nmemb, std::string *data)
{
    data->append((char *)ptr, size * nmemb);
    return size * nmemb;
}

int main()
{

    auto curl = curl_easy_init();
    if (curl)
    {
        curl_easy_setopt(curl, CURLOPT_URL, "https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD,JPY,EUR");

        std::string response_string;
        std::string header_string;
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeFunction);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_string);
        curl_easy_setopt(curl, CURLOPT_HEADERDATA, &header_string);
        curl_easy_perform(curl);

        char *url{""};
        long response_code{-1};
        double elapsed{-1};
        /*Gather info on response code , store it in response_code variable location
        Similarly we store elapsed time in its respedctive varialbe location*/

        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        curl_easy_getinfo(curl, CURLINFO_TOTAL_TIME, &elapsed);
        curl_easy_getinfo(curl, CURLINFO_EFFECTIVE_URL, &url);

        curl_easy_cleanup(curl);
        curl = NULL;
    

        std::cout << "\n"
                  << response_string << "\n";
        std::cout << "\n\n\n"
                  << response_code << "\n\n\n";
        std::cout << "\n\n\n"
                  << elapsed << "\n\n\n";
    }
        
}