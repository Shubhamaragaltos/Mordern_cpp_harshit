#include<iostream>
#include"AipCaller.h"
#include"Response.h"
#include<memory>


int main()
{
    std::string _end_point = "https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD,JPY,EUR";
    auto api_ptr = std::make_shared<AipCaller>(_end_point);
    api_ptr->ExecuteAPiCall();
    std::cout<<*api_ptr<<"\n";

}