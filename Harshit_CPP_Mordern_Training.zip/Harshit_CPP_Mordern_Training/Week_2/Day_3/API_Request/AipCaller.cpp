#include "AipCaller.h"

AipCaller::AipCaller(std::string url)
    : _end_point(url.c_str()), _curl_session_object_handle(curl_easy_init()), _response{std::make_shared<Response>()}


{

}

AipCaller::AipCaller(std::string url, std::string header)
    : AipCaller(url)
{
    _request_header = header;
}

void AipCaller::ExecuteAPiCall()
{
    curl_easy_setopt(_curl_session_object_handle,CURLOPT_URL,_end_point);

    curl_easy_setopt(_curl_session_object_handle,
                     CURLOPT_WRITEFUNCTION,
                    +[](void *ptr, size_t size, size_t nmemb, std::string *data)
                     { data->append((char *)ptr, size * nmemb); return size * nmemb; });

    curl_easy_setopt(_curl_session_object_handle, CURLOPT_WRITEDATA, &_response);

    curl_easy_setopt(_curl_session_object_handle, CURLOPT_HEADERDATA, &_request_header);
}

std::ostream &operator<<(std::ostream &os, const AipCaller &rhs)
{
    os << "_curl_session_object_handle: " << rhs._curl_session_object_handle
       << " _end_point: " << rhs._end_point
       << " _response: " << rhs._response
       << " _request_header: " << rhs._request_header;
    return os;
}
