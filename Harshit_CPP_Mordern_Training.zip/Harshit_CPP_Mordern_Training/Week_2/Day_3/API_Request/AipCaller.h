#ifndef AIPCALLER_H
#define AIPCALLER_H

#include <iostream>
#include <curl/curl.h>
#include <memory>
#include "Response.h"

class AipCaller
{
private:
    CURL *_curl_session_object_handle{nullptr};
    const char *_end_point{nullptr};
    std::shared_ptr<Response> _response{nullptr};
    std::string _request_header{""};

public:
    AipCaller() = default;
    AipCaller(const AipCaller &) = delete;
    AipCaller(AipCaller &&) = delete;
    AipCaller &operator=(const AipCaller &) = delete;
    AipCaller &operator=(AipCaller &&) = delete;
    ~AipCaller() = default;

    AipCaller(std::string url);
    AipCaller(std::string url, std::string header);

    void ExecuteAPiCall();

    CURL *curlSessionObjectHandle() const { return _curl_session_object_handle; }
    void setCurlSessionObjectHandle(CURL *curl_session_object_handle) { _curl_session_object_handle = curl_session_object_handle; }

  //  char *endPoint() const { return _end_point; }

    std::shared_ptr<Response> response() const { return _response; }
    void setResponse(const std::shared_ptr<Response> &response) { _response = response; }

    std::string requestHeader() const { return _request_header; }
    void setRequestHeader(const std::string &request_header) { _request_header = request_header; }

    friend std::ostream &operator<<(std::ostream &os, const AipCaller &rhs);
};

#endif // AIPCALLER_H
