#include <iostream>

int main()
{
    auto lam =  [i = 0]() mutable { return ++i; };

    auto c1 = lam;

    auto c2 = lam;
    std::cout << c1() << "\n"
              << c1() << "\n"
              << c1() << "\n\n\n\n\n\n";
    std::cout << c2() << "\n"
              << c2() << "\n"
              << c2() << "\n";
}