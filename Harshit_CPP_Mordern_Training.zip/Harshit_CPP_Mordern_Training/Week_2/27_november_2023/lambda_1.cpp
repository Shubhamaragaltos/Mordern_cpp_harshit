#include<iostream>




int main()
{
    auto lam = [](){std::cout<<"\nlambda\n";};

    auto lam1 = std::move(lam);
    lam();
    std::cout<<"\n==============";
    lam1();
    return 0;
}                                                                                                                                         