#include <iostream>
#include <vector>
    int g = 20;

int main()
{

    auto f1 = [=]()
    { return g + 1; };
    auto f2 = [g = g]()
    { return g + 1; };
    // int k=f1(), l=f2();

    std::cout << "\n"
              << f1() << "\n"
              << f2();
    //   std::cout<<"\n"<<k<<"\n"<<l;
    std::cout << "\n==================================\n";
    g = 10;
    std::cout << "\n"
              << f1() << "\n"
              << f2();

    return 0;
}