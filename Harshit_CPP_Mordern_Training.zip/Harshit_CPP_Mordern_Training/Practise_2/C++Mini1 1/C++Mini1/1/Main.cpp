#include "Functionalities.h"

// using Data_Container = std::vector<std::string>;
int main()
{
    Container ptr;
    CreateObjects(ptr);
    Function_Container ftr;
    Functions(ftr);
    ApplyLogicOndata(ftr,ptr);
    

}