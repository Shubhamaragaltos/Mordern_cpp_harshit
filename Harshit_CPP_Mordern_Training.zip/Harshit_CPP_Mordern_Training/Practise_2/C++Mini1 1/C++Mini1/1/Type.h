#ifndef TYPE_H
#define TYPE_H

enum class Type
{
    PAID=1,
    COD,
    PROMOTION
};

#endif // TYPE_H
