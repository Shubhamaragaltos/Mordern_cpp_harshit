#include <iostream>
#include <memory>
#include <functional>

int main()
{
    std::shared_ptr<int> p = std::make_shared<int>(5);
    std::reference_wrapper<std::shared_ptr<int>> R();
    std::cout << R().get();
}