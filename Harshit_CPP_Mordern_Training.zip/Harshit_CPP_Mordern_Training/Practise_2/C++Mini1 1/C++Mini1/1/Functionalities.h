#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Order.h"
#include <vector>
#include<functional>

using Pointer = std::shared_ptr<Order>;
using Container = std::vector<Pointer>;
using Fntype = std::function<void(Container&)>;
using Function_Container = std::vector<Fntype>;
using Refttyp = std::reference_wrapper<Pointer>;



// Functioanlities
void CreateObjects(Container &data);
void Functions(Function_Container& function );
void ApplyLogicOndata(Function_Container& function, Container &data);

#endif // FUNCTIONALITIES_H
