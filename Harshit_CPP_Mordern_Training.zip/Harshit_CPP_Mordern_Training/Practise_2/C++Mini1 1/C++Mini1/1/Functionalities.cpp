#include "Functionalities.h"

void CreateObjects(Container &data)
{
    // Putting data in the container
    data.emplace_back(
        std::make_shared<Order>(
            "ID1",
            100.5,
            Type::COD,
            10.5));
    data.emplace_back(
        std::make_shared<Order>(
            "ID2",
            200.5,
            Type::PAID,
            20.5));
    data.emplace_back(
        std::make_shared<Order>(
            "ID3",
            300.5,
            Type::PROMOTION,
            30.5));
    data.emplace_back(
        std::make_shared<Order>(
            "ID4",
            400.5,
            Type::PAID,
            40.5));
    data.emplace_back(
        std::make_shared<Order>(
            "ID5",
            1000.5,
            Type::COD,
            50.5));

                 for (Refttyp p : data)           
                {
                    if (1)
                    {
                        std::cout << p.get()->discount() <<"\n";
                    }
                }
}

void Functions(Function_Container &function)
{

    // Find ID  with Height Discount
    function.emplace_back([](Container &data)
                          {
                              auto itr = data.begin();
                              int max = (*itr)->discount();
                              std::string ans{};

                              for (Pointer p : data)
                              {
                                  if (max < p->discount())
                                  {
                                      max = p->discount();
                                      ans = p->id();
                                  }
                              }
                               std::cout << "\n The ID with Maximum Discout is : " << ans;
                              
                          });

    function.emplace_back([](Container &data)
                          {
                           std::string idx = "ID2";
                              for (Pointer p : data)
                              {
                                  if (p->id() == idx)
                                  {
                                    std::cout<<static_cast<int>(p->type());
                                      
                                  }
                              } });

    function.emplace_back([](Container &data)
                          {
                            int n=3;
                              for (Pointer i : data)
                              {
                                    if(n>0)
                                    {
                                  std::cout << *i<<"\n\n";
                                  n--;
                                    }
                              } });
                              
}

void ApplyLogicOndata(Function_Container &function, Container &data)
{
    for (auto fn : function)
    {
        fn(data);
        std::cout << "\n"
                  << "<<+++++++++++++++++++++++++++++++++++++++"
                  << "\n";
    }
}
