#ifndef DEVICE_H
#define DEVICE_H

#include <iostream>
#include<memory>
#include "DeviceType.h"
#include "DeviceDriver.h"
#include <functional>
using  Ref_Pointer = std::shared_ptr<DeviceDriver>;
using  Ref_DeviceDriver = std::reference_wrapper<Ref_Pointer>;


class Device
{
private:
    std::string _device_id;
    DeviceType _device_type;
    int _device_battery_level;
    Ref_DeviceDriver _device_driver;

public:
    Device(std::string device_id,DeviceType type,int level,Ref_DeviceDriver _device_driver);
    ~Device()=default;

    //Disabled functions
    Device()=default;
    Device(const Device&)=delete;
    Device(Device&&)=delete;
    Device operator=(const Device&)=delete;
    Device operator=(Device&&)=delete;

    //member functions
    float _battery_drain_factor();

    std::string deviceId() const { return _device_id; }

    DeviceType deviceType() const { return _device_type; }

    int deviceBatteryLevel() const { return _device_battery_level; }

    Ref_DeviceDriver deviceDriver() const { return _device_driver; }


    friend std::ostream &operator<<(std::ostream &os, const Device &rhs);
};



#endif // DEVICE_H
