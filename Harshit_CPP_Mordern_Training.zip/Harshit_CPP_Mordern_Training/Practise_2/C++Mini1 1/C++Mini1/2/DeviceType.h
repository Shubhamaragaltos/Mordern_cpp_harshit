#ifndef DEVICETYPE_H
#define DEVICETYPE_H

enum class DeviceType
{
    INFOTAINMENT,
    ACCESSORY,
    SAFETY
};

#endif // DEVICETYPE_H
