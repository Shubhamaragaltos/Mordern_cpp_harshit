#include "Device.h"

Device::Device(std::string device_id, DeviceType type, int level, Ref_DeviceDriver Driver)
:_device_id(device_id),_device_type(type),_device_battery_level(level),_device_driver(Driver)
{
}

float Device::_battery_drain_factor()
{
    if(_device_type==DeviceType::INFOTAINMENT||_device_type==DeviceType::ACCESSORY)
        return 0.25;
    if(_device_type==DeviceType::SAFETY){
        if(_device_battery_level>50)
            return 0.5;
        else
            return 0.4;
    }
    return 0;
        
    
}

std::ostream &operator<<(std::ostream &os, const Device &rhs) {
    os << "_device_id: " << rhs._device_id
       << " _device_type: " << static_cast<int>(rhs._device_type)
       << " _device_battery_level: " << rhs._device_battery_level
       << " _device_driver: " << *(rhs._device_driver.get());
    return os;
}
