#include "Functionalities.h"

void CreateObjects(Container &data, DeviceDriverContainer &drdata)
{
    drdata.emplace_back(std::make_shared<DeviceDriver>("Version1", ReleaseQuarter::Q2, 11));
    drdata.emplace_back(std::make_shared<DeviceDriver>("Version3", ReleaseQuarter::Q3, 90));
    drdata.emplace_back(std::make_shared<DeviceDriver>("Version4", ReleaseQuarter::Q4, 120));
    drdata.emplace_back(std::make_shared<DeviceDriver>("Version5", ReleaseQuarter::Q2, 50));
    drdata.emplace_back(std::make_shared<DeviceDriver>("Version2", ReleaseQuarter::Q1,10));

    data.emplace_back(
        std::make_shared<Device>(
            "ID1",
            DeviceType::ACCESSORY,
            75, drdata[0]));

    data.emplace_back(
        std::make_shared<Device>(
            "ID2",
            DeviceType::SAFETY,
            65,
            drdata[1]));

    data.emplace_back(
        std::make_shared<Device>(
            "ID3",
            DeviceType::INFOTAINMENT,
            85,
            drdata[2]));
    data.emplace_back(
        std::make_shared<Device>(
            "ID4",
            DeviceType::INFOTAINMENT,
            15,
            drdata[3]));
    data.emplace_back(
        std::make_shared<Device>(
            "ID5",
            DeviceType::SAFETY,
            45,
            drdata[4]));

    for (auto p : data)
    {
        std::cout << *p << "\n";
    }
    
}

 std::function<void(Container &data)> IDAboveDrainFactor = [](Container &data)

{
    if (data.empty())
        throw std::runtime_error("No data exists in Container");
    for (const Pointer &ptr : data)
    {
        if (ptr->_battery_drain_factor() > 0.3)
        {
            std::cout << "\nThe Device id : " << ptr->deviceId();
        }
    }
};

 std::function<void(Container &data)> AverageSizeInBytes = [](Container &data)
{
    if (data.empty())
        throw std::runtime_error("No data in Container");
    float sum = 0, count = 0;
    for (Pointer &ptr : data)
    {
        if (ptr->deviceDriver().get()->releaseQuarter() == ReleaseQuarter::Q1 || ptr->deviceDriver().get()->releaseQuarter() == ReleaseQuarter::Q4)
        {
            sum += ptr->deviceDriver().get()->sizeInBytes();
            count++;
        }
    }
    std::cout << "\nThe Average Size Bytes :" << sum / count;
};

 std::function<void(Container &data, float key)> FindVersionNumber = [](Container &data, float key)
{
    if (data.empty())
        throw std::runtime_error("No data in Container");
    for ( Pointer &ptr : data)
    {
        
        if (ptr->deviceDriver().get()->sizeInBytes() == key)
          std::cout << "\n Version Number for Given size bytes : " << ptr->deviceDriver().get()->versionNumber();
    }

};

 std::function<void(Container &data, DeviceType type)> FindDriverInstances = [](Container &data, DeviceType type)
{
    if (data.empty())
        throw std::runtime_error("No data in Container");
    for (const Pointer &ptr : data)
    {
        if (ptr->deviceType() == type)
        {
            std::cout << "\nThe Device Driver : " << *(ptr->deviceDriver().get());
        }
        
    }
};
