#ifndef RELEASEQUARTER_H
#define RELEASEQUARTER_H

enum class ReleaseQuarter
{
    Q1,
    Q2,
    Q3,
    Q4
};

#endif // RELEASEQUARTER_H
