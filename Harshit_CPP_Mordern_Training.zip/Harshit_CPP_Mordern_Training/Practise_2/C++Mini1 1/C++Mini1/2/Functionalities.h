#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Device.h"
#include "DeviceDriver.h"
#include <vector>
#include<functional>

using Pointer = std::shared_ptr<Device>;
using Container = std::vector<Pointer>;


using DeviceDriverContainer = std::vector<Ref_Pointer>;

using Fntyp = std::function<void(Container&)>;

void CreateObjects(Container &data,DeviceDriverContainer& drdata);
extern std::function<void(Container &data)> IDAboveDrainFactor;
extern std::function<void(Container &data)>AverageSizeInBytes;
extern std::function<void(Container &data,float key)> FindVersionNumber;
extern std::function<void(Container &data,DeviceType type)> FindDriverInstances;

#endif // FUNCTIONALITIES_H
