#include"Vehicle.h"
#include"HybridCar.h"

std::ostream &operator<<(std::ostream &os, const HybridCar &rhs) {
    os << static_cast<const Vehicle &>(rhs)
       << " _fuel_tank_capacity: " << rhs._fuel_tank_capacity
       << " _battery_capacity: " << rhs._battery_capacity;
    return os;
}

HybridCar::HybridCar(int id, std::string name, float price, VehicleType type, int fuel_cap, int battery_cap)
    : Vehicle(id, name, price, type), _fuel_tank_capacity(fuel_cap), _battery_capacity(battery_cap)
{
}

HybridCar::HybridCar(int id, std::string name, VehicleType type, int fuel_cap, int battery_cap)
    : Vehicle(id, name, type), _fuel_tank_capacity(fuel_cap), _battery_capacity(battery_cap)
{
}

void HybridCar::CalculateRegistrationCharge()
{
    std :: cout << "\nTax for HybribCar is 11% "<< 0.1f * price()<<"\n";
}
