#include "Functionalities.h"
#include "PetrolCar.h"
#include "DieselCar.h"
#include "EvCar.h"
#include "HybridCar.h"
#include"memory"
#include<iostream>

void CreateObjects(Container &data)
{
    //step 1 : make a constructor call to petrotcar

    // std::shared_ptr<PetrolCar>(101, "city", 140000.0f, VehicleType :: PERSONAL, 43);

    // std :: shared_ptr<Vehicle> ptr = std::make_shared<PetrolCar>(101, "city", 140000.0f, VehicleType :: PERSONAL, 43);

    // data.emplace_back(
    //    ptr
    //);


    data.emplace_back(
        std::make_shared<PetrolCar>(101, "city", 140000.0f, VehicleType :: PERSONAL, 43)
    );

    data.emplace_back(
        std::make_shared<PetrolCar>(106, "Dzire", 200000.0f, VehicleType :: PERSONAL, 43)
    );

    data.emplace_back(
        std::make_shared<PetrolCar>(104, "Baleno", 950000.0f, VehicleType :: PERSONAL, 44)
    );

    data.emplace_back(
        std::make_shared<DieselCar>(204, "Manza", 500000.0f, VehicleType :: PERSONAL, 48)
    );

    data.emplace_back(
        std::make_shared<DieselCar>(201, "Verna", 500000.0f, VehicleType :: PERSONAL, 47)
    );

    data.emplace_back(
        std::make_shared<DieselCar>(204, "Nexon", 950000.0f, VehicleType :: PERSONAL, 48)
    );

    data.emplace_back(
        std::make_shared<EvCar>(304, "Nexon", 100000.0f, VehicleType :: PERSONAL, 80)
    );

    data.emplace_back(
        std::make_shared<EvCar>(308, "Renault", 800000.0f, VehicleType :: PERSONAL, 40)
    );

    data.emplace_back(
        std::make_shared<EvCar>(309, "Tesla", 960000.0f, VehicleType :: PERSONAL, 98)
    );


    data.emplace_back(
        std::make_shared<HybridCar>(402, "Prius", 2870000.0f, VehicleType :: PERSONAL, 30, 70)
    );


    data.emplace_back(
        std::make_shared<HybridCar>(412, "Escape", 3220000.0f, VehicleType :: PERSONAL, 40, 75)
    );


    data.emplace_back(
        std::make_shared<HybridCar>(416, "Fusion", 100000.0f, VehicleType :: PERSONAL, 40, 80)
    );
}

void regist(Container &data)
{
    for(Pointer P :data)
    {
      P->CalculateRegistrationCharge();
    }
}

float AveragePrice(Container &data)
{
    return 0.0f;
}

