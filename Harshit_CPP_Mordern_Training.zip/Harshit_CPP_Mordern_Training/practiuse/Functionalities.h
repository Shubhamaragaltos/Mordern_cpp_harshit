#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <memory>
#include <vector>
#include "Vehicle.h"

// Step 1: create a alias "Pointer" which is an alternate name
// for std :: shared_ptr<Vehicle>
using Pointer = std ::shared_ptr<Vehicle>;

// step 2 : now specify alternate container which indicates
//  a standard vector of "Pointer" where Pointer is explained above
using Container = std ::vector<Pointer>;

void CreateObjects(Container& data);
void regist(Container& data);
float AveragePrice(Container& data);

#endif // FUNCTIONALITIES_H
