#include"Vehicle.h"
#include"DieselCar.h"

std::ostream &operator<<(std::ostream &os, const DieselCar &rhs) {
    os << static_cast<const Vehicle &>(rhs)
       << " _fuel_tank_capacity: " << rhs._fuel_tank_capacity;
    return os;
}

DieselCar::DieselCar(int id, std::string name, float price, VehicleType type, int capacity)
    : Vehicle(id, name, price, type), _fuel_tank_capacity(capacity) 
{
}

DieselCar::DieselCar(int id, std::string name, VehicleType type, int capacity)
    : Vehicle(id, name, type), _fuel_tank_capacity(capacity)
{
}

void DieselCar::CalculateRegistrationCharge()
{
    std :: cout << "\nTax of Diesel Car is 12%: " << 0.2f * price();
}
