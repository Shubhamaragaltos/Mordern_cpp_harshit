#include "Functionalities.h"
#include "PetrolCar.h"
#include "DieselCar.h"
#include "EvCar.h"
#include "HybridCar.h"
#include "VehicleType.h"
#include"memory"
#include<iostream>

int main(){
        
    Container data;
    CreateObjects(data);
    // for(int i = 0; i<12; i++){
    //     std::cout<<"\n"<<*(data[i]);
    // }

    for(const auto& dis: data){
        std :: cout << *dis<<"\n\n";
    }
std::cout<<"\n======================================\n";

regist(data);
}