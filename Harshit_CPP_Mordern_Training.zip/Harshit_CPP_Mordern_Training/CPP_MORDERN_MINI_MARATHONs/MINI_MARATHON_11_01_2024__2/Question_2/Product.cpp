#include "Product.h"


Product::Product(std::string productID, std::string Productbrand, 
                  int productvale, ProductType ptype, ProductOrigin origintype):
      _productID(productID), _Product_brand(Productbrand), _product_vale(productvale),
      _ptype(ptype), _origin_type(origintype) {
         _productTaxAmount = (5 *_product_vale)/100;
      }


std::ostream &operator<<(std::ostream &os, const Product &rhs) {
    os << "_productID: " << rhs._productID
       << " _product_vale: " << rhs._product_vale
       << " _ptype: " << static_cast<int>(rhs._ptype)
       << " _origin_type: " << static_cast<int>(rhs._origin_type)
       << " _productTaxAmount: " << rhs._productTaxAmount
       << "_Product_brand: " << rhs._Product_brand;
    return os;
}

