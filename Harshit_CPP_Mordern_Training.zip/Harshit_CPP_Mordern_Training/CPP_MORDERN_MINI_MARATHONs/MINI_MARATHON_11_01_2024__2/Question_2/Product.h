#ifndef PRODUCT_H
#define PRODUCT_H

#include <iostream>
#include"ProductOrigin.h"
#include"ProductType.h"

class Product
{
private:
    std::string _productID;
    std::string _Product_brand;
    int _product_vale;
    ProductType _ptype;
    ProductOrigin _origin_type;
    float _productTaxAmount;

public:
    Product(std::string productID, std::string Productbrand, int productvale, ProductType ptype, ProductOrigin origintype);

   
   
    ~Product() = default;
    Product() = default;
    Product(const Product &) = delete;
    Product(Product &&) = delete;
    Product operator=(const Product &) = delete;
    Product operator=(Product &&) = delete;

    std::string productID() const { return _productID; }

    float productVale() const { return _product_vale; }

    ProductType ptype() const { return _ptype; }

    ProductOrigin originType() const { return _origin_type; }

    float productTaxAmount() const { return _productTaxAmount; }

    std::string productBrand() const { return _Product_brand; }

    friend std::ostream &operator<<(std::ostream &os, const Product &rhs);

    
};

#endif // PRODUCT_H
