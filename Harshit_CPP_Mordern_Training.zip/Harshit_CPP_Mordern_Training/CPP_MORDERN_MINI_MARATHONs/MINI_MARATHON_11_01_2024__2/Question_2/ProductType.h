#ifndef PRODUCTTYPE_H
#define PRODUCTTYPE_H

enum class ProductType{
    FOOD, PERFUME, APPLIANCE

};

#endif // PRODUCTTYPE_H
