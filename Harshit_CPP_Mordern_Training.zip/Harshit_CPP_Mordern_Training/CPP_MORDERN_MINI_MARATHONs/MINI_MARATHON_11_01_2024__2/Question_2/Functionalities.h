#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include<functional>
#include"Product.h"
#include<memory>
#include<set>
#include<algorithm>
#include<numeric>
#include<bits/stdc++.h>

using Pointer = std::shared_ptr<Product>;
using Container = std::vector<Pointer>;


void CreateObject(Container& data);

extern std::function<float(Container& data, ProductType Type)> AverageProductPrice;
extern std::function<float(Container& data)> MaximumProductTaxAmount;
extern std::function<Container(Container& data, int N)> N_Instance;
extern std::function<Container(Container &data)> UnquieProductBrand;
extern std::function<Pointer(Container& data, std::string Brand)> ProductInstanceByBrand;
// //extern std::function<int(Container& data)> ArrayOFinteger;



#endif // FUNCTIONALITIES_H
