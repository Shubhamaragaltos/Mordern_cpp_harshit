
#include "Functionalities.h"

int main()
{

        Container ptr;

        CreateObject(ptr);
        std::cout << "\n\n===================================================================================\n\n";

        std::cout << "\nThe Average:  " << AverageProductPrice(ptr, ProductType::APPLIANCE) << std::endl;
        std::cout << "\n\n===================================================================================\n\n";

        std::cout << "\n Tax Amount : " << MaximumProductTaxAmount(ptr);
        std::cout << "\n\n===================================================================================\n\n";

        Pointer p = ProductInstanceByBrand(ptr, "AMI");

        std::cout << "\n"
                  << *p;
        std::cout << "\n\n===================================================================================\n\n";

        Container ans = N_Instance(ptr, 1);
        for (auto p : ans)
        {
                std::cout << "\n"
                          << *p;
        }

        std::cout << "\n\n============UNQUIE=======================================================================\n\n";

        UnquieProductBrand(ptr);
}