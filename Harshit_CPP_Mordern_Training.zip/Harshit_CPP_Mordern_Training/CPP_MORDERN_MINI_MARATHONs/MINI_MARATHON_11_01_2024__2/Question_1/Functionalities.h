#include <iostream>
#include <functional>


auto SumOfValuesOfRows=[] (int** Arr,int row, int col)
{
   // std::array<std::array<int,2>,2> Arr= trr.get();
    
      for (int i = 0; i < row; i++)
    {
             int start=0;

            for (int j = 0; j < col; j++)
            {
               start += Arr[i][j];
            }
            std::cout<<start<<"\n";
            
    } };

 auto HigestValue = [] ( std::reference_wrapper<std::array<std::array<int,2>,2>> trr,int row, int col)
{
    std::array<std::array<int,2>,2> Arr= trr.get();
    int max = Arr[0][0];
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            if (max < Arr[i][j])
            {
                max = Arr[i][j];
            }
        }
    }
    std::cout << "\n The maximum number : " << max << "\n";
};

auto SquareValueLastNumber = [] ( std::reference_wrapper<std::array<std::array<int,2>,2>> trr,int row, int col)
{
    std::array<std::array<int,2>,2> Arr= trr.get();
    int square = Arr[row - 1][col - 1];
    std::cout << "\nThe Square of last number : " << square*square;
};

auto Maximum_number_colum = [] ( std::reference_wrapper<std::array<std::array<int,2>,2>> trr,int row, int col)
{
    std::array<std::array<int,2>,2> Arr= trr.get();
      for (int i = 0; i < col; i++)
    {
        int max=Arr[i][0];
            for (int j = 0; j < row; j++)
            {
               if(max<Arr[i][j])
               {
                    max=Arr[i][j];
               }
            }
            std::cout<<"\nThe Highes value in column : "<<max<<"\n";
            
    } };

