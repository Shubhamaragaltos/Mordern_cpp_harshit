#include <iostream>
#include "Functionalities.h"
#include <array>

int main()
{
    int N_row = 2, N_col = 2;

 

 // std::array<std::array<int,2>,2> RXC;
  int RXC[N_row][N_col];


    for (int i = 0; i < N_row; i++)
    {
        for (int j = 0; j < N_col; j++)
        {
            std::cin >> RXC[i][j];
        }
    }

    for (int i = 0; i < N_row; i++)
    {
        for (int j = 0; j < N_col; j++)
        {
            std::cout << RXC[i][j] << "\t";
        }
        std::cout << "\n";
    }
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

   std::cout<<"\nThe sum of : "; 
   SumOfValuesOfRows(RXC, N_row, N_col);

    // SquareValueLastNumber(RXC, N_row, N_col);
    //  HigestValue(RXC, N_row, N_col);
    // Maximum_number_colum(RXC, N_row, N_col);

}