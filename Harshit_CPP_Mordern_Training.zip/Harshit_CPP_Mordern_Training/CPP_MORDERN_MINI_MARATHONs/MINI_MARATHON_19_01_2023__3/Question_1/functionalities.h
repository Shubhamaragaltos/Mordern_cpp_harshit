#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include <iostream>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <future>
#include <vector>

bool flag_1 = false;
bool flag = false;

int FirstNum = 0, SecondNum = 0;
std::condition_variable cv;
std::mutex mt;

void SumOfTwoNumber()
{
    std::unique_lock<std::mutex> ul(mt);

    cv.wait(ul, []()
            { return flag; });

    std::cout

        << "\n SUM of TWO NUMBER : " << FirstNum + SecondNum << "\n";
}

int SumOFNnumbers(std::future<int> &ft)
{
    int N = ft.get();
    int ans = 0;
    for (int i = 0; i < N; i++)
    {
        ans += i;
    }

    return ans;
}
void PrintOddNumber(std::vector<int> Num)
{
    std::cout << "\n Odd numbers or given Vector:";
    for (auto &&i : Num)
    {
        if (i % 2 != 0)
        {
            std::cout << "\t" << i;
        }
    }
}

void JoinThread(std::array<std::thread, 1> &threadArr)
{
    for (std::thread &t : threadArr)
    {
        if (t.joinable())
        {
            t.join();
        }
    }
}




#endif // FUNCTIONALITIES_H
