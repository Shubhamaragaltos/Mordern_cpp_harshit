#include "functionalities.h"
#include <array>

// extern  int FirstNum=0, SecondNum=0;

int main()
{
    std::array<std::thread, 1> threadARR;
    ////////////////////////////////////

    std::cout << "\n----------SUM OF TWO NUMBER-------\n \n";

    std::thread t1(&SumOfTwoNumber);

    std::cout << "\nEnter the First and Second Number: \n";
    std::cin >> FirstNum >> SecondNum;
    flag = true;
    cv.notify_all();
    t1.join();

    ////////////////////////////////////
    std::cout << "\n----------SUM OF N NUMBER-------\n \n";

    std::promise<int> pr;

    std::future<int> ft = pr.get_future();

    std::future<int> result_ft = std::async(std::launch::async, &SumOFNnumbers, std::ref(ft));

    int N = 0;
    std::cout << "\n Enter the Number : ";
    std::cin >> N;
    pr.set_value(N);
    std::cout << "\nThe Sum of first N numbers : " << result_ft.get();

    //////////////////////////////////////////////////////////////

    std::array<std::thread, 1> ThreaddArr;
    std::cout << "\n\n----------ODD number-------\n \n";
    std::vector<int> Numbers{1, 2, 3, 4, 5, 6, 7, 8, 9};

    ThreaddArr[0] = std::thread(PrintOddNumber, Numbers);
    JoinThread(ThreaddArr);
    std::cout<<"\n\n\n";

    ///////////////////////////////////////////////////
}