#ifndef CARTYPE_H
#define CARTYPE_H

  enum class CarType
  {
    REGULAR, TRANSPORT
  };


#endif // CARTYPE_H
