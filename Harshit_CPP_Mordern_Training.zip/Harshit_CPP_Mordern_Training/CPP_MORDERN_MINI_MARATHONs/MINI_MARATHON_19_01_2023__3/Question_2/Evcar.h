#ifndef EVCAR_H
#define EVCAR_H

#include"Automobile.h"

class EvCar: public Automobile
{
private:
int _battery_capacity;
public:
EvCar(int id, CarType type, float price, int seatcount, int enginehorsepower, int batterycapacity);//PC
~EvCar()=default;
EvCar()=default;
EvCar(const EvCar&)=delete;
EvCar(EvCar&&)=delete;
EvCar operator=(const EvCar&)=delete;
EvCar operator=(EvCar&&)=delete;
 int CalculateGST()override;

int batteryCapacity() const { return _battery_capacity; }
};

#endif // EVCARH
