#ifndef FUNCTIONALITES_H
#define FUNCTIONALITES_H

#include"Evcar.h"
#include<vector>
#include<memory>
#include<variant>
#include<thread>
#include<future>
#include <mutex>

using Automobile_Pointer = std::shared_ptr<Automobile>;
using  Container = std::vector<Automobile_Pointer>;

void CreateObject(Container& data);
void FindSeatCount(Container &data,std::future<int> &ft);
void FindInstanceBelow600(Container & data);
void AveragePriceDisplay(Container& data);
void SumOftotalCalculateGST(Container& data);


#endif // FUNCTIONALITES_H
