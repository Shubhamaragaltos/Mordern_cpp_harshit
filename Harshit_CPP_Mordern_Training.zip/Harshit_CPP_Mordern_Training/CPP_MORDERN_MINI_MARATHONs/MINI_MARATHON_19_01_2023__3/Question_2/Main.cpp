#include <iostream>
#include "Functionalites.h"
#include <thread>

int main()
{
    Container ptr;
    std::thread t1(CreateObject, std::ref(ptr));
    t1.join();

    //////////////////////////////////////////////////////////////////////////////
    std::promise<int> pr;

    std::future<int> ft = pr.get_future();

    std::future<void> result_ft = std::async(std::launch::async, &FindSeatCount, std::ref(ptr), std::ref(ft));

    int ID = 0;
    std::cout << "\n Enter the ID : ";
    std::cin >> ID;
    pr.set_value(ID);
    result_ft.get();

    // // ////////////////////////////////////////////////////////////////////////////////////
    
    ////////////////////////////////////////////////////////////////////////////////////
    
    ////////////////////////////////////////////////////////////////////////////////////
    std::thread t4(AveragePriceDisplay, std::ref(ptr));
    t4.join();
    ////////////////////////////////////////////////////////////////////////////////////
    std::thread t5(SumOftotalCalculateGST, std::ref(ptr));
    t5.join();

    std::cout<<"\n+++++++++++++++++++++\n\n\n";
}
    
