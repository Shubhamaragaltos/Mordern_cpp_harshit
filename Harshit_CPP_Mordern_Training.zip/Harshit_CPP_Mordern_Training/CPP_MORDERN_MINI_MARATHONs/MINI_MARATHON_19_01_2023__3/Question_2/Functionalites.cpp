#include "Functionalites.h"

void CreateObject(Container &data)
{
    data.emplace_back(std::make_shared<Automobile>(1, CarType::REGULAR, 599999, 4, 300));
    data.emplace_back(std::make_shared<Automobile>(2, CarType::TRANSPORT, 7935567, 34, 1300));
    data.emplace_back(std::make_shared<Automobile>(3, CarType::REGULAR, 1000000, 7, 500));
    data.emplace_back(std::make_shared<EvCar>(4, CarType::REGULAR, 6788000, 6, 500, 80));
    data.emplace_back(std::make_shared<EvCar>(5, CarType::TRANSPORT, 9800000, 30, 700, 100));
}

void FindSeatCount(Container &data,std::future<int> &ft)
{
    if (data.empty())
        throw std::runtime_error("No data exists in Container");

    int id = ft.get();
         for (auto p : data)           
        {
            if (p->id()==id)
            {
                std::cout << "\n The Seat count for Given ID : "<<p->seatCount()<<"\n";
            }
        }


}
void FindInstanceBelow600(Container &data)
{
    std::cout<<"\nThe Instance below 600 horsepower: \n";
         for (auto p : data)           
        {
            if (p->engineHorsepower()<600)
            {
                std::cout << *p<< std::endl;
            }
        }
}

void AveragePriceDisplay(Container &data)
{
    float total=0, count=0;
         for (auto p : data)           
        {
            //if (auto ptrl = std::dynamic_pointer_cast<Automobile>(p))
                if( p->batteryCapacity())
        
            {
                std::cout<<"\n\n=======================n\n";
                std::cout<<*p<<std::endl;
                total += p->price(); 
                count++;
            }
        }
    std::cout<<"\nThe Average Price For Automobile: "<<total/count;
}

void SumOftotalCalculateGST(Container &data)
{
    float sum=0;

         for (auto p : data)           
        {
            sum+=p->CalculateGST();
        }
    std::cout<<"\n Total GST : "<<sum;
}
