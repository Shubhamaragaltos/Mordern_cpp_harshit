#include "Automobile.h"

Automobile::Automobile(int id, CarType type, float price, int seatcount, int enginehorsepower)
: _id(id),_type(type),_price(price),_seat_count(seatcount),_engine_horsepower(enginehorsepower)
{
}
int Automobile::CalculateGST()
{
    return _price*0.18;
}
std::ostream &operator<<(std::ostream &os, const Automobile &rhs)
{
    os << "_id: " << rhs._id
       << " _type: " << static_cast<int>( rhs._type)
       << " _price: " << rhs._price
       << " _seat_count: " << rhs._seat_count
       << " _engine_horsepower: " << rhs._engine_horsepower;
    return os;
}
