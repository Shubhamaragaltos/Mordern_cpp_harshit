#include "Evcar.h"

EvCar::EvCar(int id, CarType type, float price, int seatcount, int enginehorsepower, int batterycapacity):
Automobile(id,type,price,seatcount,enginehorsepower) , _battery_capacity(batterycapacity)
{
}

int EvCar::CalculateGST()
{
        return price() * 0.10;

}
