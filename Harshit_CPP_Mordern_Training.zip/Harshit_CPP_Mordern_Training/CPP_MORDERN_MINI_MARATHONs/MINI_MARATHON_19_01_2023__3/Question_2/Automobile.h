#ifndef AUTOMOBILE_H
#define AUTOMOBILE_H

#include"CarType.h"
#include<iostream>
class Automobile
{
private:
int _id;
CarType _type;
float _price;
int _seat_count;
int _engine_horsepower;



public:
Automobile(int id, CarType type, float price, int seatcount, int enginehorsepower );//PC
~Automobile()=default;
Automobile()=default;
Automobile(const Automobile&)=delete;
Automobile(Automobile&&)=delete;
Automobile operator=(const Automobile&)=delete;
Automobile operator=(Automobile&&)=delete;
virtual int CalculateGST();
int id() const { return _id; }

CarType type() const { return _type; }

int seatCount() const { return _seat_count; }

float price() const { return _price; }

int engineHorsepower() const { return _engine_horsepower; }

friend std::ostream &operator<<(std::ostream &os, const Automobile &rhs);
};

#endif // AUTOMOBILE_H
