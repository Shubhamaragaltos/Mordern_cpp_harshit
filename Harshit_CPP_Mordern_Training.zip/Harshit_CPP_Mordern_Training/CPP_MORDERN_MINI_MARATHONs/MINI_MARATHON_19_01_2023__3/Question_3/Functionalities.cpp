#include "Functionalities.h"
#include <set>
#include<algorithm>
#include<numeric>
#include<queue>
#include <string_view>

void CreateObject(Container &data)
{
    data.emplace_back(std::make_shared<Passenger>(1, "shubham", 23, 180, std::make_shared<Ticket>(18, TicketType::GENRAL)));
    data.emplace_back(std::make_shared<Passenger>(2, "Harshit", 27, 280, std::make_shared<Ticket>(27, TicketType::GENRAL)));

    data.emplace_back(std::make_shared<Passenger>(3, "hetvi", 22, 190, std::make_shared<Ticket>(12, TicketType::RESERVED)));

    data.emplace_back(std::make_shared<Passenger>(4, "rohan", 33, 100, std::make_shared<Ticket>(11, TicketType::RESERVED)));

    data.emplace_back(std::make_shared<Passenger>(5, "kiran", 13, 170, std::make_shared<Ticket>(13, TicketType::GENRAL)));

    std::cout<<"\n All data stored\n\n";
         for (auto p : data)           
        {
            if (1)
            {
                std::cout << *p<< std::endl;
            }
        }
}

void FindAverageAgebyID(Container &data, std::vector<int> Ids)
{
        std::cout << "\n ======================Find Average Age =======================\n";

    int sum = 0, count = 0;
    for (auto &&i : Ids)
    {

        for (auto p : data)
        {
            if (p->id() == i)
            {
                sum += p->age(); 
                count++;
            }
        }
    }
    std::cout<<"Average Age : "<<sum/count;
}
void PassengerInstanceByID(Container &data, std::future<int> &ft)
{
    std::cout << "\n ======================The Passenger Instance BY ID: =======================\n";

    if (data.empty())
        throw std::runtime_error("No data exists in Container");

    int id = ft.get();
    for (auto p : data)
    {
        if (p->id() == id)
        {
            std::cout<< *p << "\n";
        }
    }
}

void MaximumFare(Container &data)
{
        std::cout << "\n \n======================The MAXIMUM FARE =======================\n\n";

    std::priority_queue<int> ans;
    std::set<int> anr;
    for (auto &&i : data)
    {
        ans.emplace(i->fare());
        anr.emplace(i->fare());
    }
    std::cout<< "Maxmimum fare : "<<ans.top()<<"\n\n";

    for (auto &&i : data)
    {
        std::cout<<ans.top()<<"\n";
        ans.pop();
    }
            std::cout << "\n \n=================\n\n";

      for (auto &&i : anr)
    {
        std::cout<<i<<"\n";
    }
           

    

}
void PassengerName(Container &data, std::string name)
{
            std::cout << "\n \n======================The Passenger  name =======================\n\n";

    Container result;
         for (auto p : data)           
        {
            if (p->name()==name)
            {
                continue;
            }
            else{
                result.emplace_back(p);
            }
        }
for (auto &&i : result)
{
    std::cout<<*i<<"\n";
    
}



}
