#ifndef TIKETTYPE_H
#define TIKETTYPE_H

enum class TicketType
{
    RESERVED, GENRAL
};

#endif // TIKETTYPE_H
