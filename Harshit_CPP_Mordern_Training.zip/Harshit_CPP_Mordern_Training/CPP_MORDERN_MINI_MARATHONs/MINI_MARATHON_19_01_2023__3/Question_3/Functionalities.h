#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include"Passenger.h"
#include<vector>
#include<future>
#include<mutex>
#include<thread>
using Pointer = std::shared_ptr<Passenger>;
using Container = std::vector<Pointer>;

void CreateObject(Container& data);
void FindAverageAgebyID(Container& data, std::vector<int> Ids);
void PassengerInstanceByID(Container &data, std::future<int> &ft);
void MaximumFare(Container& data);
void PassengerName(Container &data, std::string name);


#endif // FUNCTIONALITIES_H
