#include "Passenger.h"
#include<list>

Passenger::Passenger(int id, std::string name, int age, float fare,std::shared_ptr<Ticket> ticket)
:_id(id),_name(name),_age(age),_fare(fare),_ticket(ticket)
{
   

}
std::ostream &operator<<(std::ostream &os, const Passenger &rhs) {
    os << "_id: " << rhs._id
       << " _name: " << rhs._name
       << " _age: " << rhs._age
       << " _ticket: " << *(rhs._ticket)
       << " _fare: " << rhs._fare;
    return os;
}
