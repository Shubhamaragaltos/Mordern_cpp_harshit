#include "Functionalities.h"

int main()
{
    Container ptr;

    std::thread t1(CreateObject, std::ref(ptr));
    t1.join();
    std::promise<int> pr;

    std::future<int> ft = pr.get_future();

    std::future<void> result_ft = std::async(std::launch::async, &PassengerInstanceByID, std::ref(ptr), std::ref(ft));

    int ID = 0;
    std::cout << "\n Enter the ID : ";
    std::cin >> ID;
    pr.set_value(ID);
    result_ft.get();

    ////////////////////////////////////////////////////////////
    std::vector<int> id1{1, 2, 3};
    std::thread t2(FindAverageAgebyID, std::ref(ptr), id1);
    t2.join();
    /////////////////////////////////
    std::thread t3(MaximumFare, std::ref(ptr));
    t3.join();

    /////////////////////////////////////////////////
    PassengerName(ptr, "shubham");
}