#ifndef PASSENGER_H
#define PASSENGER_H

#include<iostream>
#include<memory>
#include"Ticket.h"
class Passenger
{
private:
int _id;
std::string _name;
int _age;
std::shared_ptr<Ticket> _ticket;
float _fare;
public:
Passenger( int id, std::string name, int age, float fare,std::shared_ptr<Ticket> ticket);//PC
~Passenger()=default;
Passenger()=default;
Passenger(const Passenger&)=delete;
Passenger(Passenger&&)=delete;
Passenger operator=(const Passenger&)=delete;
Passenger operator=(Passenger&&)=delete;

int id() const { return _id; }
void setId(int id) { _id = id; }

std::string name() const { return _name; }
void setName(const std::string &name) { _name = name; }

int age() const { return _age; }
void setAge(int age) { _age = age; }

std::shared_ptr<Ticket> ticket() const { return _ticket; }
void setTicket(const std::shared_ptr<Ticket> &ticket) { _ticket = ticket; }

float fare() const { return _fare; }
void setFare(float fare) { _fare = fare; }

friend std::ostream &operator<<(std::ostream &os, const Passenger &rhs);
};

#endif // PASSENGER_H
