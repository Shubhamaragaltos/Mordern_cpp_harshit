#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include<iostream>
#include"GradeType.h"
class Employee
{
private:
    std::string _name;
    int _id;
    float _salary;


public:
Employee( std::string name,    int id,   float salary );//PC
~Employee()=default;
Employee()=default;
Employee(const Employee&)=delete;
Employee(Employee&&)=delete;
// Employee operator=(const Employee&)=delete;
// Employee operator=(Employee&&)=delete;

virtual float CalculateBounus()=0;

std::string getname() const { return _name; }

int getid() const { return _id; }

float getsalary() const { return _salary; }

friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);


};

#endif // EMPLOYEE_H
