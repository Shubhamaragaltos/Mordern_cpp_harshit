#include "Functionalities.h"

void CreateObject(Container &data)
{
    data.emplace_back(std::make_shared<FullTimeEmployee>("SHubham", 1, 115000, "BMW", "Pune", GradeType::A, 50));
    data.emplace_back(std::make_shared<FullTimeEmployee>("Harshit", 2, 9876000, "FERRARI", "Mumbai", GradeType::B, 20));
    data.emplace_back(std::make_shared<FullTimeEmployee>("Aman", 3, 18000, "HONDA", "Banglore", GradeType::C, 10));

  
}

void DisplayCalculateBonus(Container &data)
{
    if (data.empty())
        throw std::runtime_error("No data exists in Container");
    for (auto &&i : data)
    {
        long long bonus =i->CalculateBounus();;
       std::cout<<"\nBonus: "<<bonus;

    }
    
}

void HighestSalary(Container &data)
{
    if (data.empty())
        throw std::runtime_error("No data exists in Container");

    auto itr = std::max_element(data.begin(),data.end(),[](Pointer& p1, Pointer& p2){
        return p1->getsalary()< p2->getsalary();
    });

    std::cout<<"\nHighest Salary instance : \n"<<**itr;

}

void FindEmployeeLocation(Container &data, GradeType gType)
{
    if (data.empty())
        throw std::runtime_error("No data exists in Container");

    auto itr = std::find_if(data.begin(), data.end(), [&](Pointer &P) // used STL FIND Algoritm
                            {
                                return P->gettype() == gType;
                            });
        Pointer p =*itr;

    std::cout<<"\nEmployee Location by GradeType:  " <<p->getemployeeLocation();
}

void FindPrijectNameByID(Container &data, std::future<int> &ft)
{
    int id = ft.get();

    auto itr = std::find_if(data.begin(), data.end(), [&](Pointer &P) // used STL FIND Algoritm
                            {
                                return P->getid() == id;
                            });
    Pointer p =*itr;
std::cout<<"\nProject Name for Given ID : ";
    std::cout<< p->getname();
}
