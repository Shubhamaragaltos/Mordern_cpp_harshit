#ifndef FULLTIMEEMPLOYEE_H
#define FULLTIMEEMPLOYEE_H

#include"Employee.h"
#include <ostream>

class FullTimeEmployee : public Employee
{
private:
std::string _project_name;
std::string _employee_location;
GradeType _type;
int _bonus_percentage;


public:
FullTimeEmployee(std::string name, int id, float salary, std::string projectname,  std::string employeelocation, GradeType type, int bonuspercentage );//PC
~FullTimeEmployee()=default;
FullTimeEmployee()=default;
FullTimeEmployee(const FullTimeEmployee&)=delete;
FullTimeEmployee(FullTimeEmployee&&)=delete;
FullTimeEmployee operator=(const FullTimeEmployee&)=delete;
FullTimeEmployee operator=(FullTimeEmployee&&)=delete;
float CalculateBounus()override;

std::string getprojectName() const { return _project_name; }

std::string getemployeeLocation() const { return _employee_location; }

GradeType gettype() const { return _type; }

int getbonusPercentage() const { return _bonus_percentage; }


friend std::ostream &operator<<(std::ostream &os, const FullTimeEmployee &rhs);


};

#endif // FULLTIMEEMPLOYEE_H
