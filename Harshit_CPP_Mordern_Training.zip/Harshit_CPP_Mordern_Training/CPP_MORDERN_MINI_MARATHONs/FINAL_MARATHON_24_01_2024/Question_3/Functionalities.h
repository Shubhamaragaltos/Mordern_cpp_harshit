#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<memory>
#include<vector>
#include"FullTimeEmployee.h"
#include<future>
#include<algorithm>
#include<numeric>

using Pointer = std::shared_ptr<FullTimeEmployee>;
using Container = std::vector<Pointer>;

void CreateObject(Container& data);
void DisplayCalculateBonus(Container& data);
void HighestSalary(Container& data);
void FindEmployeeLocation(Container& data, GradeType gType);
void FindPrijectNameByID(Container& data,std::future<int> &ft);
  




#endif // FUNCTIONALITIES_H
