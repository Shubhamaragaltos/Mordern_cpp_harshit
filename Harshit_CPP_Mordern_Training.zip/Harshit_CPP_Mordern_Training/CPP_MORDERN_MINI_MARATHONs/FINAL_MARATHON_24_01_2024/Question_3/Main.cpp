#include "Functionalities.h"

int main()
{
    Container ptr;
    CreateObject(ptr);
    std::cout << "\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n";
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    std::promise<int> pr;

    std::future<int> ft = pr.get_future();

    std::future<void> result_ft = std::async(std::launch::async, &FindPrijectNameByID, std::ref(ptr), std::ref(ft));

    int N = 0;
    std::cout << "\n Enter the ID : ";
    std::cin >> N;
    pr.set_value(N);
    result_ft.get();
    std::cout << "\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n";

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    try
    {
        DisplayCalculateBonus(ptr);
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }

    std::cout << "\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n";

    try
    {
        HighestSalary(ptr);
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }
        FindEmployeeLocation(ptr, GradeType::C);

    std::cout << "\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n";
    try
    {
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }

    std::cout << "\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n";
}