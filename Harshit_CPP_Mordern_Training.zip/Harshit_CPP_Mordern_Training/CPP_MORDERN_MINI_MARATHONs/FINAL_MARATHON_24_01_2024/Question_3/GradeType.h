#ifndef GRADETYPE_H
#define GRADETYPE_H

enum class GradeType{

    A=1,B,C
};

#endif // GRADETYPE_H
