#include "FullTimeEmployee.h"

FullTimeEmployee::FullTimeEmployee(std::string name, int id, float salary, std::string projectname, std::string employeelocation, GradeType type, int bonuspercentage)
    : Employee(name, id, salary), _project_name(projectname), _employee_location(employeelocation), _type(type), _bonus_percentage(bonuspercentage)
{
    if (_bonus_percentage < 1 || _bonus_percentage > 100)
    {
        throw std::runtime_error("Bonuspercentage beteen 1 to 100");
    }
}

float FullTimeEmployee::CalculateBounus()
{
    if(_type ==GradeType::A)
    {
        return _bonus_percentage * getsalary();
    }

    if(_type ==GradeType::B)
    {
                return _bonus_percentage * getsalary()/2;

    }

    if(_type ==GradeType::C)
    {
                return _bonus_percentage * getsalary()/4;

    }
    return 0.0f;
}

std::ostream &operator<<(std::ostream &os, const FullTimeEmployee &rhs) {
    os << static_cast<const Employee &>(rhs)
       << " _project_name: " << rhs._project_name
       << " _employee_location: " << rhs._employee_location
       << " _type: " << static_cast<int>(rhs._type)
       << " _bonus_percentage: " << rhs._bonus_percentage;
    return os;
}



