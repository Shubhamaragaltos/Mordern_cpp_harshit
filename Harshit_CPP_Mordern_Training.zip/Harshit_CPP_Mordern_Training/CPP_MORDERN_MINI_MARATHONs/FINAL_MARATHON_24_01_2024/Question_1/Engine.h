#ifndef ENGINE_H
#define ENGINE_H

#include <iostream>
#include "EngineType.h"

class Engine
{
private:
    std::string _engineID;
    int _horsepower;
    EngineType _enigine_Type;
    float _engineCapacity;
    float _engineTorque;

public:
    Engine(std::string engineID, int horsepower, EngineType enigineType, float engineCapacity, float engineTorque); // PC
    ~Engine() = default;
    Engine() = default;
    Engine(const Engine &) = delete;
    Engine(Engine &&) = delete;
    Engine operator=(const Engine &) = delete;
    Engine operator=(Engine &&) = delete;

    std::string engineID() const { return _engineID; }

    int horsepower() const { return _horsepower; }

    EngineType enigineType() const { return _enigine_Type; }

    float engineCapacity() const { return _engineCapacity; }

    float engineTorque() const { return _engineTorque; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);
};
#endif // ENGINEH
