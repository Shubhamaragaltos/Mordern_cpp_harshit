#include "Functionalities.h"

void CreateObject(Container &data)
{
    data[0] = std::make_shared<Engine>("ID1", 2002, EngineType::DISEL, 1, 50);
    data[1] = std::make_shared<Engine>("ID2", 500, EngineType::HYBRID, 15, 140);
    data[2] = std::make_shared<Engine>("ID3", 3000, EngineType::PETROL, 20, 90);
}

std::vector<int> Return_Engine_Type(Container &data)
{
    if (data.empty())
        throw std::runtime_error("No data exists in Container");

    std::vector<int> ans{0};

    for (auto &&i : data)
    {
        if(i->horsepower()>1000 && i->engineCapacity() > 2)
        {
            int n = static_cast<int>(i->enigineType());
           ans.emplace_back(n);
        }
    }
    
    
    return ans;
}

bool Check_Engine_Torque(Container &data)
{
    if (data.empty())
        throw std::runtime_error("No data exists in Container");

    bool ans  = std::all_of(data.begin(),data.end(),[](Pointer& p){return p->engineTorque()>110;});
    return ans;
}

void EngineCapacity_Count(Container &data, int Number=0) // use STL alogo for count
{
    if (data.empty())
        throw std::runtime_error("No data exists in Container");

    int count = std::count_if(data.begin(),data.end(),[&](Pointer& p){return p->engineCapacity()>Number;});
    std::cout<<"\n The count of Engine Capacity over threshold: "<<count;
}
