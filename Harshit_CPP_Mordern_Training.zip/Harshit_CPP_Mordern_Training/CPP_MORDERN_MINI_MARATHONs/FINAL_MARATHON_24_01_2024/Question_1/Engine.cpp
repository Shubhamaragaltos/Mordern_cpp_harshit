#include "Engine.h"

Engine::Engine(std::string engineID, int horsepower, EngineType enigineType, float engineCapacity, float engineTorque)
    : _engineID(engineID), _horsepower(horsepower), _enigine_Type(enigineType), _engineCapacity(engineCapacity),_engineTorque(engineTorque)
{
    if (_horsepower < 0 || _engineTorque < 20 || _engineTorque > 150)
    {
        throw std::runtime_error("\nHorsepoer Cannot be negative");
    }
 
  
}
    std::ostream &operator<<(std::ostream &os, const Engine &rhs)
    {
        os << "_engineID: " << rhs._engineID
           << " _horsepower: " << rhs._horsepower
           << " _enigine_Type: " << static_cast<int>(rhs._enigine_Type)
           << " _engineCapacity: " << rhs._engineCapacity
           << " _engineTorque: " << rhs._engineTorque;
        return os;
    }
