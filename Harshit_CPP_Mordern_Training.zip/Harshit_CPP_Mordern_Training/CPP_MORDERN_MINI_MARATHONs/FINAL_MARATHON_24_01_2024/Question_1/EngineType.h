#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType{

PETROL=1, DISEL, HYBRID
};

#endif // ENGINETYPE_H

