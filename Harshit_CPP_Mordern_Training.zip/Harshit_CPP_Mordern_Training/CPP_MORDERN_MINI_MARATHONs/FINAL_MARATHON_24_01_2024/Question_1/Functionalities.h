#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include"Engine.h"
#include<array>
#include<memory>
#include<vector>
#include<algorithm>
#include<numeric>

using Pointer = std::shared_ptr<Engine>;
using Container = std::array<Pointer,3>;

void CreateObject (Container& data);
std::vector<int> Return_Engine_Type(Container& data);
bool Check_Engine_Torque(Container& data);
void EngineCapacity_Count(Container& data, int Number);



#endif // FUNCTIONALITIES_H
