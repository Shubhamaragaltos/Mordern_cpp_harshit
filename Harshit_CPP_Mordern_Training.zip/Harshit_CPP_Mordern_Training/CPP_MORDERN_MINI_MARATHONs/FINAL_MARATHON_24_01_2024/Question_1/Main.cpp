#include "Functionalities.h"

int main()
{
    Container ptr;
    try
    {
        CreateObject(ptr);
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }
std::cout<<"\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n";
    try
    {
        std::vector ans = Return_Engine_Type(ptr);
        for (auto &&i : ans)
        {
            std::cout << "\nEngineType: " << i << "\n";
        }
    }

    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }
std::cout<<"\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n";

    try
    {
        std::cout << "\nTRUE or FASLE FOR ABOVE 110: " << Check_Engine_Torque(ptr);
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }
std::cout<<"\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n";


try
{
    EngineCapacity_Count(ptr, 10);
}
catch(const std::exception& e)
{
    std::cerr << e.what() << '\n';
}
std::cout<<"\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n";

    
}