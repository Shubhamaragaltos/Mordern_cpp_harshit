#include "Functionalities.h"

int main()
{
    std::vector<int> data{1, 2, 3, 4, 5};

    Function_Container fun;
    CreateObject(fun);
    Operation(fun, data);
}