#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <vector>
#include <functional>
#include <iostream>

using FnType = std::function<void(std::vector<int>)>;
using Function_Container = std::vector<FnType>;


void CreateObject(Function_Container& fata);
void Operation(Function_Container& Function, std::vector<int> data);

#endif // FUNCTIONALITIES_H
