#include "Functionalities.h"

void CreateObject(Function_Container &fata)
{
    fata.emplace_back([](std::vector<int> data)
                      {
        auto itr = std::max_element(data.begin(), data.end());
        int largest = *itr;
        *itr = 0;
        auto ptr = std::max_element(data.begin(), data.end());
        int Second = *ptr;

        std::cout << "\n SUM : "
                  << "\t" << largest + Second; });

    /////////////////////////////////////////////////////////////////////////////////////////////////
    fata.emplace_back([](std::vector<int> data)
                      {

        auto itr = std::min_element(data.begin(), data.end());
        int min = *itr;
         std::cout << "\n MIN : "
                  << "\t" << min; });

    /////////////////////////////////////////////////////////////////////////////////////////////////

    fata.emplace_back([](std::vector<int> data)
                      {

    for (auto &&i : data)
    {
        if (i % 2 != 0)
        {
            std::cout <<"ODD number: "<< i << "\n";
        }
    } });

    //    /////////////////////////////////////////////////////////////////////////////////////////////////

    fata.emplace_back([](std::vector<int> data)
                      {

     int count = std::count_if(data.begin(), data.end(), [](int number)
                               { return number % 4 == 0; });
     std::cout << "\n Count Of Element Divisible BY 4: " << count; });
}

/////////////////////////////////////////////////////////////////////////////////////////////////

void Operation(Function_Container &Fuction, std::vector<int> data)
{
    for (auto &fn : Fuction)
    {
        std::cout << "\n\n===========================================\n\n";

        fn(data);
    }
    std::cout << "\n\n===========================================\n\n";
}
