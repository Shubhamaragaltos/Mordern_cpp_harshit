#ifndef OWNERTYPE_H
#define OWNERTYPE_H

enum class OwenrType{
FULL_OWNER, PART_OWNER
};

#endif // OWNERTYPE_H
