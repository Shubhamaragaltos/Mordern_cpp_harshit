#include "Functionalities.h"
#include<queue>

void Createobject(Container &data, Vtype_Container &bata, Ref_container &rata)
{
    rata[0] = std::make_shared<Owner>("Shubham", "pune", OwenrType::FULL_OWNER);
    bata[0] = std::make_shared<TouristPermit>(12, "GOA", 12000);
    data[0] = std::make_shared<Vehicle>(1, 5400, rata[0], bata[0]);

    ////////////////////////////////////////////////////////////////
    rata[1] = std::make_shared<Owner>("harshit", "latur", OwenrType::PART_OWNER);
    bata[1] = std::make_shared<TouristPermit>(2, "Maharastra", 6000);
    data[1] = std::make_shared<Vehicle>(2, 574600, rata[1], bata[1]);

    ////////////////////////////////////////////////////////////////
    rata[2] = std::make_shared<Owner>("Hetvi", "gujrat", OwenrType::FULL_OWNER);
    bata[2] = std::make_shared<PrivatePermit>("harayana", 1600, 1500, PermitCategory::LMV);
    data[2] = std::make_shared<Vehicle>(3, 5407665, rata[2], bata[2]);
}

void PernitDetailsByID(Container &data, int IDX)
{

    for (auto &p : data)
    {
        if (p->getid() == IDX)
        {
            Vtype v = p->getinstance();
            std::visit([](auto &&val)
                       { std::cout << "\n Permit BY ID : " << *val; },
                       v);
        }
    }
}

void Countofvhecle(Container &data, OwenrType type)
{
    int count = 0;
    for (auto &&i : data)
    {
        if (i->getowner().get()->getownertype() == type)
        {
            count++;
        }
    }
    std::cout << "\nCount for ownerType : " << count;
}

void VhecleBelowThreshold(Container &data, float Price)
{
    std::cout << "\nVehicle Below threshold: \n\n";
    for (auto &&i : data)
    {
        if (i->getprice() < Price)

            std::cout << *i << "\n";
    }
}

void FindPermitIssueStateByOwnerName(Container &data, std::string name)
{

    for (auto &&i : data)
    {
        if (i->getowner().get()->getname() == name)
        {
            Vtype v = i->getinstance();
            std::visit([](auto &&val)
                       { std::cout << "\nFind State By Owner Name: " << val->getpermitIssuerState()<< "\n"; },
                       v);
        }
    }
}

void PrintOwnerDetailsOnID(Container &data, int IDX)
{
    for (auto &p : data)
    {
        if (p->getid() == IDX)
        {
            std::cout<<"Owner Details By id : "<<*p;
        }
    }
}

void MAX_Permit(Container &data)
{   
    std::priority_queue<float> ans;

    for (auto &i : data)
    {
            Vtype v = i->getinstance();
        if (std::holds_alternative<Tourism_pointer>(v))
        {
            Tourism_pointer &p = std::get<Tourism_pointer>(v);
            ans.emplace(p->getpermitCost());
        }
    }
    std::cout<<"\nThe MAx permit Cost : "<<ans.top();
    

}

void TotlaPeritCostForTourist(Container &data)
{
    float total = 0;
    for (auto &i : data)
    {
            Vtype v = i->getinstance();
        if (std::holds_alternative<Tourism_pointer>(v))
        {
            Tourism_pointer &p = std::get<Tourism_pointer>(v);
            total += p->getpermitCost();
        }
    }
    std::cout<<"\nTotal Price : "<<total;
}
