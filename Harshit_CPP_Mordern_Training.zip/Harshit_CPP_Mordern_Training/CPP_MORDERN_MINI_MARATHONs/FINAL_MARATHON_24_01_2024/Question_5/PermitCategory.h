#ifndef PERMITCATEGORY_H
#define PERMITCATEGORY_H

enum class PermitCategory{
LMV, HMV
};

#endif // PERMITCATEGORY_H
