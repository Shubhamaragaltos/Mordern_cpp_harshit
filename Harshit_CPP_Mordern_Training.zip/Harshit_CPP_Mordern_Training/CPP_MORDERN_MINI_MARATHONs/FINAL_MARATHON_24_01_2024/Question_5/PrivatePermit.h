#ifndef PRIVATEPERMIT_H
#define PRIVATEPERMIT_H
#include"PermitCategory.h"
#include<iostream>
class PrivatePermit
{
private:
    std::string _permit_issuer_state;
    float _permit_tax;
    float _permit_renewal_charge;
    PermitCategory _privateCategory;

public:
PrivatePermit( std::string permitissuerstate, float permittax, float permitrenewalcharge, PermitCategory privateCategory);
~PrivatePermit()=default;
PrivatePermit()=default;
PrivatePermit(const PrivatePermit&)=delete;
PrivatePermit(PrivatePermit&&)=delete;
PrivatePermit operator=(const PrivatePermit&)=delete;
PrivatePermit operator=(PrivatePermit&&)=delete;

std::string getpermitIssuerState() const { return _permit_issuer_state; }

float getpermitTax() const { return _permit_tax; }

float getpermitRenewalCharge() const { return _permit_renewal_charge; }

PermitCategory getprivateCategory() const { return _privateCategory; }

friend std::ostream &operator<<(std::ostream &os, const PrivatePermit &rhs);
};

#endif // PRIVATEPERMITH
