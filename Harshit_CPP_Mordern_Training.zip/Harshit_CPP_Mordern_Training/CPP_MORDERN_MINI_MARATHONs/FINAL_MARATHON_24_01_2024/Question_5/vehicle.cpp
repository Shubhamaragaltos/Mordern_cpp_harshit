#include "vehicle.h"
std::ostream &operator<<(std::ostream &os, const Vehicle &rhs)
{
    os << "_id: " << rhs._id
       << " _price: " << rhs._price
       << " _owner: " << *(rhs._owner.get());
    // << " _instance: " << rhs._instance;
    os << "_instance: ";
    std::visit([&](auto &&val)
               { os  << *val; },
               rhs._instance);
    return os;
}
Vehicle::Vehicle(int id, float price, Rftype owner, Vtype instance)
    : _id(id), _price(price), _owner(owner), _instance(instance)
{
}
