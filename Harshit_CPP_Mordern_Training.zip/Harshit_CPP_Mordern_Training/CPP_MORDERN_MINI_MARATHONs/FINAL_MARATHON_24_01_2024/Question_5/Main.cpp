#include "Functionalities.h"

int main()
{
    Container ptr;
    Vtype_Container btr;
    Ref_container ctr;

    Createobject(ptr, btr, ctr);
    std::cout << "\n\n=============================\n\n";
    PernitDetailsByID(ptr, 3);
    std::cout << "\n\n=============================\n\n";
    Countofvhecle(ptr, OwenrType ::FULL_OWNER);

    std::cout << "\n\n=============================\n\n";
    VhecleBelowThreshold(ptr, 50000);

    std::cout << "\n\n=============================\n\n";

    FindPermitIssueStateByOwnerName(ptr, "harshit");
    std::cout << "\n\n=============================\n\n";

    PrintOwnerDetailsOnID(ptr, 2);
    std::cout << "\n\n=============================\n\n";
    TotlaPeritCostForTourist(ptr);
    std::cout << "\n\n=============================\n\n";
    MAX_Permit(ptr);
    std::cout << "\n\n=============================\n\n";
}