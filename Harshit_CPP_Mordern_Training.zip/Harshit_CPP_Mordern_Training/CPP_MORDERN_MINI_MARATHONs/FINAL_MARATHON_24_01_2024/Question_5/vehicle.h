#ifndef VEHICLE_H
#define VEHICLE_H

#include<iostream>
#include"OwnerType.h"
#include"PermitCategory.h"
#include<functional>
#include"Owner.h"
#include<memory>
#include"TouristPermit.h"
#include"PrivatePermit.h"
#include<variant>

using Owner_Pointer= std::shared_ptr<Owner>;
using Rftype = std::reference_wrapper<Owner_Pointer>;
using Tourism_pointer = std::shared_ptr<TouristPermit>;
using private_pointer = std::shared_ptr<PrivatePermit>;
using Vtype = std::variant<Tourism_pointer,private_pointer>;

class Vehicle
{
private:
    int _id;
    float _price;
    Rftype _owner;
    Vtype _instance;

public:
Vehicle(int id, float price, Rftype owner, Vtype instance);//PC
~Vehicle()=default;
Vehicle()=default;
Vehicle(const Vehicle&)=delete;
Vehicle(Vehicle&&)=delete;
Vehicle operator=(const Vehicle&)=delete;
Vehicle operator=(Vehicle&&)=delete;

int getid() const { return _id; }

float getprice() const { return _price; }

Rftype getowner() const { return _owner; }

Vtype getinstance() const { return _instance; }

friend std::ostream &operator<<(std::ostream &os, const Vehicle &rhs);
};



#endif // VEHICLE_H
