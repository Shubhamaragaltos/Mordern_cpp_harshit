#include "Owner.h"

Owner::Owner(std::string name, std::string city, OwenrType ownertype)
:_name(name),_city(city),_ownertype(ownertype)
{
}
std::ostream &operator<<(std::ostream &os, const Owner &rhs) {
    os << "_name: " << rhs._name
       << " _city: " << rhs._city
       << " _ownertype: " << static_cast<int> (rhs._ownertype);
    return os;
}
