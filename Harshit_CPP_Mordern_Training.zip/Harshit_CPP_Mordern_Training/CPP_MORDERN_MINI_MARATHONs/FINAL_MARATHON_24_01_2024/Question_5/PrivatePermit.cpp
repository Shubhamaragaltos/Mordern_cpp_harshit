#include "PrivatePermit.h"

PrivatePermit::PrivatePermit(std::string permitissuerstate, float permittax, float permitrenewalcharge, PermitCategory privateCategory)
:_permit_issuer_state(permitissuerstate),_permit_tax(permittax),_permit_renewal_charge(permitrenewalcharge),_privateCategory(privateCategory)
{
}
std::ostream &operator<<(std::ostream &os, const PrivatePermit &rhs) {
    os << "_permit_issuer_state: " << rhs._permit_issuer_state
       << " _permit_tax: " << rhs._permit_tax
       << " _permit_renewal_charge: " << rhs._permit_renewal_charge
       << " _privateCategory: " << static_cast<int>(rhs._privateCategory);
    return os;
}
