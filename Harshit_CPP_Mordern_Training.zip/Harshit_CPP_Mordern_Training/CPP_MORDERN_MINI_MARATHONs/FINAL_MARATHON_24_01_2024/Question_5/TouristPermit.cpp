#include "TouristPermit.h"

TouristPermit::TouristPermit(int durationmonth, std::string permitissuerstate, float permitcost)
:_duration_month(durationmonth), _permit_issuer_state(permitissuerstate),_permit_cost(permitcost)
{
}
std::ostream &operator<<(std::ostream &os, const TouristPermit &rhs) {
    os << "_duration_month: " << rhs._duration_month
       << " _permit_issuer_state: " << rhs._permit_issuer_state
       << " _permit_cost: " << rhs._permit_cost;
    return os;
}
