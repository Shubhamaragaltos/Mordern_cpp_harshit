#ifndef TOURISTPERMIT_H
#define TOURISTPERMIT_H
#include<iostream>
class TouristPermit
{
private:
int _duration_month;
std::string _permit_issuer_state;
float _permit_cost;
public:
TouristPermit(int durationmonth, std::string permitissuerstate,float permitcost);//PC
~TouristPermit()=default;
TouristPermit()=default;
TouristPermit(const TouristPermit&)=delete;
TouristPermit(TouristPermit&&)=delete;
TouristPermit operator=(const TouristPermit&)=delete;
TouristPermit operator=(TouristPermit&&)=delete;

int getdurationMonth() const { return _duration_month; }

std::string getpermitIssuerState() const { return _permit_issuer_state; }

float getpermitCost() const { return _permit_cost; }

friend std::ostream &operator<<(std::ostream &os, const TouristPermit &rhs);
};

#endif // TOURISTPERMIT_H
