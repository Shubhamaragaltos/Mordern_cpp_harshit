#ifndef OWNER_H
#define OWNER_H
#include <iostream>
#include"OwnerType.h"
class Owner
{
private:
    std::string _name;
    std::string _city;
    OwenrType _ownertype;

public:
    Owner(std::string name, std::string city, OwenrType ownertype); // PC
        ~Owner() = default;
    Owner() = default;
    Owner(const Owner &) = delete;
    Owner(Owner &&) = delete;
    Owner operator=(const Owner &) = delete;
    Owner operator=(Owner &&) = delete;

    std::string getname() const { return _name; }

    std::string getcity() const { return _city; }

    OwenrType getownertype() const { return _ownertype; }

    friend std::ostream &operator<<(std::ostream &os, const Owner &rhs);
};

#endif // OWNER_H
