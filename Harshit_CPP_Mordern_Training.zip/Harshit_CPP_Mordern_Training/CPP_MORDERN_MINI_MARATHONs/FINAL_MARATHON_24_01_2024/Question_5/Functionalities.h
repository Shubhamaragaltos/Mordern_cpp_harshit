#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include"vehicle.h"
#include <array>

using Pointer = std::shared_ptr<Vehicle>;
using Container = std::array<Pointer,3>;
using Vtype_Container = std::array<Vtype,3>;
using Ref_container = std::array<Owner_Pointer,3>;

void Createobject(Container& data, Vtype_Container& bata,Ref_container& rata);

void PernitDetailsByID(Container& data,int IDX);
void Countofvhecle(Container& data,OwenrType type);
void VhecleBelowThreshold(Container& data, float Price);
void FindPermitIssueStateByOwnerName(Container& data, std::string name);
void PrintOwnerDetailsOnID(Container& data,int IDX);
void MAX_Permit(Container& data);
void TotlaPeritCostForTourist(Container& data);
#endif // FUNCTIONALITIES_H
