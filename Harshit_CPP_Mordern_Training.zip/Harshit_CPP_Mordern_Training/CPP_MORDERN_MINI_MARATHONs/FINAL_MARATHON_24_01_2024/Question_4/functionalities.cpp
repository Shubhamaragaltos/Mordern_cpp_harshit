#include "functionalities.h"

void CreateObject(Container &data)
{
    data.emplace(std::make_pair("ID1", std::make_shared<Developer>("IDX", "shubham", 17000, 1, SkillSet::CODE_REVIEW)));
    data.emplace(std::make_pair("ID2", std::make_shared<Developer>("IDX", "Hetvi", 1900, 3, SkillSet::CODING)));
    data.emplace(std::make_pair("ID3", std::make_shared<CodeTester>("IDX", "harshit", 189560, 7, SkillSet::INTEGRATION_TESTING)));
    data.emplace(std::make_pair("ID4", std::make_shared<CodeTester>("IDX", "Aman", 19000, 6, SkillSet::UNIT_TESTING)));
}

Container Find_instance_With_experience(Container &data)
{
    Container result;
    for (auto &[k, v] : data)
    {
        std::visit([&](auto &&val)

                   { if(val->getexperienceYears()<6)
                   {
                        result.emplace(k,v);
                   } },
                   v);
    }
    return result;
}

void AverageSalary(Container &data)
{
    float total = 1, count = 1;
    for (auto &[k, v] : data)
    {

        if (std::holds_alternative<CodeTester_Pointer>(v))
        {
            CodeTester_Pointer &p = std::get<CodeTester_Pointer>(v);
            total += p->getsalary();
            count++;
        }
    }
    float ans = total / count;
    std::cout << "\nAverage Salary : " << total / count;
}

void CountofEmployee(Container &data)
{
    Container result;
    int count = 0;
    for (auto &[k, v] : data)
    {
        std::visit([&](auto &&val)

                   { if (val->getsalary()>50000)
                         {
                             count++;
                         } },
                   v);
    }
    std::cout << "\n Count of employees Salary more than 50K:  " << count;
}

void FindSalaryById(Container &data, std::string ID)
{
    for (auto &[k, v] : data)
    {
        if (k == ID)
        {
            std::visit([&](auto &&val)

                       { std::cout << "The salary for given ID : " << val->getsalary(); },
                       v);
        }
    }
}

bool salaryAbove60(Container &data)
{
    int count = 0; int flag=1;
    for (auto &[k, v] : data)
    {
        std::visit([&](auto &&val)

                   { if (val->getsalary()<60000)
                         {
                             flag=0;
                         } },
                   v);
    }
    return flag;
}
