#include "CodeTester.h"



std::ostream &operator<<(std::ostream &os, const CodeTester &rhs) {
    os //<< //"_id: " << rhs._id
       << " _name: " << rhs._name
       << " _salary: " << rhs._salary
       << " _experience_years: " << rhs._experience_years
       << " _skill: " << static_cast<int>(rhs._skill);
    return os;
}

CodeTester::CodeTester(std::string id, std::string name, float salary, int experienceyears, SkillSet skill)
:_id(id),_name(name),_salary(salary),_experience_years(experienceyears),_skill(skill)

{
}

float CodeTester::calculateBounus()
{
     if(_experience_years <5)
    {
        return _salary*0.05;
    }
    else{
        return _salary*0.10;
    }
    return 0.0f;
}
