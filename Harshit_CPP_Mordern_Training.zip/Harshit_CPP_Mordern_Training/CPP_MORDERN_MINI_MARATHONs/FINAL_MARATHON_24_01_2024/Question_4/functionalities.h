
#include<unordered_map>

#include "Developer.h"
#include "CodeTester.h"
#include <memory>
#include <variant>
#include <ostream>

using Developer_Pointer = std::shared_ptr<Developer>;
using CodeTester_Pointer = std::shared_ptr<CodeTester>;
using Vtype = std::variant<Developer_Pointer, CodeTester_Pointer>;
using Container = std::unordered_map<std::string,Vtype>;

void CreateObject(Container& data);
Container Find_instance_With_experience(Container& data);
void AverageSalary(Container& data);
void CountofEmployee(Container& data);
void FindSalaryById(Container& data,std::string ID);
bool salaryAbove60(Container& data);