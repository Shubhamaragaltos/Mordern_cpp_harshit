#include "functionalities.h"

int main()
{
    Container ptr;
    CreateObject(ptr);
    std::cout << "\n\n===========================Find_instance_With_experience============================\n\n";
    Container ans = Find_instance_With_experience(ptr);
    for (auto &[k, v] : ans)
    {
        std::cout << "_id: "<<k;
        std::visit([](auto &&val)
                   { std::cout << " " << *val; },
                   v);
        std::cout << "\n";
    }
    
    std::cout << "\n\n======================COUNT=================================\n\n";
    CountofEmployee(ptr);
    std::cout << "\n\n==========================SALARY BY ID=============================\n\n";
    FindSalaryById(ptr, "ID3");
    std::cout << "\n\n=========================BOOLEAN==============================\n\n";
    std::cout<<"Boolean Return for salary 60000 for above all instance: "<<salaryAbove60(ptr);
    std::cout << "\n\n===================AVERAGE SALARY====================================\n\n";
    AverageSalary(ptr);
   std::cout << "\n\n=======================================================\n\n";
}
