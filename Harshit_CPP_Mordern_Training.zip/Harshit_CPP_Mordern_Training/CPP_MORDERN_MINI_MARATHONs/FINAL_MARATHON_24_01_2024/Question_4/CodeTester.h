#ifndef CODETESTER_H
#define CODETESTER_H

#include<iostream>
#include"SkillSet.h"

class CodeTester
{
private:
    std::string _id;
    std::string _name;
    float _salary;
    int _experience_years;
    SkillSet _skill;

public:
CodeTester(std::string id, std::string name, float salary, int experienceyears, SkillSet skill) ;
~CodeTester()=default;
CodeTester()=default;
CodeTester(const CodeTester&)=delete;
CodeTester(CodeTester&&)=delete;
CodeTester operator=(const CodeTester&)=delete;
CodeTester operator=(CodeTester&&)=delete;
float calculateBounus();

std::string getid() const { return _id; }

std::string getname() const { return _name; }

float getsalary() const { return _salary; }

int getexperienceYears() const { return _experience_years; }

SkillSet getSkill() const { return _skill; }

friend std::ostream &operator<<(std::ostream &os, const CodeTester &rhs);

};

#endif // CODETESTER_H
