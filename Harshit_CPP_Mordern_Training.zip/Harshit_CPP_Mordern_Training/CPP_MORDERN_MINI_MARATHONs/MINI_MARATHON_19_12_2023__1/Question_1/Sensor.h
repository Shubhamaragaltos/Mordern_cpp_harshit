#ifndef SENSOR_H
#define SENSOR_H

#include <iostream>
#include "SensorType.h"

class Sensor
{
private:
    int Id;
    std::string Name;
    int Reading;
    SensorType Type;

public:
    Sensor(/* args */) = default;
    Sensor(int _id, std::string _name, SensorType _type,int reading);
    Sensor(const Sensor &) = delete;
    Sensor(Sensor &&) = delete;
    Sensor &operator=(const Sensor &) = delete;
    Sensor &operator=(Sensor &&) = delete;
    ~Sensor()= default;

    int id() const { return Id; }

    std::string name() const { return Name; }

    int reading() const { return Reading; }

    SensorType type() const { return Type; }

    friend std::ostream &operator<<(std::ostream &os, const Sensor &rhs);

};

#endif // SENSOR_H
