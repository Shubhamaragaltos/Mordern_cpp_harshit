#include "functinalities.h"
#include <iostream>

int main()
{

    Container ptr;

    try
    {
        CreateObject(ptr);
    }
    catch (std ::runtime_error &e)
    {
        std::cerr << e.what() << "\nERROR IN FUNCTION\n";
    }

    try
    {
        
            std::cout << "\n" << Show_Reading(ptr) << "\n";
        
    }
    catch (std ::runtime_error &e)
    {
        std::cerr << e.what() << "\nERROR IN FUNCTION\n";
    }

    try
    {
       std::cout<<"\n Count: "<< Count_Sensor_Instance_type(ptr,SensorType::TYRE_PRESSIRE);
    }
    catch (std ::runtime_error &e)
    {
        std::cerr << e.what() << "\nERROR IN FUNCTION\n";
    }


    try
    {
       std::cout<<"\n sensorn name: "<< Sensor_name(ptr,1001,SensorType::TYRE_PRESSIRE);
    }
    catch (std ::runtime_error &e)
    {
        std::cerr << e.what() << "\nERROR IN FUNCTION\n";
    }

    try
    {

        Container temp = Sensor_Instance(ptr);
        auto itr = temp.begin();
        for(Pointer p : temp)
        {
            std::cout<<"\n"<<**itr<<"\n";
            itr++;
        }
    }
    catch (std ::runtime_error &e)
    {
        std::cerr << e.what() << "\nERROR IN FUNCTION\n";
    }
}