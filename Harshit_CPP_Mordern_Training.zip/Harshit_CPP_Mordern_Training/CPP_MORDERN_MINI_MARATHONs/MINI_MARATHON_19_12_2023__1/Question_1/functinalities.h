#ifndef FUNCTINALITIES_H
#define FUNCTINALITIES_H

#include <iostream>
#include <list>
#include <memory>
#include "Sensor.h"

using Pointer = std::shared_ptr<Sensor>;
using Container = std::list<Pointer>;

void CreateObject(Container &data);
bool Show_Reading(Container &data);
int Count_Sensor_Instance_type(Container &data,SensorType Type);
std::string Sensor_name(Container &data, int _id, SensorType S_type);
Container Sensor_Instance(Container &data);
#endif // FUNCTINALITIES_H
