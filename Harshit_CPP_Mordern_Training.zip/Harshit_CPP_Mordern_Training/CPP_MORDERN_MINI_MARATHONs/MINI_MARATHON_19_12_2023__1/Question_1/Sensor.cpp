#include "Sensor.h"
std::ostream &operator<<(std::ostream &os, const Sensor &rhs) {
    os << "Id: " << rhs.Id
       << " Name: " << rhs.Name
       << " Reading: " << rhs.Reading
       << " Type: " <<static_cast<int> (rhs.Type);
    return os;
}
Sensor::Sensor(int _id, std::string _name, SensorType _type, int reading)
:Id(_id),Name(_name), Type(_type)
{
    if(reading>0 && reading<20 && reading%10!=0)
    {
            Reading=reading;
    }
    else{
    throw std::runtime_error("INPUT VALUE IS INVALID");
    }
}
