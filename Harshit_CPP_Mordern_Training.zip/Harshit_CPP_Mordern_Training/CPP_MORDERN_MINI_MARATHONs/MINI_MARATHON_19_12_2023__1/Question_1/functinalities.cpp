#include "functinalities.h"

void CreateObject(Container &data)
{
    data.emplace_back(std::make_shared<Sensor>(1001, "SUV_Sensor", SensorType::TYRE_PRESSIRE, 12));
    data.emplace_back(std::make_shared<Sensor>(1002, "Thermometer", SensorType::TEMPERATURE, 11));
    data.emplace_back(std::make_shared<Sensor>(1003, "Plane_Sensor", SensorType::CABIN_PRESUSURE, 13));
    data.emplace_back(std::make_shared<Sensor>(1004, "Truck_sensor", SensorType::TYRE_PRESSIRE, 19));
    data.emplace_back(std::make_shared<Sensor>(1005, "Car_Sensor", SensorType::TYRE_PRESSIRE, 15));
}

bool Show_Reading(Container& data)
{
for(Pointer p: data)
{
    if (p->reading() > 25)
    {
        return false;
    }
}
    return true;

}

int Count_Sensor_Instance_type(Container &data, SensorType Type)
{
    if (data.empty())
    {
        throw std ::runtime_error("CONTAINER IS EMPTY");
    }
    int count = 0;
    for (Pointer p : data)
    {
        if (Type == p->type())
        {
            count++;
        }
    }
    return count;
}

std::string Sensor_name(Container &data, int _id, SensorType S_type)
{
     if (data.empty())
    {
        throw std ::runtime_error("CONTAINER IS EMPTY");
    }
    std::string name{""};
    for (Pointer p : data)
    {
        if (p->id() == _id && p->type() == S_type)
        {
            name = p->name();
            return name;
        }
    }
    throw std::runtime_error("DATA NOT FOUND");
}

Container Sensor_Instance(Container &data)
{
     if (data.empty())
    {
        throw std ::runtime_error("CONTAINER IS EMPTY");
    }
    Container ptr;
    for(Pointer p : data)
    {
        if(p->reading()>15 && p->type()==SensorType::TYRE_PRESSIRE)
        {
            ptr.emplace_back(p);
        }
    }
    return ptr;
}
