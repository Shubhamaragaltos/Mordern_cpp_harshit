#include "Functionalities.h"

void CreateObject(Container &data)
{
  
    data.emplace_back(std::make_shared<TouristVehicle>("19MEJ03",
                                                       VehicleType::BUS,
                                                       32, std::make_shared<VehiclePermit>("1001", PermitType::LEASED, 30, 15000)));

    data.emplace_back(std::make_shared<TouristVehicle>("19M903",
                                                       VehicleType::BIKE,
                                                       2, std::make_shared<VehiclePermit>("1002", PermitType::OWNED, 356, 2000)));

    data.emplace_back(std::make_shared<TouristVehicle>("7EJ03",
                                                       VehicleType::CAB,
                                                       5, std::make_shared<VehiclePermit>("1003", PermitType::OWNED, 245, 7000)));
}

Container Find_Instances_SeatCount_Permit(Container &data)
{
    Container temp{};
    if (data.empty())
    {
        throw std::runtime_error("\nCONTAINER IS EMPTY\n");
    }
    for (Pointer &p : data)
    {
        if (p->seatCount() >= 4 && p->getPtr()->permitType() == PermitType::LEASED)
        {
            temp.emplace_back(p);
        }
    }
    if (temp.empty())
    {
        throw std::runtime_error("\nNOT FOUND\n");
    }
    return temp;
}

float Average_permit_duaration(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("\nCONTAINER IS EMPTY\n");
    }
    float Total = 0;
    int count=0;

    for (Pointer &p : data)
    {
        if (p->type() == VehicleType::CAB)
        {
            Total = Total + p->getPtr()->permitDaurationLeft();
           count++;
        }
    }

    return Total / count;
}

Pointer Per_hour_booking_charge(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("\nCONTAINER IS EMPTY\n");
    }
      Pointer t;
    auto itr = data.begin();
    float min = (*itr)->getPtr()->permitRenewalCharges();
    for (Pointer P : data)
    {
        if (P->getPtr()->permitRenewalCharges() < min)
        {
            min = P->getPtr()->permitRenewalCharges();
            t=P;

        }
    }
    

    return t;
}

Container N_Instances(Container data, int number)
{
    
    if (data.empty())
    {
        throw std::runtime_error("\nCONTAINER IS EMPTY\n");
    }
    for (int i=0; i<data.size()-number; i++)
    {
        data.pop_front();
    }
    return data;
}
