#include "TouristVehicle.h"

TouristVehicle::TouristVehicle(std::string number, VehicleType type, int seatCount, std::shared_ptr<VehiclePermit> ptq)
    : _number(number), _type(type), Seat_count(seatCount), ptr(ptq)
{
}
std::ostream &operator<<(std::ostream &os, const TouristVehicle &rhs)
{
    os << "_number: " << rhs._number
       << " _type: " << static_cast<int>(rhs._type)
       << " Seat_count: " << rhs.Seat_count
       << " ptr: " << *rhs.ptr;
    return os;
}
