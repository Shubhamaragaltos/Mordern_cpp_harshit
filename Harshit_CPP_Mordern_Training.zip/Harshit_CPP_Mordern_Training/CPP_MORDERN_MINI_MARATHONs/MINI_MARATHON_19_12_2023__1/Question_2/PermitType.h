#ifndef PERMITTYPE_H
#define PERMITTYPE_H

enum class PermitType{
    LEASED,OWNED
};

#endif // PERMITTYPE_H
