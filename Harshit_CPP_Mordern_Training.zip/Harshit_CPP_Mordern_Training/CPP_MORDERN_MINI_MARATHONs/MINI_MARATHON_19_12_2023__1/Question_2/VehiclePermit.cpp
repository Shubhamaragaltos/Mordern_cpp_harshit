#include "VehiclePermit.h"
std::ostream &operator<<(std::ostream &os, const VehiclePermit &rhs) {
    os << "_serial_number: " << rhs._serial_number
       << " _permit_type: " << static_cast<int> (rhs._permit_type)
       << " _permit_dauration_left: " << rhs._permit_dauration_left
       << " _permit_renewal_charges: " << rhs._permit_renewal_charges;
    return os;
}


VehiclePermit::VehiclePermit(std::string serialnumber, PermitType ptype, int permitDuration, float Renewal_charges)
: _serial_number(serialnumber), _permit_type(ptype),_permit_dauration_left(permitDuration), _permit_renewal_charges(Renewal_charges)
{

}
