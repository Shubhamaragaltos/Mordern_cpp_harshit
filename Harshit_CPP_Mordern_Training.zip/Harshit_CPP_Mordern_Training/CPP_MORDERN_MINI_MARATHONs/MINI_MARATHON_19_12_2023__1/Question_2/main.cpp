#include "Functionalities.h"

#include <iostream>

int main()
{

    Container obj;

    std::cout << "\n================ CreateObject==================\n";
    CreateObject(obj);
    std::cout << "\n================ Find INstance==================\n";
    try
    {
        Container tem = Find_Instances_SeatCount_Permit(obj);
        auto itr = obj.begin();
        for (Pointer p : tem)
        {
            std::cout << "\n"
                      << **itr << "\n";
            itr++;
        }
    }
    catch (std::runtime_error &e)
    {
        std::cerr << e.what() << "\nERROR in FUNCTION\n";
    }

    std::cout << "\n================ Average==================\n";
    try
    {
        float ans = Average_permit_duaration(obj);
        
        std::cout << "\n"
                  << ans<< "\n";
    }
    catch (std::runtime_error &e)
    {
        std::cerr << e.what() << "\nERROR in FUNCTION\n";
    }

    std::cout << "\n================ Minimum charges==================\n";
    try
    {
        Pointer p = Per_hour_booking_charge(obj);
        std::cout << "\n"
                  << *p << "\n";
    }
    catch (std::runtime_error &e)
    {
        std::cerr << e.what() << "\nERROR in FUNCTION\n";
    }

    std::cout << "\n================ N instance==================\n";
    try
    {
        Container temp = N_Instances(obj,2);
        auto iitr = temp.begin();
        for (Pointer p : temp)
        {
            std::cout << "\n"
                      << **iitr << "\n";
            iitr++;
        }
    }
    catch (std::runtime_error &e)
    {
        std::cerr << e.what() << "\nERROR in FUNCTION\n";
    }
}
