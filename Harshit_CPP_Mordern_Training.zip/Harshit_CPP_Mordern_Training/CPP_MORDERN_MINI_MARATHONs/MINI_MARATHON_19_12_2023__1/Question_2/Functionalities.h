#include<iostream>
#include<memory>
#include"TouristVehicle.h"
#include<list>

using Pointer = std::shared_ptr<TouristVehicle>;
using Container = std::list<Pointer>;

void CreateObject(Container& data);
Container Find_Instances_SeatCount_Permit(Container& data);
float Average_permit_duaration(Container& data);
Pointer Per_hour_booking_charge(Container& data);
Container N_Instances(Container data, int number);