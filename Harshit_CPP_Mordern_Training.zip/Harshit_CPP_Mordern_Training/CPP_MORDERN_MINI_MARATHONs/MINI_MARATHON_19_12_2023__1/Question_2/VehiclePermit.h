#ifndef VEHICLEPERMIT_H
#define VEHICLEPERMIT_H

#include<iostream>
#include"PermitType.h"

class VehiclePermit
{
private:
    std::string _serial_number;
    PermitType _permit_type;
    int _permit_dauration_left;
    float _permit_renewal_charges;
public:
    VehiclePermit(/* args */) = default;
    VehiclePermit(std::string serialnumber, PermitType ptype, int permitDuration, float Renewal_charges);
    VehiclePermit(const VehiclePermit &) = delete;
    VehiclePermit(VehiclePermit &&) = delete;
    VehiclePermit &operator=(const VehiclePermit &) = delete;
    VehiclePermit &operator=(VehiclePermit &&) = delete;
    ~VehiclePermit()= default;

    std::string serialNumber() const { return _serial_number; }

    int permitDaurationLeft() const { return _permit_dauration_left; }

    float permitRenewalCharges() const { return _permit_renewal_charges; }

    PermitType permitType() const { return _permit_type; }

    friend std::ostream &operator<<(std::ostream &os, const VehiclePermit &rhs);
};

#endif // VEHICLEPERMIT_H
