#ifndef TOURISTVEHICLE_H
#define TOURISTVEHICLE_H

#include<iostream>
#include"VehicleType.h"
#include<memory>
#include"VehiclePermit.h"

class TouristVehicle
{
private:
    std::string _number;
    VehicleType _type;
    int Seat_count;
    std::shared_ptr<VehiclePermit> ptr;
    
    
public:
    TouristVehicle(/* args */) = default;
    TouristVehicle(std::string number, VehicleType type, int seatCount, std::shared_ptr<VehiclePermit> ptq);
    TouristVehicle(const TouristVehicle &) = delete;
    TouristVehicle(TouristVehicle &&) = delete;
    TouristVehicle &operator=(const TouristVehicle &) = delete;
    TouristVehicle &operator=(TouristVehicle &&) = delete;
    ~TouristVehicle()= default;

    std::string number() const { return _number; }

    VehicleType type() const { return _type; }

    int seatCount() const { return Seat_count; }

    std::shared_ptr<VehiclePermit> getPtr() const { return ptr; }

    friend std::ostream &operator<<(std::ostream &os, const TouristVehicle &rhs);
};
#endif // TOURISTVEHICLE_H
