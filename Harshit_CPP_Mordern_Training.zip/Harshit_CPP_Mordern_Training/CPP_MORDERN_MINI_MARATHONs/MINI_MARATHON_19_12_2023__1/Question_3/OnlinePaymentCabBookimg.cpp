#include "OnlinePaymentCabBookimg.h"

OnlinePaymentCabBookimg::OnlinePaymentCabBookimg(std::string bookingID, std::string pickupLocation, std::string droplocation, float base_price, int dropcount, PaymentMode pm)
    : CabBooking(bookingID, pickupLocation, droplocation, base_price), _drop_stop_count(dropcount), pmode(pm)
{
}

float OnlinePaymentCabBookimg::CabFareCalculation()
{
    float ans = 0;
    if (PaymentMode::ONLINE_WALLET == getPmode())
    {
        ans = baseFare() + (baseFare()*0.01);
        return ans;
    }
    else
    {
        return ans = baseFare() * dropStopCount();
    }
}

std::ostream &operator<<(std::ostream &os, const OnlinePaymentCabBookimg &rhs)
{
    os << static_cast<const CabBooking &>(rhs)
       << " pmode: " << static_cast<int>(rhs.pmode)
       << " _drop_stop_count: " << rhs._drop_stop_count;
    //   << " ptr: " << rhs.ptr;
    return os;
}
