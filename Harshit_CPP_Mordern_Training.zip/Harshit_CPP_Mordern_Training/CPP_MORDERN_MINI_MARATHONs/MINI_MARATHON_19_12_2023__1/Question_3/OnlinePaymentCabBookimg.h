#ifndef ONLINEPAYMENTCABBOOKIMG_H
#define ONLINEPAYMENTCABBOOKIMG_H

#include <iostream>
#include "CabBooking.h"
#include "PaymentMode.h"
#include <memory>
#include"CashPamentCabBookin.h"

class OnlinePaymentCabBookimg : public CabBooking
{
private:
    PaymentMode pmode;
    int _drop_stop_count;

public:
    OnlinePaymentCabBookimg(/* args */) = default;
    OnlinePaymentCabBookimg(std::string bookingID, std::string pickupLocation, std::string droplocation, float base_price,int dropcount, PaymentMode pm);
    OnlinePaymentCabBookimg(const OnlinePaymentCabBookimg &) = delete;
    OnlinePaymentCabBookimg(OnlinePaymentCabBookimg &&) = delete;
    OnlinePaymentCabBookimg &operator=(const OnlinePaymentCabBookimg &) = delete;
    OnlinePaymentCabBookimg &operator=(OnlinePaymentCabBookimg &&) = delete;
    ~OnlinePaymentCabBookimg() = default;
    float CabFareCalculation() override;

    int dropStopCount() const { return _drop_stop_count; }

    PaymentMode getPmode() const { return pmode; }


    friend std::ostream &operator<<(std::ostream &os, const OnlinePaymentCabBookimg &rhs);

};

#endif // ONLINEPAYMENTCABBOOKIMG_H
