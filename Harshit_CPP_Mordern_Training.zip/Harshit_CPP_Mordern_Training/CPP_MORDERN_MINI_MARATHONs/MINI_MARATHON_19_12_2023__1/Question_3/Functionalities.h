#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include "OnlinePaymentCabBookimg.h"
#include"CabBooking.h"
#include <memory>
#include <vector>

using Pointer = std::shared_ptr<CabBooking>;
using Container = std::vector<Pointer>;

void CreateObject(Container &data);

Container Find_base_fare_(Container &data, std::string booking__ID);

Pointer find (Container &data);

Container N__instance(Container data);
Container N_instance(Container data);

bool CAB_fare_1000(Container &data);
float Average_base_fare(Container &data);

#endif // FUNCTIONALITIES_H
