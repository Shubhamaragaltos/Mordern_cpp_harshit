#include "Functionalities.h"

void CreateObject(Container &data)
{
    data.emplace_back(std::make_shared<OnlinePaymentCabBookimg>("1001", "phase1", "phase2", 150, 1, PaymentMode::UPI));
    data.emplace_back(std::make_shared<OnlinePaymentCabBookimg>("1002", "phase2", "phase3", 250, 2, PaymentMode::CARD));
    data.emplace_back(std::make_shared<OnlinePaymentCabBookimg>("1003", "swargate", "phase2", 550, 3, PaymentMode::ONLINE_WALLET));
    //========================================
    data.emplace_back(std::make_shared<CashPamentCabBookin>("1004", "swargate", "whagoli",45,100));
    data.emplace_back(std::make_shared<CashPamentCabBookin>("1005", "phase1", "shivaji", 270, 50));
    data.emplace_back(std::make_shared<CashPamentCabBookin>("1006", "pmc", "bala", 189, 20));
}

Container Find_base_fare_(Container &data, std::string booking__ID)
{
    Container ptr;
    for(Pointer p : data)
    {
        if(p->bookingId()==booking__ID)
        {
            ptr.emplace_back(p);
        }
    }
    return ptr;
}
//=======================================================================
Container N_instance(Container data)
{
    for(Pointer& p: data)
    {
        if(std::shared_ptr<OnlinePaymentCabBookimg> cast = std::dynamic_pointer_cast<OnlinePaymentCabBookimg>(p))
        {
            data.emplace_back(p);

        }
    }
    return data;

}

Container N__instance(Container data)
{
     for(Pointer& p: data)
    {
        if(p->pickupLocation()
        {
            data.emplace_back(p);

        }
    }
    return data;
}

bool CAB_fare_1000(Container &data)
{

    return false;
}

float Average_base_fare(Container &data)
{
    return 0.0f;
}
