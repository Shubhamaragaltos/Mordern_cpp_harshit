#include<iostream>

#include"Functionalities.h"

int main()
{
    Container ptr;
    CreateObject(ptr);
    std::cout<<"\n++++++++++++++++++++++++++++\n";
    Container pin=  Find_base_fare_(ptr,"1001");
    auto itr= pin.begin();
    for(Pointer p : pin)
    {
        std::cout<<**itr;
        itr++;
    }
}