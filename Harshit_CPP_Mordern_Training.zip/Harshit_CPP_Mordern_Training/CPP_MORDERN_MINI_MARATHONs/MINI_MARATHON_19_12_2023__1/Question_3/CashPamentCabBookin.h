#ifndef CASHPAMENTCABBOOKIN_H
#define CASHPAMENTCABBOOKIN_H

#include<iostream>
#include"CabBooking.h"

class CashPamentCabBookin: public CabBooking
{
private:
    int _reward_point_claimed;
    

public:
  CashPamentCabBookin(/* args */) = default;
    CashPamentCabBookin(std::string bookingID, std::string pickupLocation, std::string droplocation, float base_price,int rewadPoint );
    CashPamentCabBookin(const CashPamentCabBookin &) = delete;
    CashPamentCabBookin(CashPamentCabBookin &&) = delete;
    CashPamentCabBookin &operator=(const CashPamentCabBookin &) = delete;
    CashPamentCabBookin &operator=(CashPamentCabBookin &&) = delete;
    ~CashPamentCabBookin() = default;
    float CabFareCalculation() override;

    int rewardPointClaimed() const { return _reward_point_claimed; }

    friend std::ostream &operator<<(std::ostream &os, const CashPamentCabBookin &rhs);
};

#endif // CASHPAMENTCABBOOKIN_H
