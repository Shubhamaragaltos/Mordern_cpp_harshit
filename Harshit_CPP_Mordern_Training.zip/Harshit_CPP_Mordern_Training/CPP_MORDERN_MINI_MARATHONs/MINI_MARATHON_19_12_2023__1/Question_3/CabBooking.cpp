#include "CabBooking.h"

CabBooking::CabBooking(std::string bookingID, std::string pickupLocation, std::string droplocation, float base_price)
: _booking_id(bookingID), _pickup_location(pickupLocation),_drop_location(droplocation),_base_fare(base_price)
{
}
std::ostream &operator<<(std::ostream &os, const CabBooking &rhs) {
    os << "_booking_id: " << rhs._booking_id
       << " _pickup_location: " << rhs._pickup_location
       << " _drop_location: " << rhs._drop_location
       << " _base_fare: " << rhs._base_fare;
    return os;
}
