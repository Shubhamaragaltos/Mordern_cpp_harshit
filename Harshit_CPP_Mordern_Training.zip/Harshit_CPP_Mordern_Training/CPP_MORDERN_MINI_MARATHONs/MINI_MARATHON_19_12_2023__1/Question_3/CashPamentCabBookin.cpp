#include "CashPamentCabBookin.h"

std::ostream &operator<<(std::ostream &os, const CashPamentCabBookin &rhs)
{
    os << static_cast<const CabBooking &>(rhs)
       << " _reward_point_claimed: " << rhs._reward_point_claimed;
    return os;
}

CashPamentCabBookin::CashPamentCabBookin(std::string bookingID, std::string pickupLocation, std::string droplocation, float base_price, int rewadPoint)
    : CabBooking(bookingID, pickupLocation, droplocation, base_price), _reward_point_claimed(rewadPoint)

{
}

float CashPamentCabBookin::CabFareCalculation()
{
    float abs = baseFare() * 2;

    if (_reward_point_claimed < (0.25 * baseFare()))
    {
        return abs;
    }
    return abs;
}