#include <iostream>
#include <future>

void Square(std::future<int> &ft)
{
    std::cout << "\nSquare is started";
    int number = ft.get();
    std::cout << "\n square is : " << number * number;
}

int main()
{
    int num = 8;

    std::promise<int> pr;
    std::future<int> ft = pr.get_future();


    std::future<void> ans_ft = std::async(std::launch::async, &Square, std::ref(ft));

    // std::cin>>num;
    return 0;
}