#include<iostream>
#include<future>



int sqouare(std::future<int> &ft)
{
    std::cout<<"\nSquare is started\n";

    int number = ft.get();
    return number*number;


}
int factorial(int number)
{
    if(number<0)
    {
       
            throw std::runtime_error("The number is negative \n");
    }
    else if(number ==1 || number==0)
    {
        return 1;
    }
    else{

    return number * factorial(number-1);
    }
}



int main()
{
    std::promise<int> pr;
    std::future<int> ft= pr.get_future();
    std::future<int> result_ft = std::async(std::launch::async,&sqouare,std::ref(ft));
    int num=0;
    std::cin>>num;
    pr.set_value(num);
    std::cout<<factorial(4);

    std::cout<<"\nthe squares: "<<result_ft.get();



int val{0};
std::cin>>val;




}