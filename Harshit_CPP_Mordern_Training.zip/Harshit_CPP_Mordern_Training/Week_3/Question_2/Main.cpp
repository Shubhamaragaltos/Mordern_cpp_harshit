
#include "Functionalities.h"
#include "thread"

int main()
{

        Container ptr;

        // CreateObject(ptr);

        std::thread t1(&CreateObject, std::ref(ptr));
        t1.join();

        std::thread t2([](Container data)
                       {
        ProductType Type = ProductType::APPLIANCE;
    int sum = 0;
    int count = 0;
    for (auto p : data)
    {
        if (p->ptype() == Type)
        {
            sum = sum + p->productVale();
            count++;
        }
    }
    std::cout<< sum / count; },
                       ptr);

        t1.join();

        std::cout << "\n\n===================================================================================\n\n";

        // std::cout << "\nThe Average:  " << AverageProductPrice(ptr, ProductType::APPLIANCE) << std::endl;

        //         std::cout << "\n\n===================================================================================\n\n";

        //         std::cout << "\n Tax Amount : " << MaximumProductTaxAmount(ptr);
        //         std::cout << "\n\n===================================================================================\n\n";

        //         Pointer p = ProductInstanceByBrand(ptr, "MI");

        //         std::cout << "\n"
        //                   << *p;
        //         std::cout << "\n\n===================================================================================\n\n";

        //         Container ans = N_Instance(ptr, 1);
        //         for (auto p : ans)
        //         {
        //                 std::cout << "\n"
        //                           << *p;
        //         }

        //         std::cout << "\n\n============UNQUIE=======================================================================\n\n";

        // Container ans1 = UnquieProductBrand(ptr,"HI");
        //         for (auto p : ans1)
        //         {
        //                 std::cout << "\n"
        //                           << *p;
        //         }
}