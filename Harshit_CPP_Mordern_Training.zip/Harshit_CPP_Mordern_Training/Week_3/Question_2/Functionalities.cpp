#include "Functionalities.h"

void CreateObject(Container &data)
{
    data.emplace_back(
        std::make_shared<Product>(
            "101",
            "MI",
            12000,
            ProductType::APPLIANCE,
            ProductOrigin::IMPORTED));
    data.emplace_back(
        std::make_shared<Product>(
            "102",
            "SONY",
            12000,
            ProductType::APPLIANCE,
            ProductOrigin::IMPORTED));
    data.emplace_back(
        std::make_shared<Product>(
            "103",
            "SONY",
            12000,
            ProductType::APPLIANCE,
            ProductOrigin::IMPORTED));
    data.emplace_back(
        std::make_shared<Product>(
            "104",
            "MI",
            12000,
            ProductType::APPLIANCE,
            ProductOrigin::IMPORTED));

    // data.emplace_back(std::make_shared<Product>("105",1233,ProductType::APPLIANCE,ProductOrigin::DOMESTIC,"SAN"));
    // data.emplace_back(std::make_shared<Product>("102", 50, ProductType::FOOD, ProductOrigin::DOMESTIC, "SONY"));

    // data.emplace_back(std::make_shared<Product>("103", 2000, ProductType::PERFUME, ProductOrigin::IMPORTED, "MI"));

    // data.emplace_back(std::make_shared<Product>("104", 30000, ProductType::APPLIANCE, ProductOrigin::DOMESTIC, "KPIT"));
}

std::function<float(Container &data, ProductType Type)> AverageProductPrice = [](Container &data, ProductType Type)
{
    int sum = 0;
    int count = 0;
    for (auto p : data)
    {
        if (p->ptype() == Type)
        {
            sum = sum + p->productVale();
            count++;
        }
    }
    return sum / count;
};

std::function<float(Container &data)> MaximumProductTaxAmount = [](Container &data)
{
    auto itr = data.front();
    int max = itr->productTaxAmount();

    for (auto p : data)
    {
        if (max < p->productTaxAmount())

        {
            max = p->productTaxAmount();
        }
    }
    return max;
};

std::function<Container(Container &data, int N)> N_Instance = [](Container &data, int N)
{
    Container result;
    auto itr = data.rbegin();

    //  auto itr = data.end();
    // --itr;
    //  std::cout << "The last: " << **itr << "\n";
    while (N > 0)
    {
        result.emplace_back(*itr);

        itr++;
        N--;
    }

    return result;
};

std::function<Pointer(Container &data, std::string Brand)> ProductInstanceByBrand = [](Container &data, std::string Brand)
{
    for (auto p : data)
    {
        if (p->productBrand() == Brand)
        {
            return p;
        }
    }

    throw std::runtime_error("ERROR");
};

std::function<Container(Container &data, std::string Brand)> UnquieProductBrand = [](Container &data, std::string Brand)
{
    Container result;
    int i = 0, j = 0;
    int n = 0;
    int flag = 0;
    for (auto p : data)
    {
        for (auto p : data)
        {
            
        }
    }
    return result;
};

// std::function<int(Container &data)> ArrayOFinteger;
