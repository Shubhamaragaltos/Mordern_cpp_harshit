#include <iostream>

class Parent
{
private:
    int n;

public:
    Parent(/* args */) {}
    explicit Parent(int i) : n(i) {}
    void display()
    {
        std::cout << "\nhello world";
    }
    ~Parent()
    {
        std::cout << "\n"
                  << "Parent costructor called";
    }
};
class child : public Parent
{
private:
    /* data */
public:
    child(/* args */) {}
    void display()
    {
        std::cout << "\nhi";
    }
    ~child()
    {
        std::cout << "\n"
                  << " child destructor called";
    }
   
};
    void magic (int n,int p)
   {
    std::cout<<n<<std::endl;
        std::cout<<p<<std::endl;

   }

 
int main()
{
 //demo p;
 child pr;
   Parent pt; 
   magic(2.0,4.4);

}