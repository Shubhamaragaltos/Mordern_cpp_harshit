    #include"Car.h"

std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "_id: " << rhs._id
       << " _Price: " << rhs._Price;
    return os;
}

Car::Car(std::string carId, float CarPrice, VhechileType Carty):
_id(carId),_Price(CarPrice), _Type(Carty)
{
}
