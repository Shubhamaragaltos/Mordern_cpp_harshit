#include "Functionalities.h"

void CreateObjects(Container &data)
{
    data.emplace_back(std::make_shared<Car>("C-101", 8.0f, VhechileType::SEDAN));
    data.emplace_back(std::make_shared<Car>("C-102", 8433000.0f, VhechileType::HATCHBACK));
    data.emplace_back(std::make_shared<Car>("C-103", 340000.0f, VhechileType::SUV));

    data.emplace_back(std::make_shared<Bike>("B-101", 55000.0f, VhechileType::COMMUTE));
    data.emplace_back(std::make_shared<Bike>("B-102", 250000.0f, VhechileType::SPORTS));
    data.emplace_back(std::make_shared<Bike>("B-103", 120000.0f, VhechileType::COMMUTE));
}

float AveragePrice(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("empty data");
    }
    long total_Price = 0.0f;
    for (VType v : data)
    {
        std::visit([&](auto &&val)
                   {
                       total_Price = total_Price + val->price();
                   },
                   v);
    }
    //std::cout<<"\nTotal Price = "<<total_Price;
    return total_Price/data.size();
}

VType Minimum_Price_Instance(const Container &data)
{
    auto itr=data.front();
    int min=0;
    std::visit([&](auto&& val){
        min = val->price();
    },itr);
    VType ans = itr;
    for(VType v : data)
    {
        std::visit([&](auto&& val){
            if(val->price()<min)
            {
                min = val->price();
                ans = v;

            }
        },v);
    }
    return ans;
}

bool ifIdExist(const Container &data, std::string _id)
{
    bool flag = false;
     if (data.empty())
    {
        throw std::runtime_error("empty data");
    }
    for(VType v : data)
    {
        std::visit([&](auto&& val){
            if(_id == val->id())
            {
                flag=true;
            }

        },v);
    }
    return flag;

}





