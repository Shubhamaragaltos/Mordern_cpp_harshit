#ifndef BIKE_H
#define BIKE_H

#include<iostream>
#include"VhechileType.h"

class Bike
{
private:
    std::string _id;
    float _Price;
    VhechileType _Type;

public:
     Bike(/* args */) = default;
    Bike(Bike &&) = default;
    Bike(const Bike &) = default;
    Bike &operator=(const Bike &) = default;
    Bike &operator=(Bike &&) = default;
    ~Bike()=default;
    Bike(std::string BikeId, float BikePrice, VhechileType bikety);

    std::string id() const { return _id; }

    float price() const { return _Price; }

    VhechileType type() const { return _Type; }

    friend std::ostream &operator<<(std::ostream &os, const Bike &rhs);
};

#endif // BIKE_H
