#ifndef CARTYPE_H
#define CARTYPE_H

enum class VhechileType
{

    SEDAN,
    SUV,
    HATCHBACK,
    SPORTS,
    COMMUTE

};

#endif // CARTYPE_H
