#ifndef CAR_H
#define CAR_H

#include <iostream>
#include "VhechileType.h"

class Car
{
private:
    std::string _id;
    float _Price;
    VhechileType _Type;

public:
    Car(/* args */) = default;
    Car(Car &&) = default;
    Car(const Car &) = default;
    Car &operator=(const Car &) = default;
    Car &operator=(Car &&) = default;
    ~Car()=default;
    Car(std::string carId, float CarPrice, VhechileType Carty);

    std::string id() const { return _id; }

    float price() const { return _Price; }

    VhechileType type() const { return _Type; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
    

};

#endif // CAR_H
