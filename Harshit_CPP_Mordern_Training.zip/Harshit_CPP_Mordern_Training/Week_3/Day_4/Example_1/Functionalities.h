#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include<memory>
#include<optional>
#include<variant>
#include"Bike.h"
#include"Car.h"
#include<list>


using BikePointer = std::shared_ptr<Bike>;
using CarPointer = std::shared_ptr<Car>;
using VType = std::variant<BikePointer,CarPointer>;
using Container = std::list<VType>;
/*
    # Taking an empty Container by lvalue referance and fill it ith variant objects
    # It should be return Void
*/

void CreateObjects(Container& data);
/*
  Average Price can be found using visit and total.

*/
float AveragePrice( Container& data);
/*
    Find instance with minimum price(all vehicles have prices which are unique)

*/
VType Minimum_Price_Instance(const Container& data);
/*

Check id given id Present in any of the instance
*/
bool ifIdExist(const Container& data,std::string _id);
/*
Return all instanse whose type matches with type passed

*/
inline std::optional<Container> Instances_Matching_Type( Container& data, VhechileType type)
{

     if (data.empty())
    {
        throw std::runtime_error("empty data");
    }
    Container result;

    for(VType v : data)
    {
        std::visit([&](auto&& val){
            if(val->type()==type){result.emplace_back(val);}}
        ,v);
    }
    if(result.empty()){
        return std::nullopt;
    }
     return result;
    
}




#endif // FUNCTIONALITIES_H
