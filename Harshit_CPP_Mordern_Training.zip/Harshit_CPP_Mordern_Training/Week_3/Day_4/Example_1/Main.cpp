#include <iostream>

#include "Functionalities.h"

int main()
{
  Container ptr;
  CreateObjects(ptr);
  std::cout << "\n===================================================================================\n";
  long as1 = AveragePrice(ptr);
  std::cout << "The Average price: " << as1;

  std::cout << "\n===================================================================================\n";

  VType ans = Minimum_Price_Instance(ptr);
  std::visit([](auto &&val)
             { std::cout << "The minimum price : " << *val; },
             ans);
  std::cout << "\n===================================================================================\n";

  std::cout << "The Bool OF if : " << ifIdExist(ptr, "B-191");
  std::cout << "\n===================================================================================\n";
try{
  std::optional<Container> result1 = Instances_Matching_Type(ptr, VhechileType::SPORTS);
  if (result1.has_value())
  {
    for (auto P : result1.value())

    {
      std::visit([](auto &&val)
                 { std::cout << *val << "\n"; },
                 P);
    }
  }
}
catch(std::runtime_error &mess){
  std::cout<<mess.what();
}
}
