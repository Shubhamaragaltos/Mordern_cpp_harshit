#include "Bike.h"

Bike::Bike(std::string BikeId, float BikePrice, VhechileType bikety)
:_id(BikeId), _Price(BikePrice),_Type(bikety)
{
}
std::ostream &operator<<(std::ostream &os, const Bike &rhs) {
    os << "_id: " << rhs._id
       << " _Price: " << rhs._Price
       << " _Type: " << static_cast<int>(rhs._Type);
    return os;
}
