#include <mutex>
#include <thread>
#include <iostream>
#include <array>
std::mutex mt;

void CalculationSquare(std::array<int, 5> &arr)
{
    for (int val : arr)
    {
        std::lock_guard<std::mutex> lk(mt);
        std::cout << val * val << "\t";
    }
    std::cout << "\n+++++++++++++++++++++++++++++++++++++++++++++++++++++++\n";
}

void CalculationCube(std::array<int, 5> &arr)
{
    for (int val : arr)
    {
        std::lock_guard<std::mutex> lk(mt);
        std::cout << val * val * val << "\t";
    }
    std::cout << "\n+++++++++++++++++++++++++++++++++++++++++++++++++++++++\n";
}
int main()
{
    std::array<int, 5> arr{1, 2, 3, 4, 5};

    std::thread t1(&CalculationSquare, std::ref(arr));
    std::thread t2(&CalculationCube, std::ref(arr));

    t1.join();
    t2.join();
}