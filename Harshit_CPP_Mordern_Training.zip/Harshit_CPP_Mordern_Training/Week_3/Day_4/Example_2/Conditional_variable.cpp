#include <iostream>
#include <condition_variable>
#include <math.h>
#include <thread>
#include <mutex>

int number = 0;
bool flag = false;

std::condition_variable cv;
std::mutex mt;

void Display_Square()
{
    std::unique_lock<std::mutex> ul(mt);

    cv.wait(ul, []()
            { return flag; });

            std::cout

        << "\n Square of number : " << number * number << "\n";
        
}
/*
    - Main will take cin inout and swuare and store value in a global varaible.
*/

int main()
{
    std::thread t1(&Display_Square);

    std::cin >> number;
    flag =true;
    cv.notify_all(); // signal sent from main to os that we can now invoke the wating thread.

    t1.join();
}