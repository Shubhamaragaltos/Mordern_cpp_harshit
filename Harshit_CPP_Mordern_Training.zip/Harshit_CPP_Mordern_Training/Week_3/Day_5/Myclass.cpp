#include <iostream>

class Myclass
{
private:
    int _id;

public:
    Myclass(/* args */) = delete;
    Myclass(int id) : _id(id) {}
    Myclass(const Myclass &) { std::cout << "Copy Constructor called\n"; };
    Myclass(Myclass &&)=default;
    Myclass &operator=(Myclass &&)=delete;
    Myclass &operator=(const Myclass &) =delete;

    ~Myclass() = default;
};
// step: 4--> signature is matched and magic is invoked
Myclass Magic(Myclass &obj) // Magic function take 1 non const l value refrence to myclass and return myclass by value
{                           // step 5: Temp object is instantiated by ""
    Myclass temp(obj);
    std::cout << "The address of TEMP : " << &temp << "\n";
    // step:7 return the temp
    return temp;
}

int main()
{
    // step 1: obj gets instantiated
    Myclass obj(100);
    // step 2: Address is printed (obj is in the stack of main function)
    std::cout << "The address of OBJ : " << &obj << "\n";
    // step 3: Call Magic function. whatever is returned from Magic will be saved
    // in return_obj varaiable
    Myclass return_obj = Magic(obj);
    // step 4: --->
    std::cout << "The address of Return_OBJ : " << &return_obj << "\n";
}