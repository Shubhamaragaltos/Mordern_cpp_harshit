/*
    create a thread t1 that calculates square of all members
    in an array and stores them in result container
*/

#include <array>
#include <thread>
#include<iostream>

int main()
{
    std::array<int, 5> data{10, 20, 30, 40, 50};
    std::array<int, 5> result{0};

    std::thread t1([&result](std::array<int, 5> &data)
                   {
int k=0;
for(int val:data)
{
    result[k++]=val*val;
} },
                   std::ref(data));

    t1.join();
    auto itr = data.begin();
    for (int val : result)
    {
        if (itr != data.end())
        {
            std::cout<< "Square Of : " << *itr << val << "\n";
            itr++;
        }
    }
}
