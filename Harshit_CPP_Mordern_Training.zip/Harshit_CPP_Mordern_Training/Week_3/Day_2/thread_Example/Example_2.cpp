/*
    create an array of 5 threads that calculate the square
    of ONE NUMBER FROM AN ARRAY OF 5 integers. store answers in a result cntainer


*/

#include <iostream>
#include <thread>
#include <array>
#include<functional>


void  InsatantialteThreads(std::array<std::thread,5>& threadArr,std::function<void(int,int)> f1,std::array<int,5>data)
{
     auto itr = data.begin();
    for (int i = 0; i < 5; i++)
    {
        threadArr[i] = std::thread(f1,*itr++,i);
    }

}

void JoinThread(std::array<std::thread,5>& threadArr)
{
    for (std::thread &t : threadArr)
    {
        if (t.joinable())
        {
            t.join();
        }
    }
}
void DisplayResult(std::array<int,5>& result, std::array<int,5>& data)
{
     auto itrr = data.begin();

    for (int val : result)
    {
        if (itrr != data.end())
        {
            std::cout << "SQUARE : " << *itrr << " IS : " << val << "\n";
            itrr++;
        }
    }
}

void StarApp()
{
    std::array<int, 5> data{10, 20, 30, 40, 50};
    std::array<int, 5> result{0};

    auto l1 = [&result](int number,int idx)
    { result[idx] = number * number; };

    std::array<std::thread, 5> threadARR;

    InsatantialteThreads(threadARR,l1,data);
    JoinThread(threadARR);
    DisplayResult(result,data);

}

int main()
{
    
   
    StarApp();
    return 0;

   
}