#include<iostream>
#include<thread>
#include<mutex>
/*
    100 withdraw transcation of 10 unnits each
    100 Depostil transcation of 10 unit each

*/
std::mutex mt;

int amount= 1000;

void withdraw()
{
    for(int i=0; i<100;i++){
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
        mt.lock();
        amount -=10;
        mt.unlock();
    }
}

void Deposit(){
    
    for(int i=0; i<100;i++){
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
        //crtical section
        mt.lock();
        amount +=10;
        mt.unlock();
    }
}

int main()
{
    std::thread t1(&withdraw);
    std::thread t2(&Deposit);

    t1.join();
    t2.join();

    std::cout<<"\n FINAL AMOUNT : "<<amount;
}