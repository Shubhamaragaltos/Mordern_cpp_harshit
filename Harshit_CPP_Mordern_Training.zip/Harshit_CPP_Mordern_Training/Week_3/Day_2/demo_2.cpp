#include <iostream>
#include <array>
#include <thread>
#include <functional>

std::array<int, 10> result{0};
std::function<void(std::array<int, 5> &data)> square = [](std::array<int, 5> &data)
{
    int k = 0;
    for (int val : data)
    {
        std::this_thread::sleep_for(std::chrono::seconds(1));

        result[k++] = val * val;
    }
      for (int val : result)
    {
        std::cout << val << "\t";
    }

};

int main()
{
    std::array<int, 5> data{1, 2, 3, 4, 5};

    std::thread t1(&square, std::ref(data));

    // std::thread t2([](std::array<int, 5> data)
    //                {
    // int k = 5;

    // for (int val : data)
    // {
    //     std::this_thread::sleep_for(std::chrono::seconds(1));
    //     result[k++] = val * val * val;
    // } },std::ref(data));

    t1.join(); // main get blocked till t1 complete the process.
  //  t2.join(); // main get blocked till t2 complete the process.
std::cout<<"\n T1 findhe: ";
    // for (int val : result)
    // {
    //     std::cout << val << "\t";
    // }

    return 0;
}