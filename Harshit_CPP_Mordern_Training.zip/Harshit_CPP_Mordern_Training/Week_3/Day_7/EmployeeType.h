#ifndef EMPLOYEETYPE_H
#define EMPLOYEETYPE_H

enum class EmployeeType{
    REGULAR, ELITE

};

#endif // EMPLOYEETYPE_H
