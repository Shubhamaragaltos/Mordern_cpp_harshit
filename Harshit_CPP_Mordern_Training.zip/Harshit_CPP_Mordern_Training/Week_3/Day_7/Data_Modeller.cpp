#include "Data_Modeller.h"

Data_Modeller::Data_Modeller(Vtype instance, const std::vector<float> &goodPrice) : _instance(std::move(instance)), _goodPrice(goodPrice)
{
}

void Data_Modeller::operator()()
{
    if (_goodPrice.empty())
    {
        throw std::runtime_error("Not Found");
    }
    float total = 0.0f;
    for (auto p : _goodPrice)
    {
        total += p;
    }
    std::cout << "\n Average vale is: " << total / _goodPrice.size() << "\n";
}

std::ostream &operator<<(std::ostream &os, const Data_Modeller &rhs)
{
    os << "_instance: ";
    std::visit([&](auto &&val)
               { os << *val; },
               rhs._instance);

    os << " _goodPrice: ";
         for (auto p : rhs._goodPrice)           
        {
            os<<p<<"\t";
        }
    return os;
}
