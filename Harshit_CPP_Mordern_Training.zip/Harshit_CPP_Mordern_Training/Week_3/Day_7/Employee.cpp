#include "Employee.h"

Employee::Employee(std::string name, EmployeeType type, float salary_int):_name(name),_type(type),_salary(salary_int)
{
    
}
std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_name: " << rhs._name
       << " _type: " <<static_cast<int> (rhs._type)
       << " _salary: " << rhs._salary;
    return os;
}
