#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include"Employee.h"
#include"BusinessOwner.h"
#include"Data_Modeller.h"
using DataPointer = std::unique_ptr<Data_Modeller>;
using Container = std::vector<DataPointer>;

void CreateObject(Container& data);
void CalculateTaxPayable(const Container& data);
void CallParenOperator (const Container& data);

#endif // FUNCTIONALITIES_H
