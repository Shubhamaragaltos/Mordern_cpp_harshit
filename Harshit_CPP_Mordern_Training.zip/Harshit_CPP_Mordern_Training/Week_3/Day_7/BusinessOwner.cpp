#include "BusinessOwner.h"

BusinessOwner::BusinessOwner(float expense, float revenue, std::string registeredBusiness, BussinessType Business_Type)
:_expense(expense), _revenue(revenue), _registered_Business(registeredBusiness), _Business_Type(Business_Type)
{
}
std::ostream &operator<<(std::ostream &os, const BusinessOwner &rhs) {
    os << "_expense: " << rhs._expense
       << " _revenue: " << rhs._revenue
       << " _registered_Business: " << rhs._registered_Business
       << " _Business_Type: " <<static_cast<int>(rhs._Business_Type);
    return os;
}
