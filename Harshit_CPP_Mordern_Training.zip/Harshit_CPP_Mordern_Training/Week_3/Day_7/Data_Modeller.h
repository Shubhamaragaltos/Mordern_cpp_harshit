#ifndef DATA_MODELLER_H
#define DATA_MODELLER_H
#include<iostream>
#include"Employee.h"
#include"BusinessOwner.h"
#include<variant>
#include<memory>
#include<vector>

using BusinessPointer = std::unique_ptr<BusinessOwner>;
using EmployeePointer = std::unique_ptr<Employee>;
using Vtype  = std::variant<BusinessPointer,EmployeePointer>;


class Data_Modeller
{
private:
Vtype _instance;
std::vector<float> _goodPrice;

public:

Data_Modeller(Vtype instance,const std::vector<float> &goodPrice);
void operator()();
~Data_Modeller()=default;
Data_Modeller()=default;
Data_Modeller(const Data_Modeller&)=delete;
Data_Modeller(Data_Modeller&&)=delete;
Data_Modeller operator=(const Data_Modeller&)=delete;
Data_Modeller operator=(Data_Modeller&&)=delete;

const Vtype& instance() const { return _instance; }

std::vector<float> goodPrice() const { return _goodPrice; }


friend std::ostream &operator<<(std::ostream &os, const Data_Modeller &rhs);

};

#endif // DATA_MODELLER_H
