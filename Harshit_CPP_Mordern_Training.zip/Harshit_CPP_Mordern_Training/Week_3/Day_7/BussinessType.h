#ifndef BUSSINESSTYPE_H
#define BUSSINESSTYPE_H

enum class BussinessType
{
    EXPORT,IMPORT

};

#endif // BUSSINESSTYPE_H
