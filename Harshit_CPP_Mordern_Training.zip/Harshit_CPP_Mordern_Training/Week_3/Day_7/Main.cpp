#include<iostream>
#include"Functionalities.h"
#include"thread"

using arr = std::array<int,3>;
int main()
{
    Container ptr;
std::thread t1(CreateObject,std::ref(ptr));
t1.join();

std::thread t2(CalculateTaxPayable,std::ref(ptr));

std::thread t3(CallParenOperator,std::ref(ptr));

t2.join();
std::cout<<"\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n";

t3.join();


}