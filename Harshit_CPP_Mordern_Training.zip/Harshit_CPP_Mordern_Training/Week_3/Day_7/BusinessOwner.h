#ifndef BUSINESSOWNER_H
#define BUSINESSOWNER_H
#include"BussinessType.h"
#include<iostream>
class BusinessOwner
{
private:
float _expense;
float _revenue;
std::string _registered_Business;
BussinessType _Business_Type;
public:
BusinessOwner(float expense, float revenue, std::string registeredBusiness, BussinessType Business_Type);//PC
~BusinessOwner()=default;
BusinessOwner()=default;
BusinessOwner(const BusinessOwner&)=delete;
BusinessOwner(BusinessOwner&&)=delete;
BusinessOwner operator=(const BusinessOwner&)=delete;
BusinessOwner operator=(BusinessOwner&&)=delete;

float getexpense() const { return _expense; }

float getrevenue() const { return _revenue; }

std::string getregisteredBusiness() const { return _registered_Business; }

BussinessType getbusinessType() const { return _Business_Type; }

friend std::ostream &operator<<(std::ostream &os, const BusinessOwner &rhs);
};

#endif // BUSINESSOWNER_H
