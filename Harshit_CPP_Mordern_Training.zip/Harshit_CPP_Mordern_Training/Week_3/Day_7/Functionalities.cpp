#include "Functionalities.h"
#include <mutex>
std::mutex mt;
void CreateObject(Container &data)
{
    data.emplace_back(std::make_unique<Data_Modeller>(

        std::make_unique<Employee>("SHUBHAM", EmployeeType::ELITE, 8999.0f), std::vector<float>{19.21f, 123.3f, 256.8f}

        ));

    data.emplace_back(std::make_unique<Data_Modeller>(

        std::make_unique<Employee>("ROHAN", EmployeeType::REGULAR, 5599.0f), std::vector<float>{19.21f, 123.3f, 256.8f}

        ));

    data.emplace_back(std::make_unique<Data_Modeller>(

        std::make_unique<BusinessOwner>(100, 2300, "EXPR", BussinessType::EXPORT), std::vector<float>{121.0f, 12.3f, 56.8f}

        ));

    data.emplace_back(std::make_unique<Data_Modeller>(

        std::make_unique<BusinessOwner>(145, 20000, "KPIT", BussinessType::IMPORT), std::vector<float>{124.0f, 132.3f, 536.8f}

        ));
}
/*
This Function will accept a container of DATA_Modeller pointer.

FOR EACH POINTER, perform the Following.

a) Capture the instance referance.
b) Use hold_alternative to verfiy which type of pointer is prsent in the _instance
c) if pointer is of type BussinessOWner.
    1) use std::get to fetch BusinessOWnerPointer (this will be safe because if has bee
        )
    2) use the fetched pointer in businessOwner to calculate tax for business

else when pointer is of type employee
    1) use std::get to fetch EmployeePointer
    2) use the fetched Pointer to fetchtype of pointer
    3) If type is REGULAR tax is 10% else it should 20% of salary




*/
void CalculateTaxPayable(const Container &data)
{
    for (const DataPointer &ptr : data)
    {
        const Vtype &val = ptr->instance();

        if (std::holds_alternative<BusinessPointer>(val))
        {
            const BusinessPointer &p = std::get<BusinessPointer>(val);
            mt.lock();
            std::cout << "\n The salary of Business: " << (0.10f * (p->getrevenue() - p->getexpense()));
            mt.unlock();
        }
        else
        {
            const EmployeePointer &y = std::get<EmployeePointer>(val);
            if (y->type() == EmployeeType::REGULAR)
            {
                std::lock_guard<std::mutex> lk(mt);
                std::cout << "\n The salary of Employee: " << (0.10 * (y->salary()));
            }
            else
            {
                std::lock_guard<std::mutex> lk(mt);
                std::cout << "\n The salary of Employee ELEITE: " << (0.20 * (y->salary()));
            }
        }
    }
}

void CallParenOperator(const Container &data)
{

    if (data.empty())
        throw std::runtime_error("No data exists in Container");

    else
    {
        for (const DataPointer &ptr : data)
        {
            std::lock_guard mlk(mt);
            ptr->operator()();
        }
    }
}
