#include <iostream>
#include <vector>
#include <optional>

void TakeInput(std::vector<int> &data, int N)
{
    int val = -1;
    for(int i=0; i<N; i++)
    {
        std::cin>>val;
        data[i]=val;
    }
   
    /*
        identify even number from data, store all of them in result
        result return

        scenario 1: there is at least 1 even number in data.
                    you identify the number. store in result.

        Scenario 2: data is empty. handle by rasing exception.

        Scenario 3: Data is not empty. Howerver, all number is ODD

    */
}

std::optional<std::vector<int>> ReturnEvenNumber(std::vector<int> &data)
{
    if (data.empty())
    {
        throw std::runtime_error("Error as data is empty");
    }
    
    std::vector<int> result;

    for (int v : data)
    {
        if (v % 2 == 0)
        {
            result.push_back(v);
        }
    }
    if (result.empty())
    {
        return std::nullopt;
    }
    return result;
}
int main()
{
    int N = -1;
  //  std::vector<int> data;
    std::cin >> N;
    std::vector<int> v1(N);

    TakeInput(v1, N);
    std::optional<std::vector<int>> Even_number = ReturnEvenNumber(v1);
    /*
        has_value return false if optional wrapper Contains nullopt
    */

    if (Even_number.has_value())
    /*

    */
    {
        std::cout << "\nThe size of contaoiner: " << Even_number.value().size() << "\n";
    }
    else
    {
        std::cout << "Vector Returned no values\n";
    }
}
