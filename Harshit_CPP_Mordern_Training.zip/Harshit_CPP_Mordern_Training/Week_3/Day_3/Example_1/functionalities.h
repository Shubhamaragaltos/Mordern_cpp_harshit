#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include <memory>
#include <vector>
#include "Employee.h"
#include "BusinessOwner.h"
#include <variant>

using EmPointer = std::shared_ptr<Employee>;
using BusinessPointer = std::shared_ptr<BusinessOwner>;

using Vtype = std::variant<EmPointer, BusinessPointer>;
using Conatiner = std::vector<Vtype>;


void CreateObject(Conatiner& data)
{
    data.emplace_back(std::make_shared<Employee>());
    data.emplace_back(std::make_shared<BusinessOwner>());
}
void Process(Conatiner& data)
{
    for(Vtype p : data)
    {
        
        std::visit([](auto &&val)
               { val->PayTax(); },
               p);
    }
}

#endif // FUNCTIONALITIES_H
