#include <iostream>
#include "BusinessOwner.h"
#include "Employee.h"
#include <variant>
#include <memory>
#include"functionalities.h"

int main()
{
    Conatiner ptr;
    CreateObject(ptr);
    Process(ptr);
    
    /*
    std::variant<Employee, BusinessOwner> v1;
    v1 = Employee();
    std::visit([](auto &&val)
               { val.PayTax(); },
               v1);

    v1 = BusinessOwner();
    std::visit([](auto &&val)
               { val.PayTax(); },
               v1);

    std::shared_ptr<Employee> E1 = std::make_shared<Employee>();
    std::variant<std::shared_ptr<Employee>, std::shared_ptr<BusinessOwner>> v2;

    v2 = E1;
    std::visit(
        [](auto &&val)
        { val->PayTax(); },
        v2);
*/



}