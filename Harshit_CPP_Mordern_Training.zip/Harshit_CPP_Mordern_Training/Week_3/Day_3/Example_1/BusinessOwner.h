#ifndef BUSINESSOWNER_H
#define BUSINESSOWNER_H

#include<iostream>
class BusinessOwner
{
private:
    /* data */
public:
    BusinessOwner(/* args */) {}
    ~BusinessOwner() {}
    void PayTax()
    {
        std::cout<<"\nBusiness has to pay advance tax and gst every month/quater\n\n";
    }
};

#endif // BUSINESSOWNER_H
