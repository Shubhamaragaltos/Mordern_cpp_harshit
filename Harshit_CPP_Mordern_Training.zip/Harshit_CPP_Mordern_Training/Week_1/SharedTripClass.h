#ifndef SHAREDTRIPCLASS_H
#define SHAREDTRIPCLASS_H

#include<iostream>
#include"TripClass.h"


class SharedTripClass: public TripClass
{
private:
    int shared_Trip_passenger;
    
public:
   SharedTripClass(/* args */)=default;
    SharedTripClass(std::string _trip_id,std::string _trip_driver,int trip_disatance, int trip_rating, RideType type,int Shared_trip);
    SharedTripClass(SharedTripClass&&)=delete;
    SharedTripClass(const SharedTripClass&)=delete;
    SharedTripClass &operator=(const SharedTripClass&)=delete;
    SharedTripClass &operator=(SharedTripClass&&)=delete;
    ~SharedTripClass() =default;
 float CalculateFare() override;
    int sharedTripPassenger() const { return shared_Trip_passenger; }
    void setSharedTripPassenger(int sharedTripPassenger) { shared_Trip_passenger = sharedTripPassenger; }

    friend std::ostream &operator<<(std::ostream &os, const SharedTripClass &rhs);
};

#endif // SHAREDTRIPCLASS_H
