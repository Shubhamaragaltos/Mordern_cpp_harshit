#ifndef VEHICLE_H
#define VEHICLE_H
#include <iostream>
#include "vehicleType.h"
class vehicle
{
private:
    int _id;
    std::string _model_name;
    float _price;
    vehicleType _type;
    /* data */
public:
    vehicle(int id, std::string model, float price, vehicleType type);
    // 1) deleted default constructon
    vehicle() = delete;

    // 2) COPY CONSTRUCTOR()Deleted copy constructor;
    vehicle(const vehicle &) = delete;

    // 3) copy assignment operator;
    vehicle &operator=(const vehicle &) = delete;

    // 4) move constructor
    vehicle(vehicle &&) = delete;

    // 5) move assignment
    vehicle &operator=(vehicle &&) = delete;

    // 6) defalut Destructor;
    ~vehicle(){
        std::cout<<"\nDestructor called\n";
    };

    float price() const { return _price; }

    int id() const { return _id; }
};

#endif // VEHICLE_H
