#include<iostream>

template<typename T>
class shared_ptr{
    private:
    

};