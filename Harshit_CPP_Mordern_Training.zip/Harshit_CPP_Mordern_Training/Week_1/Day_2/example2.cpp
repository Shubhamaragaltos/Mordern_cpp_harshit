#include <iostream>

int magic(int *arr, int size)
{
    for (int i = 0; i < size; i++)
    {
        /*
        *(arr+i) allow compiler to jump into a memory location starting from an offset of "i" positions
        from the base address stored in "arr".
        */
        std::cout << *(arr + i) << std::endl;
        std::cout << arr[i] << std::endl;
        std::cout << "====================\n";
    }
    return *arr;
}

int main()

{
    int arr[3] = {10, 20, 30};
    magic(arr, 3);
    std::cout << "++++++++++++++";


    return 0;
}