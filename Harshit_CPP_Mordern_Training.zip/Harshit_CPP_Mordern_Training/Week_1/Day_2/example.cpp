#include <iostream>

int main()
{
    int n1 = 10;

    int *ptr = &n1;

    int **ptr1 = &ptr;

    std::cout << "\ncontent of n : " << n1;
    std::cout << "\nAddress of n1 : " << &n1;
    std::cout << "\n content of ptr : " << ptr;
    std::cout << "\nAddress of ptr : " << &ptr;
    std::cout << "\ncontent of ptr1 : " << ptr1;
    std::cout << "\nAddress of ptr1 : " << &ptr1;
}