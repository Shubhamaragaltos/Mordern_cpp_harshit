#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include <memory>
#include <vector>
#include "Customer.h"

using Pointer = std::shared_ptr<Customer>;
using Pointer_debit = std::shared_ptr<Debit_Card>;
using Container = std::vector<Pointer>;


void createObject(Container &data) noexcept;
/* A function to find average age of coustomer*/
float AverageAge(Container &data);

/*
A function to return the Nth object from the conatiner
*/
Pointer NthCustomer(Container &data, int n);
/*
A function to find the age of the customer whose ID is provided as parameter;

*/
int AgeOfCustomer_ID(Container &data, int _id);

/*
A function to return the expiry date of debit card
whose cvv function matches with the values given by the user.

*/
int FindCvv(Container& data, int _id);
std::string CVV_Expiry_DATE(Container &data, int cvv);
/*
A function to return the conatinerof all pointers which point to customer with age above 50.

*/
Container AGE50(Container &data);
/*
A function to return a debit card pointer for a customer whose ID is given as an input parameter
*/
Pointer_debit DebitCardID(Container &data, int ID);

#endif // FUNCTIONALITIES_H
