#include "Debit_Card.h"

Debit_Card::Debit_Card(int _cvv, std::string _DebirName, std::string _Expiry, DebitCardType _type)
:CVV(_cvv), Debit_name(_DebirName), Expiry(_Expiry), Type_debit(_type)
{
}

std::ostream &operator<<(std::ostream &os, const Debit_Card &rhs) {
    os << "CVV: " << rhs.CVV
       << " Debit_name: " << rhs.Debit_name
       << " Expiry: " << rhs.Expiry
       << " Type_debit: " << static_cast<int>(rhs.Type_debit);
    return os;
}

