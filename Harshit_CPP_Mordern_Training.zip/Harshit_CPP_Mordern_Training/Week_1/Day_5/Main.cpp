#include <iostream>
#include <vector>
#include <memory>
#include "Customer.h"
#include "functionalities.h"

using Pointer = std::shared_ptr<Customer>;
using Container = std::vector<Pointer>;

int main()
{
    Container ptr;
    createObject(ptr);
    std::cout << "\n++++++++++++++++\n";
    std::cout << "1. The Average : " << AverageAge(ptr);
    std::cout << "\n++++++++++++++++\n";
    std::cout << "2. Find expiry date with the CVV : " << CVV_Expiry_DATE(ptr, 321);
    std::cout << "\n++++++++++++++++\n";
    std::cout << "3. Find the Age of customer for the Given ID: " << AgeOfCustomer_ID(ptr, 1002);
    std::cout << "\n++++++++++++++++\n";
    int ans = FindCvv(ptr, 1002);
    std::cout << "4. Find the CVV customer for the Given ID: " << ans;
    std::cout << "\n++++++++++++++++\n";
    std::cout << "5. Find debit card deatil for the given ID: \n";

    std::cout << *(DebitCardID(ptr, 1001));

    std::cout << "\n++++++++++++++++\n";
    std::cout << "6. Find Nth Customer : \n";
    std::cout << *(NthCustomer(ptr, 0));
    std::cout << "\n++++++++++++++++\n\n\n";
    std::cout << "7. Find 50 + age  Customer : \n";

    Container ans1 = AGE50(ptr);
    for (auto p : ans1)
    {
        std::cout << *p;
    }
    std::cout << "\n++++++++++++++++\n\n\n";

    return 0;
}
