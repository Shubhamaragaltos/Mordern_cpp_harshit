#include "functionalities.h"

void createObject(Container &data) noexcept
{
  data.emplace_back(
      std::make_shared<Customer>(
          1001,
          33,
          "SHUBHAM",
          CustomerType::ELEITE,
          std::make_shared<Debit_Card>(243, "Shubham Marewad", "28/11", DebitCardType::DOMESTIC))

  );

  data.emplace_back(
      std::make_shared<Customer>(
          1002,
          53,
          "Rohan Nakod",
          CustomerType::REGULAR,
          std::make_shared<Debit_Card>(321, "Rohan", "26/11", DebitCardType::INTERNATIONAL))

  );

  for (int i = 0; i < data.size(); i++)
  {
    std::cout << "===============================================================\n";

    std::cout << *(data[i]);
    std::cout << "===============================================================\n";
  }
}

float AverageAge(Container &data)
{
  if (data.empty())
  {
    throw std::runtime_error("Empty data");
  }
  float total = 0.0f;
  /*For - each loop (range based loop)
  For every pointer called ptr where we fect every data */
  for (Pointer &ptr : data)
  {
    total = total + ptr->getAge();
  }
  return total / data.size();
}

int AgeOfCustomer_ID(Container &data, int _id)
{
  if (data.empty())
  {
    throw std::runtime_error("Data is empty");
  }

  for (Pointer &ptr : data)
  {
    if (ptr->getId() == _id)
    {
      return ptr->getAge();
    }
  }
  throw std::runtime_error("ID NOT FOUND");
  return 0;
}

std::string CVV_Expiry_DATE(Container &data, int cvv)
{
  if (cvv > 999 || cvv < 100)
  {
    throw std::runtime_error("INVALID INPUT");
  }
  for (Pointer p : data)
  {
    if (p->getCard()->cVV() == cvv)
    {
      return p->getCard()->expiry();
    }
  }
  return 0;
}

int FindCvv(Container &data, int _id)
{
  for (Pointer p : data)
  {
    if (p->getId() == _id)
    {
      return p->getCard()->cVV();
    }
  }
  throw std::runtime_error("ID Not found");
}

Pointer_debit DebitCardID(Container &data, int ID)
{
  if (data.empty())
  {
    throw std::runtime_error("Data is empty");
  }
  for (Pointer P : data)
  {
    if (P->getId() == ID)
    {
      return P->getCard();
    }
  }
  throw std::runtime_error("ID NOT FOUD ");
}
Pointer NthCustomer(Container &data, int n)
{
  if (data.empty())
  {
    throw std::runtime_error("Data is empty");
  }
  if (n > data.size() || n < 0)
  {
    throw std::runtime_error("N is Beyond avalable items: ");
  }
  auto itr = data.begin(); // Abtraction over pointers,  So that we can travers over the conatiner without knowing the opertaion.
  while (n > 1)
  {
    itr++;
    n--;
  }
  return *itr;
}

Container AGE50(Container &data)
{
  if (data.empty())
  {
    throw std::runtime_error("Data is empty");
  }

  Container result;
  for (Pointer p : data)
  {
    if (p->getAge() > 50)
    {
      result.emplace_back(p);
      return result;
    }
  }

  throw std::runtime_error("Did not found 50+ age");
}
