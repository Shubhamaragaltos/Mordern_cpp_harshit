#include <iostream>
#include "Car.h"
#include "Engine.h"
#include <memory>
#include <vector>
#include "Functionalities.h"

using Pointer = std::shared_ptr<Car>;
using Pointer_Engine = std::shared_ptr<Engine>;
using Container = std::vector<Pointer>;
int main()
{
   Container ptr;
   /*=============================================================================================================*/

   Accept(ptr);
   std::cout << "\n\n===================== HORSEPOWER ==============================\n\n";
   try
   {
      std::cout << "Horsepower: " << Find_Horsepower(ptr, "100R2JS");
   }
   catch (std::runtime_error &e)
   {
      std::cerr << e.what() << "\n";
   }

   /*=============================================================================================================*/

   std::cout << "\n\n===================== EGINE TORQUE ==============================\n\n";
   try
   {
      Container ans;
      ans = Find_Engine_Torque(ptr);
      for (auto p : ans)
      {
         std::cout << "\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n";
         std::cout << *p;
      }
   }
   catch (const std::runtime_error &e)
   {
      std::cerr << e.what() << "\n";
   }

   /*=============================================================================================================*/
   std::cout << "\n\n===================== SAME CAR TYPE LIST ==============================\n\n";

 try{
   Container Samecartype;
   Samecartype = Find_SameCarType(ptr, CarType::HATCHBACK);


   for (auto p : Samecartype)
   {
      std::cout << "\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n";
      std::cout << *p;
   }
 }
 catch(const std::runtime_error &e)
 {
   std::cerr<<e.what()<<"\nERROR\n";
 }
   /*=============================================================================================================*/
   std::cout << "\n\n===================== AVERAGE ENGINE HORSEPOWER ==============================\n\n";
 try{
   std::cout << " Average Horsepower : " << Average_Engine_Horsepower(ptr, EngineType::ICT);
 }
 catch(const std::runtime_error &e)
 {

   std::cerr<<e.what()<<"\nERROR AVERAGE\n";
 }

   /*=============================================================================================================*/


   std::cout << "\n\n===================== LOWEST CAR PRICE ==============================\n\n";

   try{
   int long lowest = LowestCarPrice(ptr);
   std::cout << " Car_price_lowest : " << lowest;
   }
   catch(std::runtime_error &e)
   {
      std::cerr<<e.what()<<"\n";
   }
   try{
   std::cout << "\n\n===================== COMBINED PRICE ==============================\n\n";
   int long combined_Price;
   combined_Price = Combinedprice(ptr[0], ptr[1]);
   std::cout << " Combined_price : " << combined_Price << "\n\n\n";
   }
   catch(const std::runtime_error &e)
   {
      std::cerr<<e.what()<<"/n";
   }

   return 0;
}