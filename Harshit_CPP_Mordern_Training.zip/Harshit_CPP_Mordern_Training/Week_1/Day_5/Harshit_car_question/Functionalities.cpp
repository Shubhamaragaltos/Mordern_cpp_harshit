#include "Functionalities.h"
#include <cmath>

void Accept(Container &data)
{
    data.emplace_back(
        std::make_shared<Car>("100HER2JS",
                              "TATA_NEXON",
                              820000,
                              CarType::SUV,
                              std::make_shared<Engine>("EN100", 116000, 215, EngineType::MANULA)));

    data.emplace_back(
        std::make_shared<Car>("1098RTEB",
                              "MARUTI_BALENO",
                              1120000,
                              CarType::SEADAN,
                              std::make_shared<Engine>("EN101", 95000, 150, EngineType::ICT)));

    data.emplace_back(
        std::make_shared<Car>("19829HJSJ",
                              "HARRIER",
                              1478003,
                              CarType::SUV,
                              std::make_shared<Engine>("EN102", 106000, 200, EngineType::ICT)));

    data.emplace_back(
        std::make_shared<Car>("43JSI493",
                              "HONDA_CIVIC",
                              2020000,
                              CarType::SEADAN,
                              std::make_shared<Engine>("EN103", 1090800, 300, EngineType::HYBRID)));

    // for (int i = 0; i < data.size(); i++)
    // {
    //     std::cout << "\n"
    //               << *(data[i]) << "\n";
    //     std::cout << "============================================================================================================================";
    // }
}

int Find_Horsepower(Container &data, std::string carid)
{
    if (data.empty())
    {
        throw std::runtime_error("DATA IS EMPTY");
    }
    for (Pointer p : data)
    {
        if (p->carID() == carid)
        {
            return p->engineObj()->engineHorsepower();
        }
    }
    throw std::runtime_error("CAR_ID NOT FOUND");
}

Container Find_Engine_Torque(const Container &data)
{
    Container Result;
    if (data.empty())
    {
        throw std::runtime_error("DATA IS EMPTY ENGINE TORQUE 300");
    }
    for (Pointer p : data)
    {
        if (p->engineObj()->engineTorque() > 300)
        {
            Result.emplace_back(p);
        }
    }
    if (Result.empty())
    {
        throw std::runtime_error("ENHINE TORQUE NOT FOUND MORE THAN 300");
    }
    return Result;
}

Container Find_SameCarType(const Container &data, CarType choice_cartype)
{
    if (data.empty())
    {
        throw std::runtime_error("DATA IS EMPTY FOR CAR TYPE");
    }
    Container result1;
    for (Pointer p : data)
    {
        if (p->type() == choice_cartype)
        {
            result1.emplace_back(p);
        }
    }
    if (result1.empty())
    {
        throw std::runtime_error("CAR TYPE IS NOT FOUND");
    }
    return result1;
}

float Average_Engine_Horsepower(const Container &data,EngineType typ)
{
    if (data.empty())
    {
        throw std::runtime_error("DATA is NOT AVAILABLE FOR AVERAGE ENGINEHORSEPOWER");
    }
    float res = 0;int count=0;
    for (Pointer p : data)
    {
        if(p->engineObj()->eType() == typ && p->carPrice() > 1000000)
        {
        res += p->engineObj()->engineHorsepower();
        ++count;
        std::cout<<"--"<<*p<<"\n\n\n\n";

        }
    }
    return res / count;
}

long int LowestCarPrice(Container &data)
{
      if (data.empty())
    {
        throw std::runtime_error("DATA is NOT AVAILABLE FOR LOWESPRICE");
    }
    auto itr = data.begin();
    long int min = (*itr)->carPrice();
    for (Pointer P : data)
    {
        if (P->carPrice() < min)
        {
            min = P->carPrice();
        }
    }
    return min;
}

int long Combinedprice(Pointer &p1, Pointer &p2)
{
    int long ans = p1->carPrice() * p2->carPrice();
    return ans;
}
