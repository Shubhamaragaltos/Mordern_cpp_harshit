#ifndef CAR_H
#define CAR_H

#include <iostream>
#include "CarType.h"
#include "Engine.h"
#include <memory>
class Car
{
private:
    std::string Car_ID;
    float Car_Price;
    std::string Car_Brand;
    std::shared_ptr<Engine> Engine_obj;
    CarType Type;

public:
    Car(/* args */) = delete;

    Car(std::string carid, std::string carBrand, float carprice, CarType cartype, std::shared_ptr<Engine> obj);
    Car(const Car &) = delete;
    Car(Car &&) = delete;
    Car &operator=(const Car &) = delete;
    Car &operator=(Car &&) = delete;

    ~Car() = default;

    std::string carID() const
    {
        return Car_ID;
    }

    float carPrice() const { return Car_Price; }

    std::string carBrand() const { return Car_Brand; }

    std::shared_ptr<Engine> engineObj() const { return Engine_obj; }

    CarType type() const { return (Type); }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);

};

#endif // CAR_H
