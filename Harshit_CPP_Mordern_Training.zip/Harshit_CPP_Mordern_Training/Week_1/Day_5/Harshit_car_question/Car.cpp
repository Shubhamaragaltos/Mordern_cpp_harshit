#include "Car.h"

Car::Car(std::string carid, std::string carBrand, float carprice, CarType cartype, std::shared_ptr<Engine> obj)
    : Car_ID(carid), Car_Brand(carBrand), Car_Price(carprice), Type(cartype), Engine_obj(obj)
{
}

std::ostream &operator<<(std::ostream &os, const Car &rhs)
{
    os << "Car_ID: " << rhs.Car_ID
       << " Car_Price: " << rhs.Car_Price
       << " Car_Brand: " << rhs.Car_Brand
       << " Type: " << static_cast<int>(rhs.Type)

       << "\n\n Engine_Details: " << *rhs.Engine_obj;
    return os;
}
