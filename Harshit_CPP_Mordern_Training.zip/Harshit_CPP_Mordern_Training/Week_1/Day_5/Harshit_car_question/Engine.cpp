#include "Engine.h"



Engine::Engine(std::string EngineNum, int EngineHorse, int EngineTroque, EngineType Etype)
: Engine_number(EngineNum),Engine_Horsepower(EngineHorse), Engine_Torque(EngineTroque), E_Type(Etype)

{
}

std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "Engine_number: " << rhs.Engine_number
       << " Engine_Horsepower: " << rhs.Engine_Horsepower
       << " Engine_Torque: " << rhs.Engine_Torque
       << " E_Type: " << static_cast<int>(rhs.E_Type);
    return os;
}
