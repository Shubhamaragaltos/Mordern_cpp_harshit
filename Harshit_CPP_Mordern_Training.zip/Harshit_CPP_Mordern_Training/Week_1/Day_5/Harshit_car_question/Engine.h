#ifndef ENGINE_H
#define ENGINE_H

#include<iostream>
#include"EngineType.h"

class Engine
{
private:
    std::string Engine_number;
    int Engine_Horsepower;
    int Engine_Torque;
    EngineType E_Type;
    
public:
    Engine(/* args */) = delete;

    Engine(std::string EngineNum, int EngineHorse, int EngineTroque, EngineType Etype);
    Engine(const Engine &) = delete;
    Engine(Engine &&) = delete;
    Engine &operator=(const Engine &) = delete;
    Engine &operator=(Engine &&) = delete;

    ~Engine() = default;

    std::string engineNumber() const { return Engine_number; }

    int engineHorsepower() const { return Engine_Horsepower; }

    int engineTorque() const { return Engine_Torque; }

    EngineType eType() const { return E_Type; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);
};
#endif // ENGINE_H
