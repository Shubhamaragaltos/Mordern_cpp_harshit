#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include "Car.h"
#include "Engine.h"
#include <memory>
#include <vector>

using Pointer = std::shared_ptr<Car>;
using Pointer_Engine = std::shared_ptr<Engine>;
using Container = std::vector<Pointer>;

void Accept( Container &data);
int Find_Horsepower( Container &data, std::string carid);
Container Find_Engine_Torque(const Container &data);
Container Find_SameCarType(const Container &data, CarType choice_cartype);
float Average_Engine_Horsepower(const Container& data, EngineType typ);
int long LowestCarPrice( Container& data);
int long Combinedprice(Pointer& p1, Pointer& p2);

#endif // FUNCTIONALITIES_H
