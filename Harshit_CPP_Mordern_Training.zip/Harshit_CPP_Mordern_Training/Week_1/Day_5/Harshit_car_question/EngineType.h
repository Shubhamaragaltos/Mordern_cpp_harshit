#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType
{
    ICT,
    HYBRID,
    MANULA
};

#endif // ENGINETYPE_H
