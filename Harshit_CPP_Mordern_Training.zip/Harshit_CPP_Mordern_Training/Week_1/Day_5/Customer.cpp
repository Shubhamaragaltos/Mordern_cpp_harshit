#include "Customer.h"

std::ostream &operator<<(std::ostream &os, const Customer &rhs)
{
    os << std::endl;

    os << "id: " << rhs.id
       << " name: " << rhs.name
       << " age: " << rhs.age
       << " type: " << static_cast<int>(rhs.type)
       << std::endl
       << std::endl

       << " _card: " << *(rhs.card)
       << std::endl
       << std::endl;

    return os;
}

Customer::Customer(int _id, int _age, std::string _name, CustomerType _type, std::shared_ptr<Debit_Card> _card)
    : id(_id), age(_age), name(_name), type(_type), card(_card)
{
}
