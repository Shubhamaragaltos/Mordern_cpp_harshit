#ifndef CUSTOMER_TYPE_H
#define CUSTOMER_TYPE_H

enum class CustomerType
{
    REGULAR,
    ELEITE

};

#endif // CUSTOMER_TYPE_H
