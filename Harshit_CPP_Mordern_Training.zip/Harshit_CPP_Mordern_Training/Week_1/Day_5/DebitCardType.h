#ifndef DEBITCARDTYPE_H
#define DEBITCARDTYPE_H

#include<iostream>
enum class DebitCardType{
    DOMESTIC, INTERNATIONAL
};

#endif // DEBITCARDTYPE_H
