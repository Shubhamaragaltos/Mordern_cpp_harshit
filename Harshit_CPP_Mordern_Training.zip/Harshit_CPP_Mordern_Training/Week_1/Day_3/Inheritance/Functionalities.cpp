#include "Functionalities.h"
#include "PetrolCar.h"
#include"DiselCar.h"

void createObject(conatiner &data)
{
    // step 1 : make a constructor call to petrol car
    data.emplace_back(
        std::make_shared<PetrolCar>(101, "City", 100087.0f, VehicleType::PERSONAL, 43));

    data.emplace_back(
        std::make_shared<EvCar>(101, "Taigo", 109887.0f, VehicleType::PERSONAL, 73));

    data.emplace_back(
        std::make_shared<PetrolCar>(101, "Baleno", 37563.0f, VehicleType::PERSONAL,99));


    data.emplace_back(
        std::make_shared<DiselCar>(1004,"TATA_ACE",383882.0f,VehicleType::TRANSPORT,45)
    );

    

for(int i=0;i<data.size();i++)
{
    std::cout<<*(data[i])<<std::endl;
}
    //
}


