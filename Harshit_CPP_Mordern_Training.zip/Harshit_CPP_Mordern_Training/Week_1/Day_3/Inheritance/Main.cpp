#include<iostream>
#include"vehicle.h"
#include"VehicleType.h"
#include"DiselCar.h"
#include"PetrolCar.h"
#include"Functionalities.h"

using pointer= std::shared_ptr<vehicle>;
using container = std::vector<pointer>;

int main()
{
conatiner ptr;
createObject(ptr);
    
}