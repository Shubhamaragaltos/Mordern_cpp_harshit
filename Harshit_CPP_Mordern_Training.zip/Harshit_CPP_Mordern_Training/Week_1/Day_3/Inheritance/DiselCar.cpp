#include "DiselCar.h"

DiselCar::DiselCar(int id, std::string name, float price, VehicleType type, int Disel_capa)
:vehicle(id,name,price,type),Dise_capacity(Disel_capa)
{
}
std::ostream &operator<<(std::ostream &os, const DiselCar &rhs)
{
    os << static_cast<const vehicle &>(rhs)
       << " Dise_capacity: " << rhs.Dise_capacity;
    return os;
}
