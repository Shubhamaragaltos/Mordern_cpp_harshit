
#include "PetrolCar.h"
#include <iostream>


PetrolCar::PetrolCar(int id, std::string name, float price, VehicleType type,int capacity):vehicle(id,name,price,type),fuel_tank(capacity)
{
}



PetrolCar::PetrolCar(int id, std::string name, VehicleType type, int capacity)
    : vehicle(id, name, type), fuel_tank(capacity)

{
}

void PetrolCar::calculateRegistrationChange()
{
    std::cout<<"Tax on petrol car is 13%: "<<0.13f * getPrice();
}

std::ostream &operator<<(std::ostream &os, const PetrolCar &rhs) {
    os << "fuel_tank: " << rhs.fuel_tank;
    return os;
}
