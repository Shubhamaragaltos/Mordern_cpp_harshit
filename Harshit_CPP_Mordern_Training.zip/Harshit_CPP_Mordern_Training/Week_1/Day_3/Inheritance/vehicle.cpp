#include "vehicle.h"

std::ostream &operator<<(std::ostream &os, const vehicle &rhs)
{
    os << "_id: " << rhs._id
       << " _name: " << rhs._name
       << " price: " << rhs._price
       << " _type: " << static_cast<int>(rhs._type);
    return os;
}

vehicle::vehicle(int id, std::string name, float price, VehicleType type)

    : vehicle(id, name, type)

{
     _price=price;
}

vehicle::vehicle(int id, std::string name, VehicleType type)
{
}
