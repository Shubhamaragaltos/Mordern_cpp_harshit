#include "EvCar.h"
#include "vehicle.h"

EvCar::EvCar(int id, std::string name, float price, VehicleType type, int capacity)
:vehicle(id,name,price,type), battery_count(capacity)
{
}

std::ostream &operator<<(std::ostream &os, const EvCar &rhs) {
    os << static_cast<const vehicle &>(rhs)
       << " battery_count: " << rhs.battery_count;
    return os;
}

EvCar::EvCar(int id, std::string name, VehicleType type, int capacity)
{
}
