#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include <memory>
#include <vector>
#include "vehicle.h"
#include "VehicleType.h"

// Step: Create a alias pointer which is an alternate ==name
// for std::shared_ptr to vehicle.
using pointer = std::shared_ptr<vehicle>;

// step 2: Now specify the alternate container
using conatiner = std::vector<pointer>;



    void createObject(conatiner &data);
    //void AveragePrice(conatiner &data);

#endif // FUNCTIONALITIES_H
