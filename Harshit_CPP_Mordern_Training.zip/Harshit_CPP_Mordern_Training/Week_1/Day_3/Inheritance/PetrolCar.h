
#ifndef PETROLCAR_H
#define PETROLCAR_H

#include <iostream>
#include "vehicle.h"
#include "VehicleType.h"

class PetrolCar : public vehicle
{
private:
    /* data */ int fuel_tank;

public:
    PetrolCar() = default;

    PetrolCar(const PetrolCar &) = delete;
    PetrolCar(PetrolCar &&) = delete;

    PetrolCar &operator=(const PetrolCar &) = delete;
    PetrolCar &operator=(PetrolCar &&) = delete;

    PetrolCar(int id, std::string name, float price, VehicleType type, int capacity);
    PetrolCar(int id, std::string name, VehicleType type, int capacity);
    void calculateRegistrationChange ()override;


    ~PetrolCar() = default;

    int fuelTank() const { return fuel_tank; }

    friend std::ostream &operator<<(std::ostream &os, const PetrolCar &rhs);
};

#endif // PETROLCAR_H
