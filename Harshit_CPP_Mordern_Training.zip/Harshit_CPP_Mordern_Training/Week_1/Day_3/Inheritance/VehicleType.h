#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

enum class VehicleType{
    PERSONAL,
    SECURTIY,
    TRANSPORT
};

#endif // VEHICLETYPE_H
