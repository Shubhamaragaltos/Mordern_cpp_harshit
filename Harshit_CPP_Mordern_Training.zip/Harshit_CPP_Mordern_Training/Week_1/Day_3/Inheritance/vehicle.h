#ifndef VEHICLE_H
#define VEHICLE_H
#include <iostream>
#include "VehicleType.h"
class vehicle
{
private:
    int _id{1000};
    std::string _name{""};
    float _price{0.0f};
    VehicleType _type{VehicleType::PERSONAL};

public:
    vehicle() = default;

    vehicle(const vehicle &) = delete;
    vehicle( vehicle &&) = delete;

    vehicle &operator=(const vehicle &) = delete;
    vehicle &operator=(vehicle &&) = delete;

    vehicle(int id, std::string name, float price, VehicleType type);
    vehicle(int id, std::string name, VehicleType type);

    ~vehicle() = default;

    int id() const { return _id; }

    std::string name() const { return _name; }

    float getPrice() const { return _price; }

    virtual void calculateRegistrationChange();

    friend std::ostream &operator<<(std::ostream &os, const vehicle &rhs);
};

#endif // VEHICLE_H
