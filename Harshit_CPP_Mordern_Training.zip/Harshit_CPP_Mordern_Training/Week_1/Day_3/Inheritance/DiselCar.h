#include <iostream>

#include "vehicle.h"
#include "VehicleType.h"

class DiselCar : public vehicle
{
private:
    int Dise_capacity{};

public:
    DiselCar() = default;
    DiselCar(int id, std::string name, float price, VehicleType type, int Disel_capa);
    DiselCar(const DiselCar &) = delete;

    DiselCar &operator=(const DiselCar &) = delete;
    DiselCar(DiselCar &&) = delete;
    DiselCar &operator=(DiselCar &&) = delete;

    ~DiselCar() = default;

    int diselAverage() const { return Dise_capacity; }

    friend std::ostream &operator<<(std::ostream &os, const DiselCar &rhs);
};