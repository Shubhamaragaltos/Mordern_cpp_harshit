#ifndef EVCAR_H
#define EVCAR_H
#include<iostream>
#include "VehicleType.h"
#include"vehicle.h"

class EvCar: public vehicle
{
private:
    int battery_count;

public:
    EvCar() = default;

    EvCar(const EvCar &) = delete;
    EvCar(EvCar &&) = delete;

    EvCar &operator=(const EvCar &) = delete;
    EvCar &operator=(EvCar &&) = delete;

    EvCar(int id, std::string name, float price, VehicleType type, int capacity);
    EvCar(int id, std::string name, VehicleType type, int capacity);

    ~EvCar() = default;

    friend std::ostream &operator<<(std::ostream &os, const EvCar &rhs);

};

#endif // EVCAR_H
