#include <iostream>

template <typename T1, typename T2>
 auto mymax(T1 a, T2  b)
{
    return b < a ? a : b;
}
int main()
{ int i=8.90;
    std::cout << mymax(34, 3) << "\n\n";
    std::cout << mymax(34.9, 303) << "\n\n";
    std::cout << mymax(3.4948769, 3.998787343222)<< "\n\n";
    std::cout << mymax("Aditya", "shubham_mare") << "\n\n";
    auto b = mymax(34,i);
}