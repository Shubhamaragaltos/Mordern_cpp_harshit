#include<iostream>
#include"Employee.h"
#include<memory>
using Pointer = std::shared_ptr<Employee>;
void magic(const Pointer& data)
{
    data->setId(100);

}


int main()
{
    Pointer p1 = std::make_shared<Employee> (111);
    magic(p1);
    std::cout<<p1->getId();
}

