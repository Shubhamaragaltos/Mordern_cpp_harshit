#include<iostream>
#include<memory>
#include"Employee.h"
/*
i am creating a function magic
It needs to accept one integer "data"

scenario 1: 
Copy and create duplicated data value to preserve original 
value inside data and yet perform operation on the copy inside magic.

Scenario 2:

I have "temporary" integer which needs  to be passed to magic.
Magic would perform operations like modification on the integer
and retrun the modified value.

- Pass integer Rvalue referance and return modified data by value.
- pass
*/

/*This overload of magic accepts one integer by rvalue referance and returns one integer by value*/

int magic(int && data)
{

}

std::shared_ptr<Employee> magic(std::shared_ptr<Employee>&& data)
{

}

Employee magic(Employee&& data)
{

}
int main()
{
magic(10);
Employee (101);
magic(Employee(101));
magic(std::make_shared<Employee>(102));
}
