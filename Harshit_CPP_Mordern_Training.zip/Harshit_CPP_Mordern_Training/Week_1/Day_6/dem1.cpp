#include <iostream>
#include <vector>

template <typename T>
class stack
{
    std::vector<T> v1;

public:
    // stack() = default;
    void push(const T &);
    void print()
    {
        for (T &ptr : v1)
        {
            std::cout << ptr << "\n";
        }
    }
};
// template <typename T>
// stack<T>::stack()
// {
// }

template <typename T>
void stack<T>::push(const T &element)
{
    v1.push_back(element);
}
int main()
{
    stack<int> s1;
    s1.push(45);
    s1.push(3);
    s1.push(4875);
    s1.push(4.5);

    stack<double> s2;
    s2.push(3.40);
    s2.push(340.00);
    s2.push(3776.40);
    s2.push(0.3);
    s2.push(34.98765);

    //s1.print();
    s2.print();

    

    return 0;
}
