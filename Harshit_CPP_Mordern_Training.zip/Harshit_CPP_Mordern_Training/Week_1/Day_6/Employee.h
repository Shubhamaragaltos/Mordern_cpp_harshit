#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include <ostream>

class Employee
{
private:
    int id;

public:
    Employee(int _id) : id(_id){};

    ~Employee() = default;

    int getId() const { return id; }

    void setId(int id_) { id = id_; }

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);
};

inline std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "id: " << rhs.id;
    return os;
}

#endif // EMPLOYEE_H
