#include<iostream>
#include <memory>
#include"Employee.h"
#include<vector>
#include<list>

using Empointer = std::shared_ptr<Employee>;
using Container_vectot = std::vector<Empointer>;
using Container_List = std::list<Empointer>;

void createObject(Container_List& l1, Container_vectot &l2){

    l1.emplace_back(
        std::make_shared<Employee>(100)
    );
     l1.emplace_back(
        std::make_shared<Employee>(101)
    );
     l1.emplace_back(
        std::make_shared<Employee>(102)
    );

    /*------------*/
     l2.emplace_back(
        std::make_shared<Employee>(300)
    );

     l2.emplace_back(
        std::make_shared<Employee>(301)
    );

     l2.emplace_back(
        std::make_shared<Employee>(302)
    );

}

int main()
{
    Container_List r1;
    Container_vectot V1;

   
    createObject(r1,V1);
    for(Empointer p : V1 )
    {
        std::cout<<"\n"<<*p<<"\n";
    }
    std::cout<<"\n+======================= \n";
    auto itr = r1.begin();
    itr++;

     for(Empointer p : r1 )
    {
        std::cout<<"\n"<<**itr<<"\n";
    }
    return 0;

}
/* 
Types of common logic building exercises : 

1) Total or algebraic sum operation.

 - i. create a initial toatal variable with initial value as 0.
 - ii. For each item to be added int he total, do the following

        a)fetch item 
        b) add the item to the sum
        c) update the sum;

 - iii. Return then final sum

2) Find Min value from a collection.

-i. create  initial min Value WHICH MUST BE EQUAL TO THE FIRST ITEM FROM HTE COLLECTION (MIN= data.begin())
-ii. for each item in the collection.
      a) fetch the item
      b) compare the item with "MIN_VALUE" so far.
      c)if current item is smaller, update min_value as "current item".
-iii. Finally, the min_value now holds "the global minima"




*/