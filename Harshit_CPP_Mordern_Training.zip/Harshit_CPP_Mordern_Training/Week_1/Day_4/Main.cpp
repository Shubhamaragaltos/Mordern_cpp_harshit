#include<iostream>
#include<vector>
#include<memory>
#include"Customer.h"
#include"functionalities.h"


using Pointer = std::shared_ptr<Customer>;
using Container = std::vector<Pointer>;

std::shared_ptr<Customer> dummy()
{
    std::shared_ptr<Customer> ptr = std::make_shared<Customer>(
        1001,
        34,
        "ADITYA",
        CustomerType::ELEITE,
        std::make_shared<Debit_Card>()

    );
}

int main()
{
    Container ptr;
    createObject(ptr);
    std::cout<<"\n++++++++++++++++++++++++++++\n";
    dummy();
}
