#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <iostream>
#include "Customer_type.h"
#include "Debit_Card.h"
#include<memory>

class Customer 
{
private:
    int id;
    std::string name;
    int age;
    CustomerType type;
    std::shared_ptr <Debit_Card> card;

public:
    Customer() = default;
    Customer(int _id, int _age, std::string _name, CustomerType _type, std:: shared_ptr<Debit_Card> _card);
    Customer(const Customer &) = delete;
    Customer(Customer &&) = delete;
    Customer &operator=(const Customer &) = delete;
    Customer &operator=(Customer &&) = delete;
    ~Customer() = default;

    int getId() const { return id; }
    std::string getName() const { return name; }
    void setAge(int age_) { age = age_; }
    CustomerType getType() const { return type; }
    friend std::ostream &operator<<(std::ostream &os, const Customer &rhs);
};

#endif // CUSTOMER_H
