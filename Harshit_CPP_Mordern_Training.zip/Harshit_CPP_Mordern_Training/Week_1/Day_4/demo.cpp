#include <memory>
#include <iostream>


class demo
{
private:
    int n;
public:
    demo(int k) {n=k;}
    ~demo() {}
    

    int getN() const { return n; }

    friend std::ostream &operator<<(std::ostream &os, const demo &rhs);
};
int main()
{
    std::shared_ptr<int[10]> p (new int [4]);
    //std::cin>>p[0];
   // std::cout<<p[0];

        std::cout<<"\n=============================================\n";


    std::shared_ptr<demo> ptr = std::make_shared<demo>(10);
    std::cout<<*ptr;
    
        



    return 0;
}
inline std::ostream &operator<<(std::ostream &os, const demo &rhs) {
    os << "n: " << rhs.n;
    return os;
}
