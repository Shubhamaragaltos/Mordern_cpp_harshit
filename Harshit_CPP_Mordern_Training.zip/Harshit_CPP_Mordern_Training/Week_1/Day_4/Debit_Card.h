#ifndef DEBIT_CARD_H
#define DEBIT_CARD_H

#include <iostream>
#include "DebitCardType.h"

class Debit_Card
{
private:
    int CVV;
    std::string Debit_name;
    std::string Expiry;
    DebitCardType Type_debit;

public:
    Debit_Card() = default;
    Debit_Card(int _cvv, std::string _DebirName, std::string _Expiry, DebitCardType _type);
    Debit_Card(const Debit_Card &) = delete;
    Debit_Card(Debit_Card &&) = delete;
    Debit_Card &operator=(const Debit_Card &) = delete;
    Debit_Card &operator=(Debit_Card &&) = delete;

    int cVV() const { return CVV; }

    std::string expiry() const { return Expiry; }

    std::string debitName() const { return Debit_name; }

    DebitCardType typeDebit() const { return Type_debit; }

    friend std::ostream &operator<<(std::ostream &os, const Debit_Card &rhs);
};

#endif // DEBIT_CARD_H
