#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include<memory>
#include<vector>
#include "Customer.h"


using Pointer = std::shared_ptr<Customer>;
using Container = std::vector<Pointer>;

void createObject(Container &data);

   




#endif // FUNCTIONALITIES_H
