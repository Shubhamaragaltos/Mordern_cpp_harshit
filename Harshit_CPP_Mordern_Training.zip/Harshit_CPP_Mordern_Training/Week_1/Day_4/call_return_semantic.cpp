#include<iostream>

int magic(int n1)
{
    std::cout<<"Address of n1 in Magic : "<<&n1<<"\n";
    int ans = n1*100;
    return ans;
}

int main()
{
    int data=20;
    std::cout<<"Address of DATA in MAin "<<&data<<"\n";

    int result = magic(data);
}