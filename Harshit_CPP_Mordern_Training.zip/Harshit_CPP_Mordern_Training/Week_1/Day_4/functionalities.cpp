#include "functionalities.h"

void createObject(Container &data)
{
    data.emplace_back(
        std::make_shared<Customer> (
            1001,
            33,
            "SHUBHAM",
          CustomerType::ELEITE,
            std::make_shared<Debit_Card>(243, "HARSHIT","28/11",DebitCardType::DOMESTIC))
        
        
    );

    std::cout<<*(data[0]);
}
