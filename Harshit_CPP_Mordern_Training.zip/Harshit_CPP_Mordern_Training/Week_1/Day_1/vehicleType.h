#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H


enum class vehicleType
{
    PERSONAL,
    TRANSPORT,
    LUXIOUR
};


#endif // VEHICLETYPE_H
