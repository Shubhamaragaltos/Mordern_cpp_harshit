
#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include"vehicle.h"
/*

Accept a pointer to an array of pointers.
Initialize objects on heap. Store their addreses in the array.
*/
void createobjects(vehicle** arr,const int size);

/*
loop over instance.
calculate total price and divide it by number of instance
*/

float AveragePrice( vehicle** arr, const int size);

/*return id of lowest price*/

int lowest_price_ID( vehicle** arr, const int size);




#endif // FUNCTIONALITIES_H
