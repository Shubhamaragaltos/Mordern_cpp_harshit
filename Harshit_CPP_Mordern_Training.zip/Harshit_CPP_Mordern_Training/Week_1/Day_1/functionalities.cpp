#include "functionalities.h"

void createobjects(vehicle **arr, const int size)
{
    //  arr[0] = new vehicle(101, "nexon", 82000.0f, vehicleType::PERSONAL);

    int id = 0;
    std::string name = "maruti";
    float price = 0.0f;
    vehicleType type;
    int choice = -1;

    for (int i = 0; i < size; i++)
    {
        int id = 0;
    std::string name = "maruti";
    float price = 0.0f;
    vehicleType type;
    int choice = -1;
    
        std::cin >> id;
        std::cin >> name;
        std::cin >> price;
        std::cin >> choice;

        if (choice == 0)
        {
            type = vehicleType::PERSONAL;
        }
        else
            type = vehicleType::TRANSPORT;
        arr[i] = new vehicle(id, name, price, type);
    }
}

float AveragePrice( vehicle **arr, const int size)
{
    float total = 0.0f;
    for (int i = 0; i < size; i++)
    {
        total += arr[i]->price();
    }

    return total / size;
}

int lowest_price_ID( vehicle **arr, const int size)
{
    // first loaction is for minimum price;

    int ans = arr[0]->id();
    int _min_price = arr[0]->price();
    for (int i = 0; i < size; i++)
    {
        float _current_price = arr[i]->price();
        if (_min_price >_current_price)
        {
            _min_price = _current_price;
            ans = arr[i]->id();
        }
    }
    return ans;
}
