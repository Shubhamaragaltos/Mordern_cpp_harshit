#include <iostream>
#include "functionalities.h"
#include "vehicle.h"

int main()
{
    /* average price should be calculated for all the insatances stored in the array by createobjects
     */
    int size = 3;

    vehicle *arr[3] = {nullptr};

    createobjects(arr, size);

    float k = AveragePrice(arr, size);
    std::cout << "\n AVERAGE  : " << k;
    int and_id = lowest_price_ID(arr, size);
    std::cout << "\n Lowest price  : " << and_id;
}