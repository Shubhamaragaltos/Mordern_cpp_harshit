#ifndef INDIVIDUALTRIPCLASS_H
#define INDIVIDUALTRIPCLASS_H

#include <iostream>
#include "TripClass.h"

class IndividualTripClass : public TripClass
{
private:
  int Individual_Trip_Duration;

public:
  IndividualTripClass(/* args */) = default;
  IndividualTripClass(std::string _trip_id, std::string _trip_driver, int trip_disatance, int trip_rating, RideType type, int IndividualTrip_D);
  IndividualTripClass(IndividualTripClass &&) = delete;
  IndividualTripClass(const IndividualTripClass &) = delete;
  IndividualTripClass &operator=(const IndividualTripClass &) = delete;
  IndividualTripClass &operator=(IndividualTripClass &&) = delete;
  ~IndividualTripClass() = default;
  //float CalculateFare() override;
  int individualTrip_Duration() const { return Individual_Trip_Duration; }
  void setIndividual_Trip_Duration(int individualTrip_Duration) { Individual_Trip_Duration = individualTrip_Duration; }

  friend std::ostream &operator<<(std::ostream &os, const IndividualTripClass &rhs);
};

#endif // INDIVIDUALTRIPCLASS_H
