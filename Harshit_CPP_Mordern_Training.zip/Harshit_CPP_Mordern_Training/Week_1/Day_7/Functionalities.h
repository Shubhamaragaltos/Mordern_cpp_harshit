#include<iostream>
#include"IndividualTripClass.h"
#include<memory>
#include<vector>

using Pointer = std::shared_ptr<TripClass>;
using Container = std::vector<Pointer>;

void createObject(Container& data);
std::vector<int> Calculate_fare(Container &data);
void Rating(Container& data);

