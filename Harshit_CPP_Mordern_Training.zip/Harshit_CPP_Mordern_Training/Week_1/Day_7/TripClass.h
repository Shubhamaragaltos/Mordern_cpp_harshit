#ifndef TRIPCLASS_H
#define TRIPCLASS_H

#include <iostream>
#include "RideType.h"

class TripClass
{
private:
    std::string Trip_id;
    std::string Trip_Driver;
    int Trip_Distance;
    int Trip_Rating;
    RideType Type;

public:
    TripClass(/* args */)=default;
    TripClass(std::string _trip_id,std::string _trip_driver,int trip_disatance, int trip_rating, RideType type);
    TripClass(TripClass&&)=delete;
    TripClass(const TripClass&)=delete;
    TripClass &operator=(const TripClass&)=delete;
    TripClass &operator=(TripClass&&)=delete;
  virtual  ~TripClass() =default;

    std::string tripId() const { return Trip_id; }
    void setTripId(const std::string &tripId) { Trip_id = tripId; }

    std::string tripDriver() const { return Trip_Driver; }
    void setTrip_Driver(const std::string &tripDriver) { Trip_Driver = tripDriver; }

    int tripDistance() const { return Trip_Distance; }
    void setTrip_Distance(int tripDistance) { Trip_Distance = tripDistance; }

    int tripRating() const { return Trip_Rating; }
    void setTrip_Rating(int tripRating) { Trip_Rating = tripRating; }

    RideType type() const { return Type; }
    void setType(const RideType &type) { Type = type; }

    friend std::ostream &operator<<(std::ostream &os, const TripClass &rhs);
  //  virtual float CalculateFare()=0;
};

#endif // TRIPCLASS_H
