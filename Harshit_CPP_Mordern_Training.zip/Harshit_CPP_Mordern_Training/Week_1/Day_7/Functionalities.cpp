#include "Functionalities.h"

void createObject(Container &data)
{
  data.emplace_back(std::make_shared<IndividualTripClass>("IJH536", "MAHESH", 45, 1, RideType::REGULAR, 1.5));
  data.emplace_back(std::make_shared<IndividualTripClass>("IJE3536", "SHUBHAM", 15, 2, RideType::REGULAR, 2));

  data.emplace_back(std::make_shared<IndividualTripClass>("I45T536", "SAKSHI", 34, 3, RideType::COMFORT, 35));

  data.emplace_back(std::make_shared<IndividualTripClass>("IRT4336", "HETVI", 22, 4, RideType::COMFORT, 1));

  data.emplace_back(std::make_shared<IndividualTripClass>("KSO589", "ROHAN", 101, 5, RideType::PREMIUM, 12));
auto itr = data.begin();
  for(auto p : data)
  {
  
    std::cout<<"\n"<<**itr;
    itr++;
  }
}

std::vector<int> Calculate_fare(Container &data)
{
  std::vector<int> arr;
  for (auto &p : data)
  {
    if (p->type() == RideType::COMFORT)
    {
      arr.emplace_back((p->tripDistance() * 30) + (p->tripDistance() * 30 * 0.18));
    }
    else if (p->type() == RideType::REGULAR)
    {
      arr.emplace_back((p->tripDistance() * 25) + (p->tripDistance() * 25 * 0.18));
    }
    else
    {
      arr.emplace_back((p->tripDistance() * 50) + (p->tripDistance() * 50 * 0.18));
    }
  }

  return arr;
}

void Rating(Container &data)
{

  for (Pointer P : data)
  {
    if (P->tripRating() <= 2)
    {
      int k = static_cast<int>(P->type());
      std::cout << "\nThe Ride is REGULAR:" << k << "\n";
    }
    else if (P->tripRating() <= 4)
    {
      int k = static_cast<int>(P->type());
      std::cout << "\nThe Ride is COMFORT:" << k << "\n";
    }
    else
    {
      int k = static_cast<int>(P->type());
      std::cout << "\nThe Ride is PREMIUM:" << k << "\n";
    }
  }
}
