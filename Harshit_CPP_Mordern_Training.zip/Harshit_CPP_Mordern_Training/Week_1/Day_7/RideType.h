#ifndef RIDETYPE_H
#define RIDETYPE_H

enum class RideType
{
    REGULAR,
    COMFORT,
    PREMIUM
};

#endif // RIDETYPE_H
