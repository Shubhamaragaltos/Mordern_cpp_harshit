#include "IndividualTripClass.h"


IndividualTripClass::IndividualTripClass(std::string _trip_id, std::string _trip_driver, int trip_disatance, int trip_rating, RideType type, int IndividualTrip_D)
:TripClass(_trip_id, _trip_driver, trip_disatance, trip_rating, type),Individual_Trip_Duration(IndividualTrip_D)
{
    
}


std::ostream &operator<<(std::ostream &os, const IndividualTripClass &rhs) {
  os << static_cast<const TripClass &>(rhs)
     << " Individual_Trip_Duration: " << rhs.Individual_Trip_Duration;
  return os;
}
