#include "TripClass.h"

TripClass::TripClass(std::string _trip_id, std::string _trip_driver, int trip_disatance, int trip_rating, RideType type)
: Trip_id(_trip_id),Trip_Driver(_trip_driver),Trip_Distance(trip_disatance),Trip_Rating(trip_rating)
{
    
}
std::ostream &operator<<(std::ostream &os, const TripClass &rhs) {
    os << "Trip_id: " << rhs.Trip_id
       << " Trip_Driver: " << rhs.Trip_Driver
       << " Trip_Distance: " << rhs.Trip_Distance
       << " Trip_Rating: " << rhs.Trip_Rating
       << " Type: " << static_cast<int>(rhs.Type);
    return os;
}
