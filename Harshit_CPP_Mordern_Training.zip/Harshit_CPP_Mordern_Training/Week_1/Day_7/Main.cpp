#include <iostream>
#include "Functionalities.h"
#include <memory>
#include <vector>

int main()
{
    Container ptr;
    createObject(ptr);
    std::cout << "\n+++++++++++++++++++=\n";
    std::vector<int> arr = Calculate_fare(ptr);
    for(auto i : arr)
    {
        std::cout<<i<<"\n";
    }

    
}