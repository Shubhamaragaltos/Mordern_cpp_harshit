#include "SharedTripClass.h"




SharedTripClass::SharedTripClass(std::string _trip_id, std::string _trip_driver, int trip_disatance, int trip_rating, RideType type, int Shared_trip)
:TripClass(_trip_id, _trip_driver, trip_disatance, trip_rating, type),shared_Trip_passenger(Shared_trip)
{
    
}




std::ostream &operator<<(std::ostream &os, const SharedTripClass &rhs) {
    os << static_cast<const TripClass &>(rhs)
       << " shared_Trip_passenger: " << rhs.shared_Trip_passenger;
    return os;
}
